<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="website title" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Navigation Links" FOLDED="true">
        <node TEXT="Home" LINK="https://kidneycareconsultants.com" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Services" LINK="https://kidneycareconsultants.com/services/" FOLDED="true">
          <node TEXT="Chronic Kidney Disease" LINK="https://kidneycareconsultants.com/services/chronic-kidney-disease/" FOLDED="true">
            <node TEXT="Overview" FOLDED="true">
              <node TEXT="Introduction to CKD - summary of definition and risk" FOLDED="true"/>
            </node>
            <node TEXT="Chronic Kidney Disease Program" FOLDED="true">
              <node TEXT="Program description - treating, reversing disease, managing complications" FOLDED="true"/>
            </node>
            <node TEXT="Symptoms Of Kidney Disease" FOLDED="true">
              <node TEXT="List of main CKD symptoms (fatigue, swelling, etc)" FOLDED="true"/>
            </node>
            <node TEXT="What Increases One’s Risk Of Having Chronic Kidney Disease?" FOLDED="true">
              <node TEXT="Major risk factors and populations at risk" FOLDED="true"/>
            </node>
            <node TEXT="How Can The Progression Of Kidney Disease Be Delayed?" FOLDED="true">
              <node TEXT="Tips for managing and delaying CKD" FOLDED="true"/>
            </node>
            <node TEXT="Goals" FOLDED="true">
              <node TEXT="Management targets for CKD (blood pressure, anemia, nutrition, etc)" FOLDED="true"/>
            </node>
            <node TEXT="Stages Of Kidney Disease" FOLDED="true">
              <node TEXT="CKD stage table: GFR and stage goals" FOLDED="true"/>
            </node>
            <node TEXT="Treatments for Kidney Failure" FOLDED="true">
              <node TEXT="CKD treatment options overview" FOLDED="true"/>
            </node>
            <node TEXT="CKD Related Services" FOLDED="true">
              <node TEXT="Glomerulonephritis" LINK="https://kidneycareconsultants.com/services/glomerulonephritis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_glomerulonephritis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Hypertension" LINK="https://kidneycareconsultants.com/services/hypertension/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_hypertension.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Acid Base and Electrolyte Disorders" LINK="https://kidneycareconsultants.com/services/acid-base-and-electrolyte-disorders/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_acid-base-and-electrolyte-disorders.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Treatment and Evaluation of Genetic and Hereditary Kidney Diseases" LINK="https://kidneycareconsultants.com/services/treatment-and-evaluation-of-genetic-and-hereditary-kidney-diseases/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_treatment-and-evaluation-of-genetic-and-hereditary-kidney-diseases.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Nephrolithiasis" LINK="https://kidneycareconsultants.com/services/nephrolithiasis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_nephrolithiasis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="End Stage Renal Disease" LINK="https://kidneycareconsultants.com/services/end-stage-renal-disease/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_end-stage-renal-disease.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Transplant Nephrology" LINK="https://kidneycareconsultants.com/services/transplant-nephrology/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_transplant-nephrology.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_chronic-kidney-disease.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Diet Information" LINK="https://kidneycareconsultants.com/services/diet-information/" FOLDED="true">
            <node TEXT="Table Of Contents" FOLDED="true">
              <node TEXT="Potassium" LINK="https://kidneycareconsultants.com/services/diet-information/#potassium" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_diet-information_potassium.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Sodium (PDF)" LINK="https://kidneycareconsultants.com/wp-content/uploads/2024/11/sodium_potassium_calories.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_wp-content_uploads_2024_11_sodium_potassium_calories.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Oxalate (PDF)" LINK="https://kidneycareconsultants.com/wp-content/uploads/2024/11/low_oxalate_diet.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_wp-content_uploads_2024_11_low_oxalate_diet.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Potassium Modified Diet" FOLDED="true">
              <node TEXT="Summary: Canned fruits and vegetables are lower in potassium than fresh or frozen, avoid high potassium foods." FOLDED="true"/>
              <node TEXT="High Potassium Fruit" FOLDED="true">
                <node TEXT="Apricot" FOLDED="true"/>
                <node TEXT="Avocado" FOLDED="true"/>
                <node TEXT="Banana" FOLDED="true"/>
                <node TEXT="Cantaloupe" FOLDED="true"/>
                <node TEXT="Date" FOLDED="true"/>
                <node TEXT="Fig" FOLDED="true"/>
                <node TEXT="Honeydew" FOLDED="true"/>
                <node TEXT="Mango" FOLDED="true"/>
                <node TEXT="Nectarine" FOLDED="true"/>
                <node TEXT="Orange" FOLDED="true"/>
                <node TEXT="Papaya" FOLDED="true"/>
                <node TEXT="Plum" FOLDED="true"/>
                <node TEXT="Prune" FOLDED="true"/>
                <node TEXT="Raisins" FOLDED="true"/>
                <node TEXT="Tomato Juice" FOLDED="true"/>
                <node TEXT="Vegetable Juice" FOLDED="true"/>
                <node TEXT="Watermelon" FOLDED="true"/>
                <node TEXT="Apricot Nectar" FOLDED="true"/>
                <node TEXT="Orange Juice" FOLDED="true"/>
              </node>
              <node TEXT="High Potassium Vegetables" FOLDED="true">
                <node TEXT="Artichoke" FOLDED="true"/>
                <node TEXT="Beans, any dried" FOLDED="true"/>
                <node TEXT="Broccoli" FOLDED="true"/>
                <node TEXT="Brussel Sprouts" FOLDED="true"/>
                <node TEXT="French Fries" FOLDED="true"/>
                <node TEXT="Parsnips" FOLDED="true"/>
                <node TEXT="Pumpkin" FOLDED="true"/>
                <node TEXT="Potato" FOLDED="true"/>
                <node TEXT="Lima Beans" FOLDED="true"/>
                <node TEXT="Spinach" FOLDED="true"/>
                <node TEXT="Tomato" FOLDED="true"/>
                <node TEXT="Winter Squash" FOLDED="true"/>
                <node TEXT="Rhubarb" FOLDED="true"/>
                <node TEXT="Grapefruit Juice" FOLDED="true"/>
                <node TEXT="Prune Juice" FOLDED="true"/>
              </node>
              <node TEXT="Other High Potassium Foods" FOLDED="true">
                <node TEXT="Bran Cereal Chocolate Candy" FOLDED="true"/>
                <node TEXT="Coconut Molasses" FOLDED="true"/>
                <node TEXT="Milk (4 oz. Daily is ok) Nuts" FOLDED="true"/>
              </node>
              <node TEXT="Low Potassium Fruits" FOLDED="true">
                <node TEXT="Apple" FOLDED="true"/>
                <node TEXT="Apple Juice" FOLDED="true"/>
                <node TEXT="Applesauce" FOLDED="true"/>
                <node TEXT="Blueberries" FOLDED="true"/>
                <node TEXT="Cherries" FOLDED="true"/>
                <node TEXT="Cranberries" FOLDED="true"/>
                <node TEXT="Cranberry Juice" FOLDED="true"/>
                <node TEXT="Fruit Cocktail" FOLDED="true"/>
                <node TEXT="Grapes" FOLDED="true"/>
                <node TEXT="Grape Juice" FOLDED="true"/>
                <node TEXT="Grapefruit" FOLDED="true"/>
                <node TEXT="Lemon" FOLDED="true"/>
                <node TEXT="Peach" FOLDED="true"/>
                <node TEXT="Pear" FOLDED="true"/>
                <node TEXT="Pear Nectar" FOLDED="true"/>
                <node TEXT="Pineapple" FOLDED="true"/>
                <node TEXT="Plum" FOLDED="true"/>
                <node TEXT="Strawberries" FOLDED="true"/>
                <node TEXT="Tangerine" FOLDED="true"/>
              </node>
              <node TEXT="Low Potassium Vegetables" FOLDED="true">
                <node TEXT="Asparagus" FOLDED="true"/>
                <node TEXT="Beets" FOLDED="true"/>
                <node TEXT="Cabbage" FOLDED="true"/>
                <node TEXT="Carrots" FOLDED="true"/>
                <node TEXT="Cauliflower" FOLDED="true"/>
                <node TEXT="Celery" FOLDED="true"/>
                <node TEXT="Corn" FOLDED="true"/>
                <node TEXT="Cucumber" FOLDED="true"/>
                <node TEXT="Eggplant" FOLDED="true"/>
                <node TEXT="Green beans" FOLDED="true"/>
                <node TEXT="Green pepper" FOLDED="true"/>
                <node TEXT="Lettuce" FOLDED="true"/>
                <node TEXT="Okra" FOLDED="true"/>
                <node TEXT="Onion" FOLDED="true"/>
                <node TEXT="Peas" FOLDED="true"/>
                <node TEXT="Potato-Mashed only" FOLDED="true"/>
                <node TEXT="Radish" FOLDED="true"/>
                <node TEXT="Wax beans" FOLDED="true"/>
                <node TEXT="Zucchini" FOLDED="true"/>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_diet-information.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Our Services" FOLDED="true">
            <node TEXT="Chronic Kidney Disease (CKD) due to HTN and DM" FOLDED="true">
              <node TEXT="Summary: Comprehensive evaluation and management of CKD." FOLDED="true"/>
              <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/chronic-kidney-disease/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_chronic-kidney-disease.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Diet Information" FOLDED="true">
              <node TEXT="Summary: Potassium is a mineral. Healthy kidneys maintain normal balance." FOLDED="true"/>
              <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/diet-information/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_diet-information.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Transplant Program" FOLDED="true">
              <node TEXT="Summary: Coming Soon" FOLDED="true"/>
              <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/transplant-program/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_transplant-program.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Transplant Program" LINK="https://kidneycareconsultants.com/services/transplant-program/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_transplant-program.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Glomerulonephritis" LINK="https://kidneycareconsultants.com/services/glomerulonephritis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_glomerulonephritis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Hypertension" LINK="https://kidneycareconsultants.com/services/hypertension/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_hypertension.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Acid base and electrolyte disorders" LINK="https://kidneycareconsultants.com/services/acid-base-and-electrolyte-disorders/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_acid-base-and-electrolyte-disorders.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Treatment and Evaluation of Genetic and Hereditary Kidney Diseases" LINK="https://kidneycareconsultants.com/services/treatment-and-evaluation-of-genetic-and-hereditary-kidney-diseases/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_treatment-and-evaluation-of-genetic-and-hereditary-kidney-diseases.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Nephrolithiasis" LINK="https://kidneycareconsultants.com/services/nephrolithiasis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_nephrolithiasis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="End stage Renal Disease" LINK="https://kidneycareconsultants.com/services/end-stage-renal-disease/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_end-stage-renal-disease.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Transplant Nephrology" LINK="https://kidneycareconsultants.com/services/transplant-nephrology/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_transplant-nephrology.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Home Page" LINK="https://kidneycareconsultants.com" FOLDED="true">
        <node TEXT="Hero Section" FOLDED="true">
          <node TEXT="Skip to content" LINK="https://kidneycareconsultants.com/#content" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_content.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Phone" LINK="tel:8669957667" FOLDED="true"/>
          <node TEXT="Pay Now" LINK="https://pay.streampay.streamlinepayments.com/#/qGCdZ%2525252fgjyNI27uT4rpznnqbbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/qGCdZ%2525252fgjyNKnJggufIU%2525252fwabbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/pay" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_pay.streampay.streamlinepayments.com_qGCdZ_2525252fgjyNI27uT4rpznnqbbCvtkqi0l_2525252f_2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1_qGCdZ_2525252fgjyN.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Schedule an appointment" LINK="https://kidneycareconsultants.com/#appointment-form" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_appointment-form.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Specialized Care Section" FOLDED="true">
          <node TEXT="24 Hours on Call" LINK="tel:8669957667" FOLDED="true"/>
          <node TEXT="See Our Clinic Locations" LINK="https://kidneycareconsultants.com/clinic-locations/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_clinic-locations.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Appointment Form" FOLDED="true">
            <node TEXT="Phone number*" FOLDED="true"/>
            <node TEXT="Email Address*" FOLDED="true"/>
            <node TEXT="Major Illness*" FOLDED="true"/>
            <node TEXT="Message" FOLDED="true"/>
            <node TEXT="Connect Button" FOLDED="true"/>
          </node>
        </node>
        <node TEXT="Our Services" FOLDED="true">
          <node TEXT="Chronic Kidney Disease (CKD) due to HTN and DM" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/chronic-kidney-disease/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_chronic-kidney-disease.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Diet Information" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/diet-information/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_diet-information.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Transplant Program" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/transplant-program/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_transplant-program.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Glomerulonephritis" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/glomerulonephritis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_glomerulonephritis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Hypertension" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/hypertension/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_hypertension.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Acid Base and Electrolyte Disorders" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/acid-base-and-electrolyte-disorders/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_acid-base-and-electrolyte-disorders.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Treatment and Evaluation of Genetic and Hereditary Kidney Diseases" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/treatment-and-evaluation-of-genetic-and-hereditary-kidney-diseases/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_treatment-and-evaluation-of-genetic-and-hereditary-kidney-diseases.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Nephrolithiasis" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/nephrolithiasis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_nephrolithiasis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="End Stage Renal Disease" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/end-stage-renal-disease/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_end-stage-renal-disease.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Transplant Nephrology" FOLDED="true">
            <node TEXT="Read More" LINK="https://kidneycareconsultants.com/services/transplant-nephrology/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_services_transplant-nephrology.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="Our Locations" FOLDED="true">
          <node TEXT="Broadway (Main Office)" FOLDED="true">
            <node TEXT="716 West Broadway Louisville, Ky 40202" LINK="https://maps.app.goo.gl/vMLRTbWBb73xrRdT8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_vMLRTbWBb73xrRdT8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="(866) 995-7667" LINK="tel:8669957667" FOLDED="true"/>
            <node TEXT="502-595-7007" LINK="fax:502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" LINK="https://maps.app.goo.gl/vMLRTbWBb73xrRdT8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_vMLRTbWBb73xrRdT8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Dixie Clinic (Dr Nair’ Office)" FOLDED="true">
            <node TEXT="8442 Dixie Hwy, Louisville, KY 40258" LINK="https://maps.app.goo.gl/T6ryZbveF2EgYb3b6" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_T6ryZbveF2EgYb3b6.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Get Directions" LINK="https://maps.app.goo.gl/T6ryZbveF2EgYb3b6" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_T6ryZbveF2EgYb3b6.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="HCH Medical Pavilion" FOLDED="true">
            <node TEXT="1263 Hospital Drive NW, Suite 100 Corydon, In 47112" LINK="https://maps.app.goo.gl/LYQzsonJqfKjUKMWA" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_LYQzsonJqfKjUKMWA.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="502- 425-9121" LINK="tel:502- 425-9121" FOLDED="true"/>
            <node TEXT="502-425-9161" LINK="fax:502-425-9161" FOLDED="true"/>
            <node TEXT="Get Directions" LINK="https://maps.app.goo.gl/LYQzsonJqfKjUKMWA" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_LYQzsonJqfKjUKMWA.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Dixie Highway Office" FOLDED="true">
            <node TEXT="8037 Dixie Highway Louisville, KY 40258" LINK="https://maps.app.goo.gl/1Ez5o1G4wngrZHMi8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_1Ez5o1G4wngrZHMi8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="(866) 995-7667" LINK="tel:8669957667" FOLDED="true"/>
            <node TEXT="502-595-7007" LINK="fax:502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" LINK="https://maps.app.goo.gl/1Ez5o1G4wngrZHMi8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_1Ez5o1G4wngrZHMi8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="View More" LINK="https://kidneycareconsultants.com/clinic-locations/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_clinic-locations.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Login" LINK="https://kidneycareconsultants.com/login/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_login.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Sign Up" LINK="https://kidneycareconsultants.com/signup/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_signup.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Our Providers" LINK="https://kidneycareconsultants.com/our-providers/" FOLDED="true">
        <node TEXT="Provider Directory" FOLDED="true">
          <node TEXT="Ashwin Dixit - MD - Cares for dialysis   chronic kidney disease patients in south Louisville   Shepherdsville." FOLDED="true"/>
          <node TEXT="David Fendley - MD - Southern Indiana practice, home dialysis in Jeffersonville, also serves Dixie Highway area." FOLDED="true"/>
          <node TEXT="Luisa Franco - MD - Outpatient office and home dialysis, cares for patients in Carrollton and Jeffersontown." FOLDED="true"/>
          <node TEXT="Salgram Jaisinghani - MD - Board-certified, new patients for chronic kidney disease, hypertension, imbalances, glomerular diseases." FOLDED="true"/>
          <node TEXT="Leslie Wood - MD - Downtown and Shelbyville, cares for hemodialysis   chronic kidney disease, has home dialysis clinic." FOLDED="true"/>
          <node TEXT="Amy Alexander - APRN - Indianapolis and Louisville dialysis, chronic kidney disease at Broadway office." FOLDED="true"/>
        </node>
        <node TEXT="Interactive Element" FOLDED="true">
          <node TEXT="Pay Now" LINK="https://pay.streampay.streamlinepayments.com/#/qGCdZ%2525252fgjyNI27uT4rpznnqbbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/qGCdZ%2525252fgjyNKnJggufIU%2525252fwabbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/pay" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_pay.streampay.streamlinepayments.com_qGCdZ_2525252fgjyNI27uT4rpznnqbbCvtkqi0l_2525252f_2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1_qGCdZ_2525252fgjyN.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_our-providers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Clinic Locations" LINK="https://kidneycareconsultants.com/clinic-locations/" FOLDED="true">
        <node TEXT="KIDNEY CARE CONSULTANTS MD CLINICS" FOLDED="true">
          <node TEXT="Broadway (Main Office)" FOLDED="true">
            <node TEXT="716 West Broadway Louisville, Ky 40202" FOLDED="true">
              <node TEXT="Map Link" LINK="https://maps.app.goo.gl/vMLRTbWBb73xrRdT8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_vMLRTbWBb73xrRdT8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Phone: (866) 995-7667" FOLDED="true">
              <node TEXT="Call" LINK="tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="Phone: 502-595-7007" FOLDED="true">
              <node TEXT="Call" LINK="tel:502-595-7007" FOLDED="true"/>
            </node>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Directions" LINK="https://maps.app.goo.gl/vMLRTbWBb73xrRdT8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_vMLRTbWBb73xrRdT8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Dixie Clinic (Dr Nair’ Office)" FOLDED="true">
            <node TEXT="8442 Dixie Hwy, Louisville, KY 40258" FOLDED="true">
              <node TEXT="Map Link" LINK="https://maps.app.goo.gl/T6ryZbveF2EgYb3b6" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_T6ryZbveF2EgYb3b6.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Directions" LINK="https://maps.app.goo.gl/T6ryZbveF2EgYb3b6" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_T6ryZbveF2EgYb3b6.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="HCH Medical Pavilion" FOLDED="true">
            <node TEXT="1263 Hospital Drive NW, Suite 100 Corydon, In 47112" FOLDED="true">
              <node TEXT="Map Link" LINK="https://maps.app.goo.gl/LYQzsonJqfKjUKMWA" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_LYQzsonJqfKjUKMWA.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Phone: 502- 425-9121" FOLDED="true">
              <node TEXT="Call" LINK="tel:502- 425-9121" FOLDED="true"/>
            </node>
            <node TEXT="Phone: 502-425-9161" FOLDED="true">
              <node TEXT="Call" LINK="tel:502-425-9161" FOLDED="true"/>
            </node>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Directions" LINK="https://maps.app.goo.gl/LYQzsonJqfKjUKMWA" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_LYQzsonJqfKjUKMWA.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Dixie Highway Office" FOLDED="true">
            <node TEXT="8037 Dixie Highway Louisville, KY 40258" FOLDED="true">
              <node TEXT="Map Link" LINK="https://maps.app.goo.gl/1Ez5o1G4wngrZHMi8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_1Ez5o1G4wngrZHMi8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Phone: (866) 995-7667" FOLDED="true">
              <node TEXT="Call" LINK="tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="Phone: 502-595-7007" FOLDED="true">
              <node TEXT="Call" LINK="tel:502-595-7007" FOLDED="true"/>
            </node>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Directions" LINK="https://maps.app.goo.gl/1Ez5o1G4wngrZHMi8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_1Ez5o1G4wngrZHMi8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Carrollton Office" FOLDED="true">
            <node TEXT="309 Eleventh Street Carrollton, KY 41008" FOLDED="true">
              <node TEXT="Map Link" LINK="https://maps.app.goo.gl/cYj5YZwrxVWUJBYH6" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_cYj5YZwrxVWUJBYH6.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Phone: (866) 995-7667" FOLDED="true">
              <node TEXT="Call" LINK="tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="Phone: 502-425-9161" FOLDED="true">
              <node TEXT="Call" LINK="tel:502-425-9161" FOLDED="true"/>
            </node>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Directions" LINK="https://maps.app.goo.gl/cYj5YZwrxVWUJBYH6" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_cYj5YZwrxVWUJBYH6.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Olympia Park Office" FOLDED="true">
            <node TEXT="9720 Park Plaza Avenue Ste.104 Louisville, Ky 40241" FOLDED="true">
              <node TEXT="Map Link" LINK="https://maps.app.goo.gl/J7vyd9ZC1zhVwipw9" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_J7vyd9ZC1zhVwipw9.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Phone: 502- 425-9121" FOLDED="true">
              <node TEXT="Call" LINK="tel:502- 425-9121" FOLDED="true"/>
            </node>
            <node TEXT="Phone: 502-425-9161" FOLDED="true">
              <node TEXT="Call" LINK="tel:502-425-9161" FOLDED="true"/>
            </node>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Directions" LINK="https://maps.app.goo.gl/J7vyd9ZC1zhVwipw9" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_J7vyd9ZC1zhVwipw9.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        </node>
        <node TEXT="Load More Button" FOLDED="true">
          <node TEXT="LOAD MORE" FOLDED="true"/>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_clinic-locations.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Patient Forms" LINK="https://kidneycareconsultants.com/patient-forms/" FOLDED="true">
        <node TEXT="Page Introduction" FOLDED="true">
          <node TEXT="Make Your Visit Faster   Easier" FOLDED="true"/>
        </node>
        <node TEXT="Form Instructions" FOLDED="true">
          <node TEXT="Download, fill out and bring the form to appointment" FOLDED="true"/>
        </node>
        <node TEXT="DOWNLOAD FORM" FOLDED="true">
          <node TEXT="Download Form PDF" FOLDED="true">
            <node TEXT="Link: kidneycareconsultants Patient Forms" LINK="https://kidneycareconsultants.com/wp-content/uploads/2025/08/kidneycareconsultants-Patient-Forms.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_wp-content_uploads_2025_08_kidneycareconsultants-Patient-Forms.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_patient-forms.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Contact Us" LINK="https://kidneycareconsultants.com/contact-us/" FOLDED="true">
        <node TEXT="Main Office Location" FOLDED="true">
          <node TEXT="716 West Broadway Louisville, Ky 40202" FOLDED="true">
            <node TEXT="Get Directions" LINK="https://maps.app.goo.gl/vMLRTbWBb73xrRdT8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_vMLRTbWBb73xrRdT8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="866-995-7667" LINK="tel:8669957667" FOLDED="true"/>
          <node TEXT="502-595-7007" LINK="tel:502-595-7007" FOLDED="true"/>
        </node>
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="Full Name" FOLDED="true"/>
          <node TEXT="Email Address" FOLDED="true"/>
          <node TEXT="Phone Number" FOLDED="true"/>
          <node TEXT="Your Location" FOLDED="true"/>
          <node TEXT="Message" FOLDED="true"/>
          <node TEXT="SUBMIT" FOLDED="true"/>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_contact-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Schedule an appointment" LINK="https://kidneycareconsultants.com/schedule-an-appointment/" FOLDED="true">
        <node TEXT="Appointment Request Form" FOLDED="true">
          <node TEXT="Patient Full Name*" FOLDED="true"/>
          <node TEXT="Address*" FOLDED="true"/>
          <node TEXT="Phone number*" FOLDED="true"/>
          <node TEXT="Email Address*" FOLDED="true"/>
          <node TEXT="Major Illness*" FOLDED="true"/>
          <node TEXT="Message" FOLDED="true"/>
          <node TEXT="CONNECT Button" FOLDED="true"/>
        </node>
        <node TEXT="Our Locations - Find a Clinic Near You" FOLDED="true">
          <node TEXT="Broadway (Main Office)" FOLDED="true">
            <node TEXT="716 West Broadway Louisville, Ky 40202" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/vMLRTbWBb73xrRdT8" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/vMLRTbWBb73xrRdT8" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Dixie Clinic (Dr Nair' Office)" FOLDED="true">
            <node TEXT="8442 Dixie Hwy, Louisville, KY 40258" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/T6ryZbveF2EgYb3b6" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/T6ryZbveF2EgYb3b6" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="HCH Medical Pavilion" FOLDED="true">
            <node TEXT="1263 Hospital Drive NW, Suite 100 Corydon, In 47112" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/LYQzsonJqfKjUKMWA" FOLDED="true"/>
            </node>
            <node TEXT="502- 425-9121" FOLDED="true">
              <node TEXT="Link: tel:502- 425-9121" FOLDED="true"/>
            </node>
            <node TEXT="502-425-9161" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/LYQzsonJqfKjUKMWA" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Dixie Highway Office" FOLDED="true">
            <node TEXT="8037 Dixie Highway Louisville, KY 40258" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/1Ez5o1G4wngrZHMi8" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/1Ez5o1G4wngrZHMi8" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Carrollton Office" FOLDED="true">
            <node TEXT="309 Eleventh Street Carrollton, KY 41008" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/cYj5YZwrxVWUJBYH6" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-425-9161" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/cYj5YZwrxVWUJBYH6" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Park Plaza Office" FOLDED="true">
            <node TEXT="9720 Park Plaza Avenue Ste.104 Louisville, Ky 40241" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/J7vyd9ZC1zhVwipw9" FOLDED="true"/>
            </node>
            <node TEXT="502- 425-9121" FOLDED="true">
              <node TEXT="Link: tel:502- 425-9121" FOLDED="true"/>
            </node>
            <node TEXT="502-425-9161" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/J7vyd9ZC1zhVwipw9" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Corydon Office" FOLDED="true">
            <node TEXT="313 Federal Dr. Suite. 150 Corydon, in 47112" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/NrxPajdYCWFYP9XX7" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/NrxPajdYCWFYP9XX7" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Lagrange Office" FOLDED="true">
            <node TEXT="1023 New Moody Lane Ste. 202 Lagrange, Ky 40031" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/9im9Q1q8Y4CaiTtq7" FOLDED="true"/>
            </node>
            <node TEXT="502- 425-9121" FOLDED="true">
              <node TEXT="Link: tel:502- 425-9121" FOLDED="true"/>
            </node>
            <node TEXT="502-425-9161" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/9im9Q1q8Y4CaiTtq7" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Scottsburg Office" FOLDED="true">
            <node TEXT="1473 N Gardner Street Suite A Scottsburg IN. 47170" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/xW33sXYvVRmuqPV19" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/xW33sXYvVRmuqPV19" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Clark/jeffersonville" FOLDED="true">
            <node TEXT="Medical Arts Building 207 Sparks Avenue. Suite 404 Jeffersonville, Indiana 47130" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/jK44P1ExsdEcdAM38" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/jK44P1ExsdEcdAM38" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Jewish South Office" FOLDED="true">
            <node TEXT="1903 Hebron Lane Ste.202 Shepherdsville, Ky 40165" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/ZquPtWDHonUbBYmFA" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/ZquPtWDHonUbBYmFA" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="St. Matthews" FOLDED="true">
            <node TEXT="4001 Kresge Way Suite 325 Louisville, Ky 40207" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/TCk3or4SbLnczfVB9" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/TCk3or4SbLnczfVB9" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Floyd/New Albany Office" FOLDED="true">
            <node TEXT="1919 State Street Ste 444 New Albany, in 47150" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/JEggAFEJpZVXSQAbA" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/JEggAFEJpZVXSQAbA" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="J-Town Medical Center" FOLDED="true">
            <node TEXT="10216 Taylorsville Rd. Suite 850 Louisville, Ky 40299" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/5y9makFPEH1SJ5ii6" FOLDED="true"/>
            </node>
            <node TEXT="(866) 995-7667" FOLDED="true">
              <node TEXT="Link: tel:8669957667" FOLDED="true"/>
            </node>
            <node TEXT="502-595-7007" FOLDED="true"/>
            <node TEXT="Get Directions" FOLDED="true">
              <node TEXT="Link: https://maps.app.goo.gl/5y9makFPEH1SJ5ii6" FOLDED="true"/>
            </node>
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_schedule-an-appointment.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Pay Now" LINK="https://pay.streampay.streamlinepayments.com/#/qGCdZ%2525252fgjyNI27uT4rpznnqbbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/qGCdZ%2525252fgjyNKnJggufIU%2525252fwabbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/pay" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_pay.streampay.streamlinepayments.com_qGCdZ_2525252fgjyNI27uT4rpznnqbbCvtkqi0l_2525252f_2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1_qGCdZ_2525252fgjyN.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Phone" LINK="tel:8669957667" FOLDED="true"/>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Clinic locations" LINK="https://kidneycareconsultants.com/clinic-locations/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_clinic-locations.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Patient Forms" LINK="https://kidneycareconsultants.com/patient-forms/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_patient-forms.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Pay Now" LINK="https://pay.streampay.streamlinepayments.com/#/qGCdZ%2525252fgjyNI27uT4rpznnqbbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/qGCdZ%2525252fgjyNKnJggufIU%2525252fwabbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/pay" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_pay.streampay.streamlinepayments.com_qGCdZ_2525252fgjyNI27uT4rpznnqbbCvtkqi0l_2525252f_2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1_qGCdZ_2525252fgjyN.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Privacy Policy" LINK="https://kidneycareconsultants.com/wp-content/uploads/2024/03/KCCNOTICEOFPRIVACYPRACTICESREVISED9-2013.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_kidneycareconsultants.com_wp-content_uploads_2024_03_KCCNOTICEOFPRIVACYPRACTICESREVISED9-2013.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
  </node>
</map>
