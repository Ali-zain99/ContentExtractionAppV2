<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
    <node TEXT="patient forms">
        <node TEXT="Page Introduction">
            <node TEXT="Make Your Visit Faster   Easier" />
        </node>
        <node TEXT="Form Instructions">
            <node TEXT="Download, fill out and bring the form to appointment" />
        </node>
        <node TEXT="DOWNLOAD FORM">
            <node TEXT="Download Form PDF">
                <node TEXT="Link: kidneycareconsultants Patient Forms" LINK="https://kidneycareconsultants.com/wp-content/uploads/2025/08/kidneycareconsultants-Patient-Forms.pdf" />
            </node>
        </node>
    </node>
</map>