<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="our providers">
    <node TEXT="Provider Directory">
      <node TEXT="Ashwin Dixit - MD - Cares for dialysis   chronic kidney disease patients in south Louisville   Shepherdsville." />
      <node TEXT="David Fendley - MD - Southern Indiana practice, home dialysis in Jeffersonville, also serves Dixie Highway area." />
      <node TEXT="Luisa Franco - MD - Outpatient office and home dialysis, cares for patients in Carrollton and Jeffersontown." />
      <node TEXT="Salgram Jaisinghani - MD - Board-certified, new patients for chronic kidney disease, hypertension, imbalances, glomerular diseases." />
      <node TEXT="Leslie Wood - MD - Downtown and Shelbyville, cares for hemodialysis   chronic kidney disease, has home dialysis clinic." />
      <node TEXT="Amy Alexander - APRN - Indianapolis and Louisville dialysis, chronic kidney disease at Broadway office." />
      
    </node>
    <node TEXT="Interactive Element">
      <node TEXT="Pay Now">
        <node TEXT="https://pay.streampay.streamlinepayments.com/#/qGCdZ%2525252fgjyNI27uT4rpznnqbbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/qGCdZ%2525252fgjyNKnJggufIU%2525252fwabbCvtkqi0l%2525252f%2525252b6ZrcaTl8XiN9AeAWsKi7hacOhtyAH1/pay" />
      </node>
    </node>
  </node>
</map>