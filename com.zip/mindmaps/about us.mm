<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="about us">
    <node TEXT="About Us Introduction">
      <node TEXT="Company purpose: Premium home cleaning in Melbourne" />
      <node TEXT="Why Us: Client care, service details, extra mile" />
    </node>
    <node TEXT="Our Team   Onboarding">
      <node TEXT="Team trust and onboarding process overview" />
      <node TEXT="Onboarding Steps">
        <node TEXT="Application" />
        <node TEXT="Questionnaire test" />
        <node TEXT="Phone Screening" />
        <node TEXT="Face to Face interview" />
        <node TEXT="Trial clean" />
        <node TEXT="Police and background check" />
        <node TEXT="Professional reference check" />
      </node>
    </node>
    <node TEXT="Pet Friendly Message">
      <node TEXT="Hi there, my name is Nala - Team loves animals and is 100% pet friendly!" />
      <node TEXT="Book Now">
        <node TEXT="https://crystalmaids.com.au/booking-page/" />
      </node>
    </node>
  </node>
</map>