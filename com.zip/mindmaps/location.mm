<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="location">
    <node TEXT="Our Locations Overview">
      <node TEXT="Service area map and company rating summary" />
    </node>
    <node TEXT="Main Service Areas">
      <node TEXT="Eastern Suburbs">
        <node TEXT="Link" LINK="https://crystalmaids.com.au/eastern-suburbs-house-cleaning/" />
      </node>
      <node TEXT="Brighton East">
        <node TEXT="Link" LINK="https://crystalmaids.com.au/brighton-east-house-cleaning/" />
      </node>
      <node TEXT="Brighton">
        <node TEXT="Link" LINK="https://crystalmaids.com.au/brighton-house-cleaning/" />
      </node>
      <node TEXT="Hawthorn">
        <node TEXT="Link" LINK="https://crystalmaids.com.au/hawthorn-house-cleaning/" />
      </node>
      <node TEXT="Malvern East">
        <node TEXT="Link" LINK="https://crystalmaids.com.au/malvern-east-house-cleaning/" />
      </node>
    </node>
  </node>
</map>