<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="checklist">
    <node TEXT="Crystal Maids Checklist sections summary">
      <node TEXT="Kitchen - cleaning appliances, surfaces, bins, and floors" />
      <node TEXT="Bathrooms - clean mirrors, fixtures, tub, and floors" />
      <node TEXT="Common Areas - dust, clean mirrors, vacuum, tidy area" />
      <node TEXT="Bedrooms - dust, clean mirrors, tidy beds and floors" />
      <node TEXT="Deep Cleaning - extra detail for kitchen and bathrooms" />
      <node TEXT="End of Lease Cleaning - inside drawers, ceiling fans, oven" />
      <node TEXT="Additional Services - oven, fridge, green/disinfectant supplies" />
    </node>
    <node TEXT="Book Now">
      <node TEXT="Book Now link" LINK="https://crystalmaids.com.au/booking-page/" />
    </node>
  </node>
</map>