<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="help">
    <node TEXT="Frequently Asked Questions">
      <node TEXT="Do you service my area?" />
      <node TEXT="What is included in a general cleaning?" />
      <node TEXT="How much will it cost?" />
      <node TEXT="Do you bring your own cleaning equipment and supplies?" />
      <node TEXT="Can I request special tasks or extras?" />
      <node TEXT="How do I reset my password?" />
      <node TEXT="How do I book my first appointment?" />
      <node TEXT="Can I apply a coupon to an existing appointment?" />
      <node TEXT="Can I trust my cleaning professional?" />
      <node TEXT="What happens if something goes wrong during my appointment?" />
      <node TEXT="What is your 200% satisfaction guarantee policy?" />
      <node TEXT="Can you use green products on request?" />
      <node TEXT="Is it okay that I have pets in the home?" />
      <node TEXT="Does end of lease cleaning come with a Bond Guarantee?" />
      <node TEXT="Do you do carpet steam cleaning?" />
      <node TEXT="What is included in an end of lease clean?" />
      <node TEXT="What is the difference between a General clean and a Deep clean?" />
      <node TEXT="Do I need to be home during the service?" />
      <node TEXT="Do you clean balconies?" />
      <node TEXT="Do you have discounts for regular clients?" />
      <node TEXT="Do you do laundry?" />
      <node TEXT="What is the difference with disinfectant cleaning?" />
    </node>
  </node>
</map>