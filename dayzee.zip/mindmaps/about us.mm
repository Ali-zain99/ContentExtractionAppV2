<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
    <node TEXT="about us">
        <node TEXT="DayZee Farms Began with a Bold Idea">
            <node TEXT="Introduction to DayZee Farms vision and origins in Pakistan" />
            <node TEXT="We launched DayZee Livestock, DayZee Agriculture, Solar installation, and Intersection of science and soil as key initiatives" />
        </node>
        <node TEXT="Our Impact on the UN Sustainable Development Goals (SDGs)">
            <node TEXT="Overview of DayZee Farms contribution to multiple UN SDGs" />
            <node TEXT="Highlights of SDG 2 Zero Hunger, SDG 7 Affordable and Clean Energy, SDG 9 Industry Innovation and Infrastructure, SDG 12 Responsible Consumption and Production, and SDG 13 Climate Action initiatives" />
        </node>
        <node TEXT="Get in touch Let’s Get Started">
            <node TEXT="Contact form to connect with DayZee for farming and livestock solutions">
                <node TEXT="First Name*" />
                <node TEXT="Last Name*" />
                <node TEXT="Email*" />
                <node TEXT="Mobile Number*" />
                <node TEXT="Company Name" />
                <node TEXT="City (dropdown example: Karachi)" />
                <node TEXT="Country" />
                <node TEXT="Interested In" />
                <node TEXT="Message" />
                <node TEXT="SUBMIT" />
            </node>
        </node>
        <node TEXT="DayZee agriculture summary">
            <node TEXT="Brief description of DayZee’s role in revolutionizing Pakistan’s agriculture with genetics, sustainable practices, and turnkey solutions" />
        </node>
    </node>
</map>