<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="renewable energy">
    <node TEXT="Main Content">
      <node TEXT="Hero Section - Renewable Energy Overview">
        <node TEXT="Headline: RENEWABLE ENERGY" />
        <node TEXT="Subheading: Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" />
      </node>
      <node TEXT="Solar Panel Infrastructure">
        <node TEXT="Summary: 6MW solar panel system powering farm operations, irrigation, and livestock with clean, cost-effective energy while cutting carbon emissions and costs." />
      </node>
      <node TEXT="Our Biogas Plant">
        <node TEXT="Summary: Converts organic farm waste into biogas for power and heat, reducing methane emissions and waste while supporting a circular economy." />
      </node>
      <node TEXT="Operational Metrics">
        <node TEXT="500 Delivered Packages" />
        <node TEXT="500 Global Shipping" />
        <node TEXT="500 Air Freight" />
        <node TEXT="500 Happy Customers" />
      </node>
      <node TEXT="Corporate Social Responsibility (CSR)">
        <node TEXT="Empowering Rural Communities - Creating sustainable jobs and uplifting local families." />
        <node TEXT="Farmer Development - Training on modern farming, IVF, and animal husbandry." />
        <node TEXT="Environmental Stewardship - Solar and biogas projects reducing emissions and promoting sustainable agribusiness." />
        <node TEXT="Animal Ethics   Welfare - High welfare standards focused on nutrition, care, and ethical reproduction." />
      </node>
      <node TEXT="Get in touch – Let’s Get Started">
        <node TEXT="Summary: Invitation to connect with DayZee for expert farming and livestock solutions." />
      </node>
    </node>
    <node TEXT="Forms">
      <node TEXT="Contact Form">
        <node TEXT="First Name*" />
        <node TEXT="Last Name*" />
        <node TEXT="Email*" />
        <node TEXT="Mobile Number*" />
        <node TEXT="Company Name" />
        <node TEXT="City (Dropdown - e.g., Karachi)" />
        <node TEXT="Country" />
        <node TEXT="Interested In" />
        <node TEXT="Message" />
        <node TEXT="Submit Button" />
      </node>
    </node>
    <node TEXT="Buttons">
      <node TEXT="SUBMIT">
        <node TEXT="Submit contact form" />
      </node>
    </node>
  </node>
</map>