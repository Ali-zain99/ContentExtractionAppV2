<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
    <node TEXT="livestock">
        <node TEXT="Hero - Superior Genetics for Tomorrow">
            <node TEXT="Intro summary: Imported Brahman, Beefmaster, Slick Friesians   Red Angus for superior performance in Pakistan." />
            <node TEXT="REQUEST SEMEN/EMBRYO">
                <node TEXT="tel:+923314476666" />
            </node>
            <node TEXT="BOOK A CONSULTATION">
                <node TEXT="tel:+923314431111" />
            </node>
            <node TEXT="BOOK OPU OF YOUR COW NOW">
                <node TEXT="tel:+923314431111" />
            </node>
        </node>
        <node TEXT="About Our Genetics">
            <node TEXT="Overview: Highlight of elite cattle genetics options and their key benefits." />
            <node TEXT="Genetic Breeds">
                <node TEXT="Slick Gene Frisien - Heat-resistant Friesian with high daily milk yield." />
                <node TEXT="Brahman - Imported JDH line, heavy growth and beef-focused." />
                <node TEXT="Beefmaster - Fertility, rapid weight gain and carcass quality for premium beef." />
                <node TEXT="Red Angus - High fertility, easy calving and premium beef marbling." />
            </node>
        </node>
        <node TEXT="Our Services">
            <node TEXT="Overview: Core livestock genetics services offered to farmers." />
            <node TEXT="Service Cards">
                <node TEXT="Semen Availability - High-performing, climate-adapted bulls for fertility, milk yield and meat quality." />
                <node TEXT="Embryo Transfer Pregnancies - IVF lab producing elite embryos and monitored pregnancies." />
                <node TEXT="Pregnant Heifers for Sale - Biosecure, pregnancy-verified and health-certified heifers." />
                <node TEXT="Genetics Consultation - Expert guidance from sire selection to embryo strategy." />
            </node>
        </node>
        <node TEXT="OPU Promotion - 20+ calves from one elite donor cow">
            <node TEXT="Summary: Explains Ovum Pickup (OPU) and IVF to multiply top genetics at scale." />
            <node TEXT="Book OPU Now">
                <node TEXT="tel:+92314431111" />
            </node>
        </node>
        <node TEXT="Explore Our Genetic Catalogue">
            <node TEXT="Summary: Visual strip of cattle images inviting users to browse catalogues." />
            <node TEXT="Catalogue Links">
                <node TEXT="Brahman Catalogue">
                    <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" />
                </node>
                <node TEXT="Slick-Gene Friesian Catalogue">
                    <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" />
                </node>
                <node TEXT="Beefmaster Catalogue">
                    <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" />
                </node>
                <node TEXT="Red Angus Catalogue">
                    <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" />
                </node>
            </node>
        </node>
        <node TEXT="Our Global Partners">
            <node TEXT="Summary: Logos of international universities and ranches backing their genetics." />
        </node>
        <node TEXT="Get in touch – Let’s Get Started">
            <node TEXT="Summary: Invitation to connect for expert farming and livestock solutions." />
            <node TEXT="Contact Form">
                <node TEXT="First Name*" />
                <node TEXT="Last Name*" />
                <node TEXT="Email*" />
                <node TEXT="Mobile Number*" />
                <node TEXT="Company Name" />
                <node TEXT="City (dropdown, example: Karachi)" />
                <node TEXT="Country" />
                <node TEXT="Interested In" />
                <node TEXT="Message" />
                <node TEXT="SUBMIT" />
            </node>
        </node>
        <node TEXT="Media   Social">
            <node TEXT="Watch Now on Youtube">
                <node TEXT="https://youtu.be/onr1r1d5sMQ?si=xUzEGMC-z_rTKtzG" />
            </node>
            <node TEXT="Subscribe to our channel">
                <node TEXT="https://www.youtube.com/@DayZeeFarms" />
            </node>
        </node>
    </node>
</map>