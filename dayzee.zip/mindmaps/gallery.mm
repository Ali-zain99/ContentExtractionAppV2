<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
    <node TEXT="gallery">
        <node TEXT="Image Gallery Section">
            <node TEXT="IMAGE GALLERY - visual showcase of DayZee activities and facilities" />
            <node TEXT="Gallery Items - thumbnails linking to detailed event galleries">
                <node TEXT="DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025">
                    <node TEXT="Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/" />
                </node>
                <node TEXT="Chinese Delegation at DayZee (Private) Limited">
                    <node TEXT="Link" LINK="https://dayzee.com/gallery/chinese-delegation/" />
                </node>
            </node>
        </node>
        <node TEXT="Get in touch – Contact Form Section">
            <node TEXT="Intro Text - Invitation to connect for expert farming and livestock solutions" />
            <node TEXT="Contact Form">
                <node TEXT="First Name*" />
                <node TEXT="Last Name*" />
                <node TEXT="Email*" />
                <node TEXT="Mobile Number*" />
                <node TEXT="Company Name" />
                <node TEXT="City - dropdown (e.g., Karachi)" />
                <node TEXT="Country" />
                <node TEXT="Interested In" />
                <node TEXT="Message" />
                <node TEXT="Button">
                    <node TEXT="SUBMIT" />
                </node>
            </node>
        </node>
    </node>
</map>