<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
    <node TEXT="contact us">
        <node TEXT="Contact Information">
            <node TEXT="Our Office - DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur.">
                <node TEXT="Location Link">
                    <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur." LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66" />
                </node>
            </node>
            <node TEXT="Call Us - Phone numbers for contact">
                <node TEXT="Phone 1" LINK="tel:0331 443 1111">
                    <node TEXT="0331-443 1111" />
                </node>
                <node TEXT="Phone 2" LINK="tel:0331 447 66 66">
                    <node TEXT="0331-447 6666" />
                </node>
            </node>
            <node TEXT="Email Address - Primary contact email">
                <node TEXT="info@dayzee.com" LINK="mailto:info@dayzee.com" />
            </node>
        </node>
        <node TEXT="Contact Form and Map">
            <node TEXT="Location Map - Embedded map showing DayZee Farms" />
            <node TEXT="Get in touch Let’s Get Started Form">
                <node TEXT="First Name*" />
                <node TEXT="Last Name*" />
                <node TEXT="Email*" />
                <node TEXT="Mobile Number*" />
                <node TEXT="Company Name" />
                <node TEXT="City Dropdown - Karachi selected" />
                <node TEXT="Country" />
                <node TEXT="Interested In" />
                <node TEXT="Message" />
                <node TEXT="Submit Button">
                    <node TEXT="SUBMIT" />
                </node>
            </node>
        </node>
    </node>
</map>