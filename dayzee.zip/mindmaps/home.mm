<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Dayzee">
    <node TEXT="Header">
      <icon BUILTIN="bookmark" />
      <node TEXT="Logo">
        <icon BUILTIN="image" />
        <node TEXT="DayZee" LINK="https://dayzee.com/" />
      </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content" />
      <node TEXT="Main Navigation">
        <icon BUILTIN="list" />
        <node TEXT="About Us" LINK="https://dayzee.com/about/" />
        <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/" />
        <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/" />
        <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/" />
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" />
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" />
      </node>
    </node>
    <node TEXT="Home Page Content">
      <icon BUILTIN="image" />
      <node TEXT="Hero Section">
        <icon BUILTIN="image" />
        <node TEXT="Background Image - Green Field   Irrigation" />
        <node TEXT="Title: AGRICULTURE" />
        <node TEXT="Subtitle: Innovating Modern Farming" />
      </node>
      <node TEXT="Livestock Section">
        <icon BUILTIN="image" />
        <node TEXT="Heading: LIVESTOCK" />
        <node TEXT="Subheading: In Elite Genetics for Unmatched Livestock Performance" />
        <node TEXT="Description">
          <node TEXT="DayZee Farms is transforming cattle farming in Pakistan through advanced reproductive biotechnology and elite imported genetics." />
        </node>
        <node TEXT="Button: LEARN MORE" LINK="https://dayzee.com/live-stock/" />
        <node TEXT="Programs Cards">
          <icon BUILTIN="list" />
          <node TEXT="Invitro Fertilization Program">
            <icon BUILTIN="image" />
            <node TEXT="Card Icon" />
            <node TEXT="Description: IVF Lab setting new standards in cattle and livestock breeding in Pakistan." />
          </node>
          <node TEXT="Artificial Insemination Program">
            <icon BUILTIN="image" />
            <node TEXT="Card Icon" />
            <node TEXT="Description: AI Program uses elite global genetics and advanced CASA technology." />
          </node>
          <node TEXT="Genetics Lab">
            <icon BUILTIN="image" />
            <node TEXT="Card Icon" />
            <node TEXT="Description: Genetics Lab sequences animal DNA to identify superior genetics." />
          </node>
        </node>
        <node TEXT="Benefits">
          <icon BUILTIN="list" />
          <node TEXT="Heat Tolerance">
            <icon BUILTIN="image" />
            <node TEXT="Description: Perfect for Pakistan’s climate." />
          </node>
          <node TEXT="Fertility   Productivity">
            <icon BUILTIN="image" />
            <node TEXT="Description: Maximize your herd’s potential." />
          </node>
          <node TEXT="Long-Term Profitability">
            <icon BUILTIN="image" />
            <node TEXT="Description: Higher quality offspring with market-leading traits." />
          </node>
        </node>
      </node>
      <node TEXT="Agriculture Section">
        <icon BUILTIN="image" />
        <node TEXT="Heading: Agriculture" />
        <node TEXT="Subheading: Turning Barren Land into Agricultural Gold" />
        <node TEXT="Description">
          <node TEXT="Restoring Pakistan’s soil by converting 4,200 acres of barren land into fertile farmland using state-of-the-art irrigation and sustainable farming techniques." />
        </node>
        <node TEXT="Button: LEARN MORE" LINK="https://dayzee.com/agriculture/" />
        <node TEXT="Agriculture Services Cards">
          <icon BUILTIN="list" />
          <node TEXT="Pivot Irrigation">
            <icon BUILTIN="image" />
            <node TEXT="Description: Exclusive dealer of AFKO Industries’ center-pivot and linear-move irrigation systems in Pakistan." />
          </node>
          <node TEXT="Mechanized Farming">
            <icon BUILTIN="image" />
            <node TEXT="Description: Use of state-of-the-art farm machinery and mechanization services." />
          </node>
          <node TEXT="Premium Animal Fodder">
            <icon BUILTIN="image" />
            <node TEXT="Description: Cultivation of Rhode grass, alfalfa, and other premium fodders with export focus." />
          </node>
        </node>
      </node>
      <node TEXT="Renewable Energy Section">
        <icon BUILTIN="image" />
        <node TEXT="Heading: Renewable Energy" />
        <node TEXT="Subheading: Sustainable and Smart Agriculture" />
        <node TEXT="Button: EXPLORE OUR SUSTAINABILITY" LINK="https://dayzee.com/renewable-energy/" />
        <node TEXT="Energy Solutions Cards">
          <icon BUILTIN="list" />
          <node TEXT="Solar Powered Future">
            <icon BUILTIN="image" />
            <node TEXT="Subtitle: 6.6 MW Clean Energy" />
            <node TEXT="Description: Harnessing solar power for water, pivot rotation, and farm operations." />
          </node>
          <node TEXT="Biogas To Energy">
            <icon BUILTIN="image" />
            <node TEXT="Subtitle: 2.2 MW from Organic Waste" />
            <node TEXT="Description: Transforming farm waste into reliable green power." />
          </node>
        </node>
      </node>
      <node TEXT="Contact Section">
        <icon BUILTIN="image" />
        <node TEXT="Heading: Get in touch Let’s Get Started" />
        <node TEXT="Description: Connect with DayZee for expert farming and livestock solutions." />
        <node TEXT="Contact Form">
          <icon BUILTIN="edit" />
          <node TEXT="Field: First Name*" />
          <node TEXT="Field: Last Name*" />
          <node TEXT="Field: Email*" />
          <node TEXT="Field: Mobile Number*" />
          <node TEXT="Field: Company Name" />
          <node TEXT="Dropdown: City (e.g., Karachi)" />
          <node TEXT="Field: Country" />
          <node TEXT="Dropdown: Interested In" />
          <node TEXT="Textarea: Message" />
          <node TEXT="Button: SUBMIT" />
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <icon BUILTIN="bookmark" />
      <node TEXT="Brand Summary">
        <icon BUILTIN="image" />
        <node TEXT="Logo" />
        <node TEXT="Description: Revolutionizing Pakistan’s agriculture with elite livestock genetics, sustainable farming, and innovative irrigation solutions." />
      </node>
      <node TEXT="Company Links">
        <icon BUILTIN="list" />
        <node TEXT="Home" LINK="https://dayzee.com/" />
        <node TEXT="Services" LINK="https://dayzee.com/service/" />
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" />
      </node>
      <node TEXT="Quick Links">
        <icon BUILTIN="list" />
        <node TEXT="About Us" LINK="https://dayzee.com/about/" />
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" />
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs" />
      </node>
      <node TEXT="Follow us at">
        <icon BUILTIN="list" />
        <node TEXT="Facebook - DayZee Farms" LINK="https://www.facebook.com/dayzeefarm" />
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd" />
        <node TEXT="Instagram - DayZee Farms" LINK="https://www.instagram.com/dayzeefarms/" />
        <node TEXT="Youtube - DayZee Farms" LINK="https://www.youtube.com/@DayZeeFarms" />
      </node>
      <node TEXT="Copyright">
        <node TEXT="Copyright © 2025 DayZee. All Rights Reserved" />
      </node>
    </node>
  </node>
</map>