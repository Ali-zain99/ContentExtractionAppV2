<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="agriculture">
    <node TEXT="Hero Section - Transforming 4,200 Barren Acres">
      <node TEXT="Headline   Subheadline - Sustainable livestock and agricultural hub in Cholistan desert" />
    </node>
    <node TEXT="A New Era of Desert Farming">
      <node TEXT="Overview - DayZee Farms converting barren desert into productive agricultural hub using innovative irrigation and fodder crops" />
    </node>
    <node TEXT="Barren Land Transformation">
      <node TEXT="Timeline Images - April 2024, March 2025, May 2025 showing land development progress" />
    </node>
    <node TEXT="Technology In Agriculture">
      <node TEXT="Irrigation Systems - Central pivot irrigation with current and planned installations" />
      <node TEXT="Mechanized Farm Machinery - State-of-the-art equipment for efficient farm operations" />
      <node TEXT="Solar Power Plant - 6MW solar plant to power all farm activities" />
    </node>
    <node TEXT="Our Products">
      <node TEXT="Alfalfa - High-yield, nutrient-rich forage crop for dairy and beef cattle" />
      <node TEXT="Rhodes Grass - Drought-resistant grass optimized for livestock nutrition" />
    </node>
    <node TEXT="Our Services">
      <node TEXT="Land Development - Converting barren or underutilized land into productive farmland" />
      <node TEXT="Center Pivot Irrigation Systems - Design, installation, and maintenance for efficient water use" />
      <node TEXT="Farm Operations - End-to-end mechanized crop cycle management" />
      <node TEXT="Integrated Farm Management - Planning, execution, and monitoring of agricultural operations" />
      <node TEXT="Irrigation   Infrastructure Consultancy - Advisory for large-scale, water-efficient farming systems" />
    </node>
    <node TEXT="Our Global Partners">
      <node TEXT="Partner Logos - MQ Holding Group LLC, AFKO, Ozduman, Krone supporting genetics and technology" />
    </node>
    <node TEXT="Get in touch – Let’s Get Started">
      <node TEXT="Contact Form">
        <node TEXT="First Name* (text field)" />
        <node TEXT="Last Name* (text field)" />
        <node TEXT="Email* (text field)" />
        <node TEXT="Mobile Number* (text field)" />
        <node TEXT="Company Name (text field)" />
        <node TEXT="City (dropdown - example: Karachi)" />
        <node TEXT="Country (text field)" />
        <node TEXT="Interested In (text field or dropdown)" />
        <node TEXT="Message (textarea)" />
        <node TEXT="SUBMIT (button)" />
      </node>
    </node>
  </node>
</map>