<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home Page">
    <node TEXT="Header">
      <icon BUILTIN="bookmark" />
      <node TEXT="Logo">
        <icon BUILTIN="image" />
        <node TEXT="DayZee" LINK="https://dayzee.com/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_content.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Main Navigation">
        <icon BUILTIN="list" />
      </node>
    </node>
    <node TEXT="About Us" LINK="https://dayzee.com/about/">
      <node TEXT="DayZee Farms Began with a Bold Idea">
        <node TEXT="Introduction to DayZee Farms vision and origins in Pakistan" />
        <node TEXT="We launched DayZee Livestock, DayZee Agriculture, Solar installation, and Intersection of science and soil as key initiatives" />
      </node>
      <node TEXT="Our Impact on the UN Sustainable Development Goals (SDGs)">
        <node TEXT="Overview of DayZee Farms contribution to multiple UN SDGs" />
        <node TEXT="Highlights of SDG 2 Zero Hunger, SDG 7 Affordable and Clean Energy, SDG 9 Industry Innovation and Infrastructure, SDG 12 Responsible Consumption and Production, and SDG 13 Climate Action initiatives" />
      </node>
      <node TEXT="Get in touch Let #39;s Get Started">
        <node TEXT="Contact form to connect with DayZee for farming and livestock solutions">
          <node TEXT="First Name*" />
          <node TEXT="Last Name*" />
          <node TEXT="Email*" />
          <node TEXT="Mobile Number*" />
          <node TEXT="Company Name" />
          <node TEXT="City (dropdown example: Karachi)" />
          <node TEXT="Country" />
          <node TEXT="Interested In" />
          <node TEXT="Message" />
          <node TEXT="SUBMIT" />
        </node>
      </node>
      <node TEXT="DayZee agriculture summary">
        <node TEXT="Brief description of DayZee #39;s role in revolutionizing Pakistan #39;s agriculture with genetics, sustainable practices, and turnkey solutions" />
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/">
      <node TEXT="Hero - Superior Genetics for Tomorrow">
        <node TEXT="Intro summary: Imported Brahman, Beefmaster, Slick Friesians   Red Angus for superior performance in Pakistan." />
        <node TEXT="REQUEST SEMEN/EMBRYO">
          <node TEXT="tel:+923314476666" />
        </node>
        <node TEXT="BOOK A CONSULTATION">
          <node TEXT="tel:+923314431111" />
        </node>
        <node TEXT="BOOK OPU OF YOUR COW NOW">
          <node TEXT="tel:+923314431111" />
        </node>
      </node>
      <node TEXT="About Our Genetics">
        <node TEXT="Overview: Highlight of elite cattle genetics options and their key benefits." />
        <node TEXT="Genetic Breeds">
          <node TEXT="Slick Gene Frisien - Heat-resistant Friesian with high daily milk yield." />
          <node TEXT="Brahman - Imported JDH line, heavy growth and beef-focused." />
          <node TEXT="Beefmaster - Fertility, rapid weight gain and carcass quality for premium beef." />
          <node TEXT="Red Angus - High fertility, easy calving and premium beef marbling." />
        </node>
      </node>
      <node TEXT="Our Services">
        <node TEXT="Overview: Core livestock genetics services offered to farmers." />
        <node TEXT="Service Cards">
          <node TEXT="Semen Availability - High-performing, climate-adapted bulls for fertility, milk yield and meat quality." />
          <node TEXT="Embryo Transfer Pregnancies - IVF lab producing elite embryos and monitored pregnancies." />
          <node TEXT="Pregnant Heifers for Sale - Biosecure, pregnancy-verified and health-certified heifers." />
          <node TEXT="Genetics Consultation - Expert guidance from sire selection to embryo strategy." />
        </node>
      </node>
      <node TEXT="OPU Promotion - 20+ calves from one elite donor cow">
        <node TEXT="Summary: Explains Ovum Pickup (OPU) and IVF to multiply top genetics at scale." />
        <node TEXT="Book OPU Now">
          <node TEXT="tel:+92314431111" />
        </node>
      </node>
      <node TEXT="Explore Our Genetic Catalogue">
        <node TEXT="Summary: Visual strip of cattle images inviting users to browse catalogues." />
        <node TEXT="Catalogue Links">
          <node TEXT="Brahman Catalogue">
            <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" />
          </node>
          <node TEXT="Slick-Gene Friesian Catalogue">
            <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" />
          </node>
          <node TEXT="Beefmaster Catalogue">
            <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" />
          </node>
          <node TEXT="Red Angus Catalogue">
            <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" />
          </node>
        </node>
      </node>
      <node TEXT="Our Global Partners">
        <node TEXT="Summary: Logos of international universities and ranches backing their genetics." />
      </node>
      <node TEXT="Get in touch – Let #39;s Get Started">
        <node TEXT="Summary: Invitation to connect for expert farming and livestock solutions." />
        <node TEXT="Contact Form">
          <node TEXT="First Name*" />
          <node TEXT="Last Name*" />
          <node TEXT="Email*" />
          <node TEXT="Mobile Number*" />
          <node TEXT="Company Name" />
          <node TEXT="City (dropdown, example: Karachi)" />
          <node TEXT="Country" />
          <node TEXT="Interested In" />
          <node TEXT="Message" />
          <node TEXT="SUBMIT" />
        </node>
      </node>
      <node TEXT="Media   Social">
        <node TEXT="Watch Now on Youtube">
          <node TEXT="https://youtu.be/onr1r1d5sMQ?si=xUzEGMC-z_rTKtzG" />
        </node>
        <node TEXT="Subscribe to our channel">
          <node TEXT="https://www.youtube.com/@DayZeeFarms" />
        </node>
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/">
      <node TEXT="Hero Section - Transforming 4,200 Barren Acres">
        <node TEXT="Headline   Subheadline - Sustainable livestock and agricultural hub in Cholistan desert" />
      </node>
      <node TEXT="A New Era of Desert Farming">
        <node TEXT="Overview - DayZee Farms converting barren desert into productive agricultural hub using innovative irrigation and fodder crops" />
      </node>
      <node TEXT="Barren Land Transformation">
        <node TEXT="Timeline Images - April 2024, March 2025, May 2025 showing land development progress" />
      </node>
      <node TEXT="Technology In Agriculture">
        <node TEXT="Irrigation Systems - Central pivot irrigation with current and planned installations" />
        <node TEXT="Mechanized Farm Machinery - State-of-the-art equipment for efficient farm operations" />
        <node TEXT="Solar Power Plant - 6MW solar plant to power all farm activities" />
      </node>
      <node TEXT="Our Products">
        <node TEXT="Alfalfa - High-yield, nutrient-rich forage crop for dairy and beef cattle" />
        <node TEXT="Rhodes Grass - Drought-resistant grass optimized for livestock nutrition" />
      </node>
      <node TEXT="Our Services">
        <node TEXT="Land Development - Converting barren or underutilized land into productive farmland" />
        <node TEXT="Center Pivot Irrigation Systems - Design, installation, and maintenance for efficient water use" />
        <node TEXT="Farm Operations - End-to-end mechanized crop cycle management" />
        <node TEXT="Integrated Farm Management - Planning, execution, and monitoring of agricultural operations" />
        <node TEXT="Irrigation   Infrastructure Consultancy - Advisory for large-scale, water-efficient farming systems" />
      </node>
      <node TEXT="Our Global Partners">
        <node TEXT="Partner Logos - MQ Holding Group LLC, AFKO, Ozduman, Krone supporting genetics and technology" />
      </node>
      <node TEXT="Get in touch – Let #39;s Get Started">
        <node TEXT="Contact Form">
          <node TEXT="First Name* (text field)" />
          <node TEXT="Last Name* (text field)" />
          <node TEXT="Email* (text field)" />
          <node TEXT="Mobile Number* (text field)" />
          <node TEXT="Company Name (text field)" />
          <node TEXT="City (dropdown - example: Karachi)" />
          <node TEXT="Country (text field)" />
          <node TEXT="Interested In (text field or dropdown)" />
          <node TEXT="Message (textarea)" />
          <node TEXT="SUBMIT (button)" />
        </node>
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/">
      <node TEXT="Main Content">
        <node TEXT="Hero Section - Renewable Energy Overview">
          <node TEXT="Headline: RENEWABLE ENERGY" />
          <node TEXT="Subheading: Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" />
        </node>
        <node TEXT="Solar Panel Infrastructure">
          <node TEXT="Summary: 6MW solar panel system powering farm operations, irrigation, and livestock with clean, cost-effective energy while cutting carbon emissions and costs." />
        </node>
        <node TEXT="Our Biogas Plant">
          <node TEXT="Summary: Converts organic farm waste into biogas for power and heat, reducing methane emissions and waste while supporting a circular economy." />
        </node>
        <node TEXT="Operational Metrics">
          <node TEXT="500 Delivered Packages" />
          <node TEXT="500 Global Shipping" />
          <node TEXT="500 Air Freight" />
          <node TEXT="500 Happy Customers" />
        </node>
        <node TEXT="Corporate Social Responsibility (CSR)">
          <node TEXT="Empowering Rural Communities - Creating sustainable jobs and uplifting local families." />
          <node TEXT="Farmer Development - Training on modern farming, IVF, and animal husbandry." />
          <node TEXT="Environmental Stewardship - Solar and biogas projects reducing emissions and promoting sustainable agribusiness." />
          <node TEXT="Animal Ethics   Welfare - High welfare standards focused on nutrition, care, and ethical reproduction." />
        </node>
        <node TEXT="Get in touch – Let #39;s Get Started">
          <node TEXT="Summary: Invitation to connect with DayZee for expert farming and livestock solutions." />
        </node>
      </node>
      <node TEXT="Forms">
        <node TEXT="Contact Form">
          <node TEXT="First Name*" />
          <node TEXT="Last Name*" />
          <node TEXT="Email*" />
          <node TEXT="Mobile Number*" />
          <node TEXT="Company Name" />
          <node TEXT="City (Dropdown - e.g., Karachi)" />
          <node TEXT="Country" />
          <node TEXT="Interested In" />
          <node TEXT="Message" />
          <node TEXT="Submit Button" />
        </node>
      </node>
      <node TEXT="Buttons">
        <node TEXT="SUBMIT">
          <node TEXT="Submit contact form" />
        </node>
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Gallery" LINK="https://dayzee.com/gallery/">
      <node TEXT="Image Gallery Section">
        <node TEXT="IMAGE GALLERY - visual showcase of DayZee activities and facilities" />
        <node TEXT="Gallery Items - thumbnails linking to detailed event galleries">
          <node TEXT="DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025">
            <node TEXT="Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery_dayzee-at-ildpa2025.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Chinese Delegation at DayZee (Private) Limited">
            <node TEXT="Link" LINK="https://dayzee.com/gallery/chinese-delegation/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery_chinese-delegation.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
      </node>
      <node TEXT="Get in touch – Contact Form Section">
        <node TEXT="Intro Text - Invitation to connect for expert farming and livestock solutions" />
        <node TEXT="Contact Form">
          <node TEXT="First Name*" />
          <node TEXT="Last Name*" />
          <node TEXT="Email*" />
          <node TEXT="Mobile Number*" />
          <node TEXT="Company Name" />
          <node TEXT="City - dropdown (e.g., Karachi)" />
          <node TEXT="Country" />
          <node TEXT="Interested In" />
          <node TEXT="Message" />
          <node TEXT="Button">
            <node TEXT="SUBMIT" />
          </node>
        </node>
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/">
      <node TEXT="Contact Information">
        <node TEXT="Our Office - DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur.">
          <node TEXT="Location Link">
            <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur." LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_WstmNjesSmVKyyB66.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="Call Us - Phone numbers for contact">
          <node TEXT="Phone 1" LINK="tel:0331 443 1111">
            <node TEXT="0331-443 1111" />
          </node>
          <node TEXT="Phone 2" LINK="tel:0331 447 66 66">
            <node TEXT="0331-447 6666" />
          </node>
        </node>
        <node TEXT="Email Address - Primary contact email">
          <node TEXT="info@dayzee.com" LINK="mailto:info@dayzee.com" />
        </node>
      </node>
      <node TEXT="Contact Form and Map">
        <node TEXT="Location Map - Embedded map showing DayZee Farms" />
        <node TEXT="Get in touch Let #39;s Get Started Form">
          <node TEXT="First Name*" />
          <node TEXT="Last Name*" />
          <node TEXT="Email*" />
          <node TEXT="Mobile Number*" />
          <node TEXT="Company Name" />
          <node TEXT="City Dropdown - Karachi selected" />
          <node TEXT="Country" />
          <node TEXT="Interested In" />
          <node TEXT="Message" />
          <node TEXT="Submit Button">
            <node TEXT="SUBMIT" />
          </node>
        </node>
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Home Page Content">
      <icon BUILTIN="image" />
      <node TEXT="Hero Section">
        <icon BUILTIN="image" />
        <node TEXT="Background Image - Green Field   Irrigation" />
        <node TEXT="Title: AGRICULTURE" />
        <node TEXT="Subtitle: Innovating Modern Farming" />
      </node>
      <node TEXT="Livestock Section">
        <icon BUILTIN="image" />
        <node TEXT="Heading: LIVESTOCK" />
        <node TEXT="Subheading: In Elite Genetics for Unmatched Livestock Performance" />
        <node TEXT="Description">
          <node TEXT="DayZee Farms is transforming cattle farming in Pakistan through advanced reproductive biotechnology and elite imported genetics." />
        </node>
        <node TEXT="Button: LEARN MORE" LINK="https://dayzee.com/live-stock/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Programs Cards">
          <icon BUILTIN="list" />
          <node TEXT="Invitro Fertilization Program">
            <icon BUILTIN="image" />
            <node TEXT="Card Icon" />
            <node TEXT="Description: IVF Lab setting new standards in cattle and livestock breeding in Pakistan." />
          </node>
          <node TEXT="Artificial Insemination Program">
            <icon BUILTIN="image" />
            <node TEXT="Card Icon" />
            <node TEXT="Description: AI Program uses elite global genetics and advanced CASA technology." />
          </node>
          <node TEXT="Genetics Lab">
            <icon BUILTIN="image" />
            <node TEXT="Card Icon" />
            <node TEXT="Description: Genetics Lab sequences animal DNA to identify superior genetics." />
          </node>
        </node>
        <node TEXT="Benefits">
          <icon BUILTIN="list" />
          <node TEXT="Heat Tolerance">
            <icon BUILTIN="image" />
            <node TEXT="Description: Perfect for Pakistan #39;s climate." />
          </node>
          <node TEXT="Fertility   Productivity">
            <icon BUILTIN="image" />
            <node TEXT="Description: Maximize your herd #39;s potential." />
          </node>
          <node TEXT="Long-Term Profitability">
            <icon BUILTIN="image" />
            <node TEXT="Description: Higher quality offspring with market-leading traits." />
          </node>
        </node>
      </node>
      <node TEXT="Agriculture Section">
        <icon BUILTIN="image" />
        <node TEXT="Heading: Agriculture" />
        <node TEXT="Subheading: Turning Barren Land into Agricultural Gold" />
        <node TEXT="Description">
          <node TEXT="Restoring Pakistan #39;s soil by converting 4,200 acres of barren land into fertile farmland using state-of-the-art irrigation and sustainable farming techniques." />
        </node>
        <node TEXT="Button: LEARN MORE" LINK="https://dayzee.com/agriculture/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Agriculture Services Cards">
          <icon BUILTIN="list" />
          <node TEXT="Pivot Irrigation">
            <icon BUILTIN="image" />
            <node TEXT="Description: Exclusive dealer of AFKO Industries #39; center-pivot and linear-move irrigation systems in Pakistan." />
          </node>
          <node TEXT="Mechanized Farming">
            <icon BUILTIN="image" />
            <node TEXT="Description: Use of state-of-the-art farm machinery and mechanization services." />
          </node>
          <node TEXT="Premium Animal Fodder">
            <icon BUILTIN="image" />
            <node TEXT="Description: Cultivation of Rhode grass, alfalfa, and other premium fodders with export focus." />
          </node>
        </node>
      </node>
      <node TEXT="Renewable Energy Section">
        <icon BUILTIN="image" />
        <node TEXT="Heading: Renewable Energy" />
        <node TEXT="Subheading: Sustainable and Smart Agriculture" />
        <node TEXT="Button: EXPLORE OUR SUSTAINABILITY" LINK="https://dayzee.com/renewable-energy/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Energy Solutions Cards">
          <icon BUILTIN="list" />
          <node TEXT="Solar Powered Future">
            <icon BUILTIN="image" />
            <node TEXT="Subtitle: 6.6 MW Clean Energy" />
            <node TEXT="Description: Harnessing solar power for water, pivot rotation, and farm operations." />
          </node>
          <node TEXT="Biogas To Energy">
            <icon BUILTIN="image" />
            <node TEXT="Subtitle: 2.2 MW from Organic Waste" />
            <node TEXT="Description: Transforming farm waste into reliable green power." />
          </node>
        </node>
      </node>
      <node TEXT="Contact Section">
        <icon BUILTIN="image" />
        <node TEXT="Heading: Get in touch Let #39;s Get Started" />
        <node TEXT="Description: Connect with DayZee for expert farming and livestock solutions." />
        <node TEXT="Contact Form">
          <icon BUILTIN="edit" />
          <node TEXT="Field: First Name*" />
          <node TEXT="Field: Last Name*" />
          <node TEXT="Field: Email*" />
          <node TEXT="Field: Mobile Number*" />
          <node TEXT="Field: Company Name" />
          <node TEXT="Dropdown: City (e.g., Karachi)" />
          <node TEXT="Field: Country" />
          <node TEXT="Dropdown: Interested In" />
          <node TEXT="Textarea: Message" />
          <node TEXT="Button: SUBMIT" />
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <icon BUILTIN="bookmark" />
      <node TEXT="Brand Summary">
        <icon BUILTIN="image" />
        <node TEXT="Logo" />
        <node TEXT="Description: Revolutionizing Pakistan #39;s agriculture with elite livestock genetics, sustainable farming, and innovative irrigation solutions." />
      </node>
      <node TEXT="Company Links">
        <icon BUILTIN="list" />
        <node TEXT="Home" LINK="https://dayzee.com/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Services" LINK="https://dayzee.com/service/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_service.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Quick Links">
        <icon BUILTIN="list" />
        <node TEXT="About Us" LINK="https://dayzee.com/about/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_faqs.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Follow us at">
        <icon BUILTIN="list" />
        <node TEXT="Facebook - DayZee Farms" LINK="https://www.facebook.com/dayzeefarm"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.facebook.com_dayzeefarm.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.tiktok.com_dayzee.pvt.ltd.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Instagram - DayZee Farms" LINK="https://www.instagram.com/dayzeefarms/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_dayzeefarms.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Youtube - DayZee Farms" LINK="https://www.youtube.com/@DayZeeFarms"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.youtube.com_DayZeeFarms.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Copyright">
        <node TEXT="Copyright  #169; 2025 DayZee. All Rights Reserved" />
      </node>
    </node>
  </node>
</map>