<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Home Page" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <icon BUILTIN="bookmark"/>
      <node TEXT="Logo" FOLDED="true">
        <icon BUILTIN="image"/>
        <node TEXT="DayZee" LINK="https://dayzee.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_content.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Main Navigation" FOLDED="true">
        <icon BUILTIN="list"/>
      </node>
    </node>
    <node TEXT="About Us" LINK="https://dayzee.com/about/" FOLDED="true">
      <node TEXT="DayZee Farms Began with a Bold Idea" FOLDED="true">
        <node TEXT="Introduction to DayZee Farms vision and origins in Pakistan" FOLDED="true"/>
        <node TEXT="We launched DayZee Livestock, DayZee Agriculture, Solar installation, and Intersection of science and soil as key initiatives" FOLDED="true"/>
      </node>
      <node TEXT="Our Impact on the UN Sustainable Development Goals (SDGs)" FOLDED="true">
        <node TEXT="Overview of DayZee Farms contribution to multiple UN SDGs" FOLDED="true"/>
        <node TEXT="Highlights of SDG 2 Zero Hunger, SDG 7 Affordable and Clean Energy, SDG 9 Industry Innovation and Infrastructure, SDG 12 Responsible Consumption and Production, and SDG 13 Climate Action initiatives" FOLDED="true"/>
      </node>
      <node TEXT="Get in touch Let #39;s Get Started" FOLDED="true">
        <node TEXT="Contact form to connect with DayZee for farming and livestock solutions" FOLDED="true">
          <node TEXT="First Name*" FOLDED="true"/>
          <node TEXT="Last Name*" FOLDED="true"/>
          <node TEXT="Email*" FOLDED="true"/>
          <node TEXT="Mobile Number*" FOLDED="true"/>
          <node TEXT="Company Name" FOLDED="true"/>
          <node TEXT="City (dropdown example: Karachi)" FOLDED="true"/>
          <node TEXT="Country" FOLDED="true"/>
          <node TEXT="Interested In" FOLDED="true"/>
          <node TEXT="Message" FOLDED="true"/>
          <node TEXT="SUBMIT" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="DayZee agriculture summary" FOLDED="true">
        <node TEXT="Brief description of DayZee #39;s role in revolutionizing Pakistan #39;s agriculture with genetics, sustainable practices, and turnkey solutions" FOLDED="true"/>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/" FOLDED="true">
      <node TEXT="Hero - Superior Genetics for Tomorrow" FOLDED="true">
        <node TEXT="Intro summary: Imported Brahman, Beefmaster, Slick Friesians   Red Angus for superior performance in Pakistan." FOLDED="true"/>
        <node TEXT="REQUEST SEMEN/EMBRYO" FOLDED="true">
          <node TEXT="tel:+923314476666" FOLDED="true"/>
        </node>
        <node TEXT="BOOK A CONSULTATION" FOLDED="true">
          <node TEXT="tel:+923314431111" FOLDED="true"/>
        </node>
        <node TEXT="BOOK OPU OF YOUR COW NOW" FOLDED="true">
          <node TEXT="tel:+923314431111" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="About Our Genetics" FOLDED="true">
        <node TEXT="Overview: Highlight of elite cattle genetics options and their key benefits." FOLDED="true"/>
        <node TEXT="Genetic Breeds" FOLDED="true">
          <node TEXT="Slick Gene Frisien - Heat-resistant Friesian with high daily milk yield." FOLDED="true"/>
          <node TEXT="Brahman - Imported JDH line, heavy growth and beef-focused." FOLDED="true"/>
          <node TEXT="Beefmaster - Fertility, rapid weight gain and carcass quality for premium beef." FOLDED="true"/>
          <node TEXT="Red Angus - High fertility, easy calving and premium beef marbling." FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Our Services" FOLDED="true">
        <node TEXT="Overview: Core livestock genetics services offered to farmers." FOLDED="true"/>
        <node TEXT="Service Cards" FOLDED="true">
          <node TEXT="Semen Availability - High-performing, climate-adapted bulls for fertility, milk yield and meat quality." FOLDED="true"/>
          <node TEXT="Embryo Transfer Pregnancies - IVF lab producing elite embryos and monitored pregnancies." FOLDED="true"/>
          <node TEXT="Pregnant Heifers for Sale - Biosecure, pregnancy-verified and health-certified heifers." FOLDED="true"/>
          <node TEXT="Genetics Consultation - Expert guidance from sire selection to embryo strategy." FOLDED="true"/>
        </node>
      </node>
      <node TEXT="OPU Promotion - 20+ calves from one elite donor cow" FOLDED="true">
        <node TEXT="Summary: Explains Ovum Pickup (OPU) and IVF to multiply top genetics at scale." FOLDED="true"/>
        <node TEXT="Book OPU Now" FOLDED="true">
          <node TEXT="tel:+92314431111" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Explore Our Genetic Catalogue" FOLDED="true">
        <node TEXT="Summary: Visual strip of cattle images inviting users to browse catalogues." FOLDED="true"/>
        <node TEXT="Catalogue Links" FOLDED="true">
          <node TEXT="Brahman Catalogue" FOLDED="true">
            <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" FOLDED="true"/>
          </node>
          <node TEXT="Slick-Gene Friesian Catalogue" FOLDED="true">
            <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" FOLDED="true"/>
          </node>
          <node TEXT="Beefmaster Catalogue" FOLDED="true">
            <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" FOLDED="true"/>
          </node>
          <node TEXT="Red Angus Catalogue" FOLDED="true">
            <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" FOLDED="true"/>
          </node>
        </node>
      </node>
      <node TEXT="Our Global Partners" FOLDED="true">
        <node TEXT="Summary: Logos of international universities and ranches backing their genetics." FOLDED="true"/>
      </node>
      <node TEXT="Get in touch – Let #39;s Get Started" FOLDED="true">
        <node TEXT="Summary: Invitation to connect for expert farming and livestock solutions." FOLDED="true"/>
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="First Name*" FOLDED="true"/>
          <node TEXT="Last Name*" FOLDED="true"/>
          <node TEXT="Email*" FOLDED="true"/>
          <node TEXT="Mobile Number*" FOLDED="true"/>
          <node TEXT="Company Name" FOLDED="true"/>
          <node TEXT="City (dropdown, example: Karachi)" FOLDED="true"/>
          <node TEXT="Country" FOLDED="true"/>
          <node TEXT="Interested In" FOLDED="true"/>
          <node TEXT="Message" FOLDED="true"/>
          <node TEXT="SUBMIT" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Media   Social" FOLDED="true">
        <node TEXT="Watch Now on Youtube" FOLDED="true">
          <node TEXT="https://youtu.be/onr1r1d5sMQ?si=xUzEGMC-z_rTKtzG" FOLDED="true"/>
        </node>
        <node TEXT="Subscribe to our channel" FOLDED="true">
          <node TEXT="https://www.youtube.com/@DayZeeFarms" FOLDED="true"/>
        </node>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/" FOLDED="true">
      <node TEXT="Hero Section - Transforming 4,200 Barren Acres" FOLDED="true">
        <node TEXT="Headline   Subheadline - Sustainable livestock and agricultural hub in Cholistan desert" FOLDED="true"/>
      </node>
      <node TEXT="A New Era of Desert Farming" FOLDED="true">
        <node TEXT="Overview - DayZee Farms converting barren desert into productive agricultural hub using innovative irrigation and fodder crops" FOLDED="true"/>
      </node>
      <node TEXT="Barren Land Transformation" FOLDED="true">
        <node TEXT="Timeline Images - April 2024, March 2025, May 2025 showing land development progress" FOLDED="true"/>
      </node>
      <node TEXT="Technology In Agriculture" FOLDED="true">
        <node TEXT="Irrigation Systems - Central pivot irrigation with current and planned installations" FOLDED="true"/>
        <node TEXT="Mechanized Farm Machinery - State-of-the-art equipment for efficient farm operations" FOLDED="true"/>
        <node TEXT="Solar Power Plant - 6MW solar plant to power all farm activities" FOLDED="true"/>
      </node>
      <node TEXT="Our Products" FOLDED="true">
        <node TEXT="Alfalfa - High-yield, nutrient-rich forage crop for dairy and beef cattle" FOLDED="true"/>
        <node TEXT="Rhodes Grass - Drought-resistant grass optimized for livestock nutrition" FOLDED="true"/>
      </node>
      <node TEXT="Our Services" FOLDED="true">
        <node TEXT="Land Development - Converting barren or underutilized land into productive farmland" FOLDED="true"/>
        <node TEXT="Center Pivot Irrigation Systems - Design, installation, and maintenance for efficient water use" FOLDED="true"/>
        <node TEXT="Farm Operations - End-to-end mechanized crop cycle management" FOLDED="true"/>
        <node TEXT="Integrated Farm Management - Planning, execution, and monitoring of agricultural operations" FOLDED="true"/>
        <node TEXT="Irrigation   Infrastructure Consultancy - Advisory for large-scale, water-efficient farming systems" FOLDED="true"/>
      </node>
      <node TEXT="Our Global Partners" FOLDED="true">
        <node TEXT="Partner Logos - MQ Holding Group LLC, AFKO, Ozduman, Krone supporting genetics and technology" FOLDED="true"/>
      </node>
      <node TEXT="Get in touch – Let #39;s Get Started" FOLDED="true">
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="First Name* (text field)" FOLDED="true"/>
          <node TEXT="Last Name* (text field)" FOLDED="true"/>
          <node TEXT="Email* (text field)" FOLDED="true"/>
          <node TEXT="Mobile Number* (text field)" FOLDED="true"/>
          <node TEXT="Company Name (text field)" FOLDED="true"/>
          <node TEXT="City (dropdown - example: Karachi)" FOLDED="true"/>
          <node TEXT="Country (text field)" FOLDED="true"/>
          <node TEXT="Interested In (text field or dropdown)" FOLDED="true"/>
          <node TEXT="Message (textarea)" FOLDED="true"/>
          <node TEXT="SUBMIT (button)" FOLDED="true"/>
        </node>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/" FOLDED="true">
      <node TEXT="Main Content" FOLDED="true">
        <node TEXT="Hero Section - Renewable Energy Overview" FOLDED="true">
          <node TEXT="Headline: RENEWABLE ENERGY" FOLDED="true"/>
          <node TEXT="Subheading: Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" FOLDED="true"/>
        </node>
        <node TEXT="Solar Panel Infrastructure" FOLDED="true">
          <node TEXT="Summary: 6MW solar panel system powering farm operations, irrigation, and livestock with clean, cost-effective energy while cutting carbon emissions and costs." FOLDED="true"/>
        </node>
        <node TEXT="Our Biogas Plant" FOLDED="true">
          <node TEXT="Summary: Converts organic farm waste into biogas for power and heat, reducing methane emissions and waste while supporting a circular economy." FOLDED="true"/>
        </node>
        <node TEXT="Operational Metrics" FOLDED="true">
          <node TEXT="500 Delivered Packages" FOLDED="true"/>
          <node TEXT="500 Global Shipping" FOLDED="true"/>
          <node TEXT="500 Air Freight" FOLDED="true"/>
          <node TEXT="500 Happy Customers" FOLDED="true"/>
        </node>
        <node TEXT="Corporate Social Responsibility (CSR)" FOLDED="true">
          <node TEXT="Empowering Rural Communities - Creating sustainable jobs and uplifting local families." FOLDED="true"/>
          <node TEXT="Farmer Development - Training on modern farming, IVF, and animal husbandry." FOLDED="true"/>
          <node TEXT="Environmental Stewardship - Solar and biogas projects reducing emissions and promoting sustainable agribusiness." FOLDED="true"/>
          <node TEXT="Animal Ethics   Welfare - High welfare standards focused on nutrition, care, and ethical reproduction." FOLDED="true"/>
        </node>
        <node TEXT="Get in touch – Let #39;s Get Started" FOLDED="true">
          <node TEXT="Summary: Invitation to connect with DayZee for expert farming and livestock solutions." FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Forms" FOLDED="true">
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="First Name*" FOLDED="true"/>
          <node TEXT="Last Name*" FOLDED="true"/>
          <node TEXT="Email*" FOLDED="true"/>
          <node TEXT="Mobile Number*" FOLDED="true"/>
          <node TEXT="Company Name" FOLDED="true"/>
          <node TEXT="City (Dropdown - e.g., Karachi)" FOLDED="true"/>
          <node TEXT="Country" FOLDED="true"/>
          <node TEXT="Interested In" FOLDED="true"/>
          <node TEXT="Message" FOLDED="true"/>
          <node TEXT="Submit Button" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Buttons" FOLDED="true">
        <node TEXT="SUBMIT" FOLDED="true">
          <node TEXT="Submit contact form" FOLDED="true"/>
        </node>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" FOLDED="true">
      <node TEXT="Image Gallery Section" FOLDED="true">
        <node TEXT="IMAGE GALLERY - visual showcase of DayZee activities and facilities" FOLDED="true"/>
        <node TEXT="Gallery Items - thumbnails linking to detailed event galleries" FOLDED="true">
          <node TEXT="DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025" FOLDED="true">
            <node TEXT="Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery_dayzee-at-ildpa2025.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Chinese Delegation at DayZee (Private) Limited" FOLDED="true">
            <node TEXT="Link" LINK="https://dayzee.com/gallery/chinese-delegation/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery_chinese-delegation.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
      </node>
      <node TEXT="Get in touch – Contact Form Section" FOLDED="true">
        <node TEXT="Intro Text - Invitation to connect for expert farming and livestock solutions" FOLDED="true"/>
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="First Name*" FOLDED="true"/>
          <node TEXT="Last Name*" FOLDED="true"/>
          <node TEXT="Email*" FOLDED="true"/>
          <node TEXT="Mobile Number*" FOLDED="true"/>
          <node TEXT="Company Name" FOLDED="true"/>
          <node TEXT="City - dropdown (e.g., Karachi)" FOLDED="true"/>
          <node TEXT="Country" FOLDED="true"/>
          <node TEXT="Interested In" FOLDED="true"/>
          <node TEXT="Message" FOLDED="true"/>
          <node TEXT="Button" FOLDED="true">
            <node TEXT="SUBMIT" FOLDED="true"/>
          </node>
        </node>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" FOLDED="true">
      <node TEXT="Contact Information" FOLDED="true">
        <node TEXT="Our Office - DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur." FOLDED="true">
          <node TEXT="Location Link" FOLDED="true">
            <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur." LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_WstmNjesSmVKyyB66.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="Call Us - Phone numbers for contact" FOLDED="true">
          <node TEXT="Phone 1" LINK="tel:0331 443 1111" FOLDED="true">
            <node TEXT="0331-443 1111" FOLDED="true"/>
          </node>
          <node TEXT="Phone 2" LINK="tel:0331 447 66 66" FOLDED="true">
            <node TEXT="0331-447 6666" FOLDED="true"/>
          </node>
        </node>
        <node TEXT="Email Address - Primary contact email" FOLDED="true">
          <node TEXT="info@dayzee.com" LINK="mailto:info@dayzee.com" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Contact Form and Map" FOLDED="true">
        <node TEXT="Location Map - Embedded map showing DayZee Farms" FOLDED="true"/>
        <node TEXT="Get in touch Let #39;s Get Started Form" FOLDED="true">
          <node TEXT="First Name*" FOLDED="true"/>
          <node TEXT="Last Name*" FOLDED="true"/>
          <node TEXT="Email*" FOLDED="true"/>
          <node TEXT="Mobile Number*" FOLDED="true"/>
          <node TEXT="Company Name" FOLDED="true"/>
          <node TEXT="City Dropdown - Karachi selected" FOLDED="true"/>
          <node TEXT="Country" FOLDED="true"/>
          <node TEXT="Interested In" FOLDED="true"/>
          <node TEXT="Message" FOLDED="true"/>
          <node TEXT="Submit Button" FOLDED="true">
            <node TEXT="SUBMIT" FOLDED="true"/>
          </node>
        </node>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Home Page Content" FOLDED="true">
      <icon BUILTIN="image"/>
      <node TEXT="Hero Section" FOLDED="true">
        <icon BUILTIN="image"/>
        <node TEXT="Background Image - Green Field   Irrigation" FOLDED="true"/>
        <node TEXT="Title: AGRICULTURE" FOLDED="true"/>
        <node TEXT="Subtitle: Innovating Modern Farming" FOLDED="true"/>
      </node>
      <node TEXT="Livestock Section" FOLDED="true">
        <icon BUILTIN="image"/>
        <node TEXT="Heading: LIVESTOCK" FOLDED="true"/>
        <node TEXT="Subheading: In Elite Genetics for Unmatched Livestock Performance" FOLDED="true"/>
        <node TEXT="Description" FOLDED="true">
          <node TEXT="DayZee Farms is transforming cattle farming in Pakistan through advanced reproductive biotechnology and elite imported genetics." FOLDED="true"/>
        </node>
        <node TEXT="Button: LEARN MORE" LINK="https://dayzee.com/live-stock/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Programs Cards" FOLDED="true">
          <icon BUILTIN="list"/>
          <node TEXT="Invitro Fertilization Program" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Card Icon" FOLDED="true"/>
            <node TEXT="Description: IVF Lab setting new standards in cattle and livestock breeding in Pakistan." FOLDED="true"/>
          </node>
          <node TEXT="Artificial Insemination Program" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Card Icon" FOLDED="true"/>
            <node TEXT="Description: AI Program uses elite global genetics and advanced CASA technology." FOLDED="true"/>
          </node>
          <node TEXT="Genetics Lab" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Card Icon" FOLDED="true"/>
            <node TEXT="Description: Genetics Lab sequences animal DNA to identify superior genetics." FOLDED="true"/>
          </node>
        </node>
        <node TEXT="Benefits" FOLDED="true">
          <icon BUILTIN="list"/>
          <node TEXT="Heat Tolerance" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Description: Perfect for Pakistan #39;s climate." FOLDED="true"/>
          </node>
          <node TEXT="Fertility   Productivity" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Description: Maximize your herd #39;s potential." FOLDED="true"/>
          </node>
          <node TEXT="Long-Term Profitability" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Description: Higher quality offspring with market-leading traits." FOLDED="true"/>
          </node>
        </node>
      </node>
      <node TEXT="Agriculture Section" FOLDED="true">
        <icon BUILTIN="image"/>
        <node TEXT="Heading: Agriculture" FOLDED="true"/>
        <node TEXT="Subheading: Turning Barren Land into Agricultural Gold" FOLDED="true"/>
        <node TEXT="Description" FOLDED="true">
          <node TEXT="Restoring Pakistan #39;s soil by converting 4,200 acres of barren land into fertile farmland using state-of-the-art irrigation and sustainable farming techniques." FOLDED="true"/>
        </node>
        <node TEXT="Button: LEARN MORE" LINK="https://dayzee.com/agriculture/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Agriculture Services Cards" FOLDED="true">
          <icon BUILTIN="list"/>
          <node TEXT="Pivot Irrigation" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Description: Exclusive dealer of AFKO Industries #39; center-pivot and linear-move irrigation systems in Pakistan." FOLDED="true"/>
          </node>
          <node TEXT="Mechanized Farming" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Description: Use of state-of-the-art farm machinery and mechanization services." FOLDED="true"/>
          </node>
          <node TEXT="Premium Animal Fodder" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Description: Cultivation of Rhode grass, alfalfa, and other premium fodders with export focus." FOLDED="true"/>
          </node>
        </node>
      </node>
      <node TEXT="Renewable Energy Section" FOLDED="true">
        <icon BUILTIN="image"/>
        <node TEXT="Heading: Renewable Energy" FOLDED="true"/>
        <node TEXT="Subheading: Sustainable and Smart Agriculture" FOLDED="true"/>
        <node TEXT="Button: EXPLORE OUR SUSTAINABILITY" LINK="https://dayzee.com/renewable-energy/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Energy Solutions Cards" FOLDED="true">
          <icon BUILTIN="list"/>
          <node TEXT="Solar Powered Future" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Subtitle: 6.6 MW Clean Energy" FOLDED="true"/>
            <node TEXT="Description: Harnessing solar power for water, pivot rotation, and farm operations." FOLDED="true"/>
          </node>
          <node TEXT="Biogas To Energy" FOLDED="true">
            <icon BUILTIN="image"/>
            <node TEXT="Subtitle: 2.2 MW from Organic Waste" FOLDED="true"/>
            <node TEXT="Description: Transforming farm waste into reliable green power." FOLDED="true"/>
          </node>
        </node>
      </node>
      <node TEXT="Contact Section" FOLDED="true">
        <icon BUILTIN="image"/>
        <node TEXT="Heading: Get in touch Let #39;s Get Started" FOLDED="true"/>
        <node TEXT="Description: Connect with DayZee for expert farming and livestock solutions." FOLDED="true"/>
        <node TEXT="Contact Form" FOLDED="true">
          <icon BUILTIN="edit"/>
          <node TEXT="Field: First Name*" FOLDED="true"/>
          <node TEXT="Field: Last Name*" FOLDED="true"/>
          <node TEXT="Field: Email*" FOLDED="true"/>
          <node TEXT="Field: Mobile Number*" FOLDED="true"/>
          <node TEXT="Field: Company Name" FOLDED="true"/>
          <node TEXT="Dropdown: City (e.g., Karachi)" FOLDED="true"/>
          <node TEXT="Field: Country" FOLDED="true"/>
          <node TEXT="Dropdown: Interested In" FOLDED="true"/>
          <node TEXT="Textarea: Message" FOLDED="true"/>
          <node TEXT="Button: SUBMIT" FOLDED="true"/>
        </node>
      </node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <icon BUILTIN="bookmark"/>
      <node TEXT="Brand Summary" FOLDED="true">
        <icon BUILTIN="image"/>
        <node TEXT="Logo" FOLDED="true"/>
        <node TEXT="Description: Revolutionizing Pakistan #39;s agriculture with elite livestock genetics, sustainable farming, and innovative irrigation solutions." FOLDED="true"/>
      </node>
      <node TEXT="Company Links" FOLDED="true">
        <icon BUILTIN="list"/>
        <node TEXT="Home" LINK="https://dayzee.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Services" LINK="https://dayzee.com/service/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_service.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Quick Links" FOLDED="true">
        <icon BUILTIN="list"/>
        <node TEXT="About Us" LINK="https://dayzee.com/about/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_faqs.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Follow us at" FOLDED="true">
        <icon BUILTIN="list"/>
        <node TEXT="Facebook - DayZee Farms" LINK="https://www.facebook.com/dayzeefarm" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.facebook.com_dayzeefarm.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.tiktok.com_dayzee.pvt.ltd.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Instagram - DayZee Farms" LINK="https://www.instagram.com/dayzeefarms/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_dayzeefarms.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Youtube - DayZee Farms" LINK="https://www.youtube.com/@DayZeeFarms" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.youtube.com_DayZeeFarms.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Copyright" FOLDED="true">
        <node TEXT="Copyright  #169; 2025 DayZee. All Rights Reserved" FOLDED="true"/>
      </node>
    </node>
  </node>
</map>
