<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home - Teamup Ventures">
    <node TEXT="Header">
      <node TEXT="Navigation">
        <node TEXT="Home" LINK="https://teamupventures.com/" />
        <node TEXT="The Pakistan Story" LINK="https://teamupventures.com/pakistan-story/" />
        <node TEXT="Our Team" LINK="https://teamupventures.com/#our-team" />
        <node TEXT="National Incubation Centre" LINK="https://nicpakistan.pk/" />
        <node TEXT="Scrapboard" LINK="https://teamupventures.com/#scrap-board" />
        <node TEXT="Contact   Careers" LINK="https://teamupventures.com/#contact-careers" />
      </node>
    </node>
    <node TEXT="Page Content">
      <node TEXT="The Pakistan Story">
        <node TEXT="Section Title: The Pakistan Story" />
        <node TEXT="Description">
          <node TEXT="Pakistan is on the verge of a new digital era. A young population, low unemployment and a growing middle class position Pakistan to become one of the most promising economies for investors in the coming decade." />
        </node>
        <node TEXT="READ MORE" LINK="https://teamupventures.com/pakistan-story/" />
      </node>
      <node TEXT="Scrapboard">
        <node TEXT="Section Title: Scrapboard - blog   news" />
        <node TEXT="Featured Articles">
          <node TEXT="The Era of VCs and Boom of Startups">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/the-era-of-vcs-and-boom-of-start-ups/" />
          </node>
          <node TEXT="To Survive Pakistan's COVID Pandemic, Grocery Stores Go Online">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/to-survive-pakistans-covid-pandemic-grocery-stores-go-online/" />
          </node>
          <node TEXT="Clicky.pk attracts $700,000 in pre-series A funding round">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/clicky-pk-attracts-700000-in-pre-series-a-funding-round/" />
          </node>
          <node TEXT="Pakistan's 'Sehat Kahani' Raises $1 Million Pre-Series A to Grow its Telemedicine Network">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network/" />
          </node>
          <node TEXT="Startup Challenges: The Way Out">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/startup-challenges-the-way-out/" />
          </node>
          <node TEXT="Pak Tech Startup 'Remotebase' Raises $1.4 Million Led by Indus Valley Capital">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital/" />
          </node>
          <node TEXT="Islamabad-based Startup Called 'Shopsy' Introduces Voice Search for its Customers">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers/" />
          </node>
          <node TEXT="Pakistani Fintech Startup Called 'PayPro' Receives a Grant of Rs 7.4 Million from USAID and SMEA">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea/" />
          </node>
          <node TEXT="Local Startup is Using AI to Detect COVID-19">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/local-startup-is-using-ai-to-detect-covid-19/" />
          </node>
          <node TEXT="HumWell Comes To Rescue, With An All-Inclusive Telehealth Service">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service/" />
          </node>
          <node TEXT="Pakistan's First E-commerce Marketing Tool Launched by Pakistani Entrepreneur to Make E-commerce More Competitive">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive/" />
          </node>
          <node TEXT="Pakistani Startups Break Records in 2020 Despite Global Economic Slowdown">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-startups-break-records-in-2020-despite-global-economic-slowdown/" />
          </node>
          <node TEXT="Pakistan's 'Truck It In' Raises $1.5 Million Pre-Seed for its Trucking Marketplace">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace/" />
          </node>
          <node TEXT="Pakistani EdTech Startup 'Edkasa' Raises $320,000 Pre-Seed by Launching an Exam Prep App for Students">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students/" />
          </node>
          <node TEXT="Pakistan Launches Growth Funds for Startups">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistan-launches-growth-funds-for-startups/" />
          </node>
          <node TEXT="Bayfikr – a User-Friendly Fin-Tech app, Making Payments in Pakistan Easier for Overseas Pakistanis">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis/" />
          </node>
          <node TEXT="Pakistani Fintech SadaPay Raises $7.2 Million in Country's Largest Seed Round">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round/" />
          </node>
          <node TEXT="Despite a Pandemic, Pakistani Startups Had Their Best Year Yet With Over $65 Million in Funding">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding/" />
          </node>
          <node TEXT="NIC Welcomes It's 10th Cohort of Startups">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/nic-welcomes-its-10th-cohort-of-startups/" />
          </node>
          <node TEXT="For a Successful Startup Ecosystem, Pakistan Needs to Learn to Celebrate Failure">
            <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure/" />
          </node>
        </node>
      </node>
      <node TEXT="Contact   Careers" LINK="https://teamupventures.com/#contact-careers">
        <node TEXT="Contact   Careers Form">
          <node TEXT="YOUR NAME *" />
          <node TEXT="YOUR EMAIL *" />
          <node TEXT="COMPANY *" />
          <node TEXT="SUBJECT *" />
          <node TEXT="YOUR MESSAGE *" />
          <node TEXT="GET IN TOUCH (Button)" LINK="https://teamupventures.com/#contact-careers" />
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Company Info">
        <node TEXT="Teamup Ventures" />
        <node TEXT="Licensed and regulated by the Dubai Financial Services Authority" />
        <node TEXT="Company Number: 4684" />
        <node TEXT="DUBAI OFFICE" />
        <node TEXT="Teamup Ventures" />
        <node TEXT="Level 1 Gate Avenue – South" LINK="https://maps.app.goo.gl/6TW76qnbMrejyLBt6" />
        <node TEXT="Dubai International Financial Centre (DIFC)" LINK="https://maps.app.goo.gl/yuURWpV31zyayDeN7" />
        <node TEXT="PO Box 50 70 33" />
        <node TEXT="Dubai, UAE" />
        <node TEXT="Other Contact" />
        <node TEXT="contact@teamupventures.com" LINK="mailto:contact@teamupventures.com" />
      </node>
      <node TEXT="Social Media">
        <node TEXT="Twitter" LINK="https://twitter.com/VenturesTeamup" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/teamupventures/" />
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/teamup-ventures/" />
      </node>
      <node TEXT="Terms   Conditions" LINK="https://teamupventures.com/terms-conditions/" />
    </node>
  </node>
</map>