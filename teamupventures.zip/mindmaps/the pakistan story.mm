<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="the pakistan story">
    <node TEXT="Key Economic Facts">
      <node TEXT="Population: 225M (5th largest, 132.6M below 30)" />
      <node TEXT="Nominal GDP (FY 2021): $297B" />
      <node TEXT="Net Exports (2020): $22.5B" />
      <node TEXT="GDP Per Capita, PPP (2021F): $5230" />
      <node TEXT="Inflation: 8.2%" />
      <node TEXT="Remittances (2021): $29.4B" />
      <node TEXT="Unemployment Rate: 4.5%" />
      <node TEXT="Real GDP Growth Rate (2021F): 4.7%" />
    </node>
    <node TEXT="Demographic Facts">
      <node TEXT="Population growth chart (1980-2030)" />
      <node TEXT="GDP growth chart (1980-2030)" />
    </node>
    <node TEXT="Startup Ecosystem">
      <node TEXT="Startup funding and deals in Pakistan (2015-2021)" />
      <node TEXT="Key facts about startup ecosystem" />
      <node TEXT="$579M+ raised by Pakistani startups since 2015" />
      <node TEXT="$259M+ funding raised in 2021" />
      <node TEXT="700+ startups launched till date" />
      <node TEXT="83 incubators and accelerators" />
      <node TEXT="World Bank Ease of Doing Business: +28 places in 2020" />
    </node>
    <node TEXT="Rapidly Growing Digital Infrastructure">
      <node TEXT="Opportunities from fast digital   connectivity growth" />
      <node TEXT="Pakistan shifting towards digital financial inclusion" />
      <node TEXT="Exponential growth in connectivity" />
      <node TEXT="98% of households own a mobile phone" />
      <node TEXT="103 million broadband subscribers" />
    </node>
  </node>
</map>