<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home Page">
    <node TEXT="Header">
      <node TEXT="Logo" />
      <node TEXT="Navigation">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/">
          <node TEXT="The Power of Part-time Impact">
            <node TEXT="Re-imagining Work Life - Founding story and purpose" />
          </node>
          <node TEXT="Vision Mission">
            <node TEXT="Vision: To unlock the full potential of the workforce." />
            <node TEXT="Mission: Strengthen businesses by building blended, human-centered teams." />
          </node>
          <node TEXT="Our Values">
            <node TEXT="Community, Impact, Stewardship, Courage - Company values summary" />
          </node>
          <node TEXT="Recent Recognition">
            <node TEXT="Awards and distinctions section" />
          </node>
          <node TEXT="Staff Team">
            <node TEXT="Brea Starmer - Founder, CEO">
              <node TEXT="Bio" LINK="https://lionsandtigers.com/brea-starmer" />
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer" />
            </node>
            <node TEXT="Ashley Jude - President">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude" />
            </node>
            <node TEXT="Lorraine Cunningham - Chief Technology Financial Officer">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine" />
            </node>
            <node TEXT="LaShunte Portrey - Business Development">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/" />
            </node>
            <node TEXT="Steven Rowe - Client Experience">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe" />
            </node>
            <node TEXT="Reiko Kono - Client Experience">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" />
            </node>
            <node TEXT="Shannon Lee - Client Experience Team">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/" />
            </node>
            <node TEXT="Nan Jackson - Marketing">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson" />
            </node>
            <node TEXT="Miranda Leurquin - Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/" />
            </node>
            <node TEXT="Jocylynn Kelley - Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/" />
            </node>
            <node TEXT="Allison Monat - Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat" />
            </node>
            <node TEXT="Mercedes Dunn - Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/" />
            </node>
          </node>
          <node TEXT="Work With Us">
            <node TEXT="Clients">
              <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/">
                <node TEXT="Page Introduction">
                  <node TEXT="Interested in hiring our consultants? Complete this form and we #39;ll be in touch shortly." />
                  <node TEXT="Interested in joining our team of consultants?">
                    <node TEXT="here" LINK="https://lionsandtigers.com/join-our-team" />
                  </node>
                </node>
                <node TEXT="Contact Form">
                  <node TEXT="First Name" />
                  <node TEXT="Last Name" />
                  <node TEXT="Title" />
                  <node TEXT="Organization" />
                  <node TEXT="Email" />
                  <node TEXT="Phone" />
                  <node TEXT="Message" />
                  <node TEXT="Captcha" />
                  <node TEXT="Submit Button" />
                </node>
              </node>
            </node>
            <node TEXT="Talent">
              <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
            </node>
          </node>
        </node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/">
          <node TEXT="Workforce Reimagined">
            <node TEXT="Summary: Unlocking the Power of Blended Teams, data on workforce models, blended teams as solution." />
            <node TEXT="Read the Research Report">
              <node TEXT="Link: Read the Research Report" LINK="https://lionsandtigers.com/why-now/" />
            </node>
          </node>
          <node TEXT="American workforce at inflection point">
            <node TEXT="Summary: Key stats – Women leaving workforce, rise in freelancers, gig work, independent work, job shifts for women." />
          </node>
          <node TEXT="Why This Study">
            <node TEXT="Summary: Reasons for the study, anecdotal proof, need for data, partnership with Read the Room Advisors, study goals." />
            <node TEXT="Brea Starmer">
              <node TEXT="Link: Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/" />
            </node>
          </node>
          <node TEXT="Blended Teams Work: Key findings">
            <node TEXT="Summary: Specialized skills as edge, quality over cost, speed and innovation, loss disrupts business outcomes." />
          </node>
          <node TEXT="The Value Compounds Over Time">
            <node TEXT="Summary: Longer tenure with blended teams increases strategic advantage and focus on quality, innovation, and speed." />
          </node>
          <node TEXT="Blended teams: Integral for current and future work">
            <node TEXT="Summary: Blended teams accepted for the future of work, trusted by experts and advisors." />
          </node>
          <node TEXT="Why It Matters">
            <node TEXT="Summary: Blended teams are not a stopgap—support women/caregivers, address AI disruption, grow independence." />
          </node>
          <node TEXT="2025 Blended Workforce Survey">
            <node TEXT="Summary: Run by Read the Room Advisors, predictive analytics for business impact, final report available." />
            <node TEXT="Download Full Survey Report">
              <node TEXT="Link: Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/" />
            </node>
          </node>
        </node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/">
          <node TEXT="Built For Fortune 500s   Startups" />
          <node TEXT="Working together">
            <node TEXT="ROAR Results" />
          </node>
          <node TEXT="Engagement Model Overview">
            <node TEXT="Full-time   Fractional" />
            <node TEXT="Individuals   Teams" />
            <node TEXT="Time   Outcome Based" />
          </node>
          <node TEXT="Capabilities   Skillsets">
            <node TEXT="Communications   Marketing" />
            <node TEXT="Operations" />
            <node TEXT="Change" />
            <node TEXT="See Capabilities   Skillsets Section">
              <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" />
            </node>
          </node>
          <node TEXT="Client Stories">
            <node TEXT="Read Case Studies">
              <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" />
            </node>
          </node>
          <node TEXT="Work with us">
            <node TEXT="Clients">
              <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
            </node>
            <node TEXT="Talent">
              <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
            </node>
          </node>
        </node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/">
          <node TEXT="Join Our Team Introduction">
            <node TEXT="Inclusive community of specialists; value high-impact work   flexibility" />
            <node TEXT="EXPLORE OPEN ROLES">
              <node TEXT="EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles" />
            </node>
          </node>
          <node TEXT="What it means to be a great place to work">
            <node TEXT="Flexible roles, putting people first, conscious investment in community" />
            <node TEXT="Values   Benefits">
              <node TEXT="Flexibility - Open to a variety of work hours" />
              <node TEXT="Community - Join a network of outstanding people" />
              <node TEXT="Values - Driven by stewardship, courage, impact, and alignment" />
              <node TEXT="Resources   Growth - Access library, best practices, support" />
              <node TEXT="Remote Work - Work from home or anywhere" />
              <node TEXT="Transparency - Open team communications and resources" />
              <node TEXT="DEI-Actively anti-racist organization, learn more">
                <node TEXT="more" LINK="https://lionsandtigers.com/dei" />
              </node>
            </node>
          </node>
          <node TEXT="Open Roles">
            <node TEXT="Job Listings">
              <node TEXT="Locations: Seattle, WA, United States" />
              <node TEXT="Data Analyst (consultant)" />
              <node TEXT="Events Manager (consultant)" />
              <node TEXT="Communications Manager (consultant)" />
              <node TEXT="Introduce Yourself! (Apply for any position)" />
              <node TEXT="Change Management (consultant)" />
              <node TEXT="Project Manager (consultant)" />
            </node>
            <node TEXT="Consultant Profile Updates Form">
              <node TEXT="Fields">
                <node TEXT="Name" />
                <node TEXT="Availability" />
                <node TEXT="Resume" />
                <node TEXT="Other details" />
              </node>
            </node>
          </node>
          <node TEXT="Key Metrics   Highlights">
            <node TEXT="97.5% consultant retention rate" />
            <node TEXT="$34M paid out to consultants" />
            <node TEXT="100% remote or hybrid team" />
            <node TEXT="87% women representation" />
          </node>
          <node TEXT="What Happens After You Apply">
            <node TEXT="Step 1: Apply for a role via online application" />
            <node TEXT="Step 2: Real person reviews application" />
            <node TEXT="Step 3: Contact if fit for initial call" />
            <node TEXT="Step 4: No ghosting promise" />
            <node TEXT="CONSULTANT FAQ">
              <node TEXT="CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" />
            </node>
          </node>
          <node TEXT="From Our Team">
            <node TEXT="Testimonial: Charting own path, work-life balance, purpose" />
          </node>
          <node TEXT="Newsletter Signup">
            <node TEXT="SUBSCRIBE">
              <node TEXT="Email Address" />
              <node TEXT="SUBSCRIBE button" />
            </node>
          </node>
        </node>
        <node TEXT="Resources" LINK="">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/">
            <node TEXT="Avoiding the All-Or-Nothing Workplace: Enabling People to Operate at their Highest   Best Use">
              <node TEXT="By Brea Starmer, Founder/CEO" />
              <node TEXT="Download a pdf of the playbook">
                <node TEXT="here" LINK="https://lionsandtigers.com/playbook-download/" />
              </node>
              <node TEXT="Listen to the audio version.">
                <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" />
              </node>
            </node>
            <node TEXT="Contents">
              <node TEXT="The Future Now of Work" />
              <node TEXT="We Must Adopt Blended Work Ecosystems" />
              <node TEXT="Measuring Impact Over Hours" />
              <node TEXT="Highest   Best Use Operating System" />
              <node TEXT="Our Process of Establishing HBU" />
              <node TEXT="Unlocking HBU: High-EQ Change Management" />
              <node TEXT="Blending Our Workforce: Natalie’s Example" />
              <node TEXT="Building the Plane While You Fly It" />
              <node TEXT="Advice for Proliferating HBU" />
              <node TEXT="How to Convince Your Boss or Peers You Need HBU" />
              <node TEXT="The P L Benefits of a Blended Workforce" />
              <node TEXT="HR vs Procurement: Who Manages the Blended Workforce?" />
              <node TEXT="A Few Things to Dream About" />
              <node TEXT="Commitments to Diversity are Now Public" />
              <node TEXT="Portable Benefits for Independent Workers" />
              <node TEXT="Hybrid   Flex Work Permanence" />
              <node TEXT="In Conclusion" />
            </node>
            <node TEXT="Featured Section: How I Lost My Job and Found My Way">
              <node TEXT="Founder’s story and introduction to hybrid work movement." />
              <node TEXT="Link: since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave" />
            </node>
            <node TEXT="The Workplace Isn’t Working for Everyone">
              <node TEXT="Explains workplace struggles and changing work trends." />
              <node TEXT="Link: business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace" />
              <node TEXT="Link: Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/" />
            </node>
            <node TEXT="The “Great Resignation” and Losing Those We Most Seek">
              <node TEXT="Outlines resignations and challenges in retaining talent." />
              <node TEXT="Link: 30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45" />
              <node TEXT="Link: employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/" />
              <node TEXT="Link: One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers" />
              <node TEXT="Link: disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics" />
              <node TEXT="Link: black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12" />
            </node>
            <node TEXT="We Must Adopt Blended Work Ecosystems">
              <node TEXT="Describes shift to more flexible, blended workforce and demand for remote work." />
              <node TEXT="Link: 70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/" />
              <node TEXT="Link: Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx" />
              <node TEXT="Link: research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity" />
              <node TEXT="Link: MITSloan" LINK="https://shop.sloanreview.mit.edu/store/workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work" />
            </node>
            <node TEXT="Measuring Impact Over Hours">
              <node TEXT="Urges focus on impact and outcomes, not just hours worked." />
            </node>
            <node TEXT="Reimagining the Workplace with HBU Operating System">
              <node TEXT="Introduction to Highest   Best Use framework for work allocation." />
            </node>
            <node TEXT="The Highest   Best Use Operating System">
              <node TEXT="Explains the HBU framework and its benefits." />
            </node>
            <node TEXT="The 3Ms of HBU">
              <node TEXT="Summarizes Magnet, Momentum, Maximum—core principles of the system." />
            </node>
            <node TEXT="Applying the 3Ms to our Blended Work Ecosystem">
              <node TEXT="Description of organizational layers and blended models." />
            </node>
            <node TEXT="Our Process of Establishing HBU">
              <node TEXT="Outlines the step-by-step approach for HBU in organizations." />
              <node TEXT="First Step: Highest   Best ORGANIZATION" />
              <node TEXT="Second Step: Highest   Best YOU" />
              <node TEXT="Third Step: Highest   Best COMMUNITY" />
            </node>
            <node TEXT="Stitching It All Together: Your Ecosystem is Unique">
              <node TEXT="Shows how the 3Ms combine to create unique flexible ecosystems." />
            </node>
            <node TEXT="Unlocking HBU: High-EQ Change Management">
              <node TEXT="Approach to emotional intelligence in leading workplace change." />
              <node TEXT="Link: Dr. Renee St. Jacques" LINK="https://www.reneestjacques.com/" />
            </node>
            <node TEXT="Blending Our Workforce: Natalie’s Example">
              <node TEXT="Practical case study applying HBU steps to a blended workforce." />
            </node>
            <node TEXT="Building the Plane While You Fly It">
              <node TEXT="Encouragement and analogy for evolving work practices." />
            </node>
            <node TEXT="Very Practical Advice for Proliferating HBU">
              <node TEXT="Actionable, step-by-step guidance for implementing HBU." />
            </node>
            <node TEXT="How to Convince Your Boss or Peers You Need HBU">
              <node TEXT="Tips for building a business case and securing buy-in." />
            </node>
            <node TEXT="The P L Benefits of a Blended Workforce">
              <node TEXT="Financial and productivity benefits comparison for workforce models." />
            </node>
            <node TEXT="Human Resources vs Procurement: Management Debate">
              <node TEXT="Describes roles of HR and procurement in managing blended workforce." />
            </node>
            <node TEXT="A Few Things to Dream About">
              <node TEXT="Forward-looking ideas and trends for innovative workforces." />
              <node TEXT="Link: FLEX network" LINK="https://www.webwire.com/ViewPressRel.asp?aId=242981" />
              <node TEXT="Link: public version in the Netherlands" LINK="https://unileverfreelancers.talent-pool.com/" />
              <node TEXT="Link: Josh Bersin highlights" LINK="https://joshbersin.com/2019/07/the-company-as-a-talent-network-unilever-and-schneider-electric-show-the-way/" />
              <node TEXT="Link: Jon Younger recently published" LINK="https://www.forbes.com/sites/jonyounger/2022/12/01/six-ways-that-freelancers-will-improve-project-team-engagement-and-performance/?sh=45f3f32f1b81" />
            </node>
            <node TEXT="Commitments to Diversity are Now Public">
              <node TEXT="Describes DEI progress, transparency, and importance." />
              <node TEXT="Link: public commitment" LINK="https://docs.google.com/spreadsheets/d/11OBEAG8yQs3olTDDFwt6PoSy9Lqjk9cWslCc-H_ytyo/edit#gid=0" />
              <node TEXT="Link: Measure Up initiative" LINK="https://www.prnewswire.com/news-releases/fortune-and-refinitiv-encourage-unprecedented-corporate-diversity-disclosure-and-accountability-through-new-measure-up-partnership-301159688.html" />
              <node TEXT="Link: Diverse company lists like these" LINK="https://vervoe.com/most-diverse-companies/" />
              <node TEXT="Link: inclusive approach to procurement" LINK="https://hbr.org/2020/08/why-you-need-a-supplier-diversity-program" />
            </node>
            <node TEXT="Portable Benefits for Independent Workers">
              <node TEXT="Highlights need for benefits portability for freelancers and independents." />
              <node TEXT="Link: National Conference of State Legislators" LINK="https://www.ncsl.org/research/labor-and-employment/portable-benefits-for-gig-workers.aspx#:~:text=Policymakers%2C%20industry%20innovators%2C%20labor%20organizers,and%20drive%20broader%20economic%20prosperity." />
              <node TEXT="Link: potential" LINK="https://www.aspeninstitute.org/publications/designing-portable-benefits/" />
            </node>
            <node TEXT="Hybrid   Flex Work Permanence">
              <node TEXT="Flexibility in location, schedule, and organizational value." />
              <node TEXT="Link: According to Gallup" LINK="https://www.gallup.com/workplace/390632/future-hybrid-work-key-questions-answered-data.aspx" />
              <node TEXT="Link: enable non-linear days" LINK="https://www.bbc.com/worklife/article/20220928-the-non-linear-workdays-changing-the-shape-of-productivity" />
              <node TEXT="Link: flexible work policy examples" LINK="https://www.shrm.org/resourcesandtools/tools-and-samples/policies/pages/cms_000593.aspx#:~:text=Flextime%2C%20in%20which%20an%20employee,leave%20earlier%20in%20the%20afternoon." />
              <node TEXT="Link: Mercer reports" LINK="https://www.mercer.us/content/dam/mercer/attachments/north-america/us/us-2022-inside-employees-minds-infographic.pdf?utm_source=marketo&amp;utm_medium=email&amp;utm_campaign=NSW1&amp;utm_term=rethinking-the-way-we-work-flexible-work-policies&amp;utm_content=newsletter&amp;utm_country=us&amp;adobe_mc=MCMID%3D28544653033654653390475691018962050474%7CMCORGID%3D7205F0F5559E57A87F000101%2540AdobeOrg%7CTS%3D1671228362" />
            </node>
            <node TEXT="In Conclusion">
              <node TEXT="Summarizes call to action for workplace change." />
            </node>
            <node TEXT="Sources">
              <node TEXT="Collection of research, citations, and further reading." />
              <node TEXT="Link: a pdf version" LINK="https://lionsandtigers.com/playbook-download/" />
              <node TEXT="Link: Blog" LINK="https://lionsandtigers.com/blog/" />
            </node>
          </node>
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/">
            <node TEXT="Courage at Work">
              <node TEXT="Overview">
                <node TEXT="Welcome to our courageous community." />
              </node>
            </node>
            <node TEXT="Content Categories">
              <node TEXT="Thought Leadership   Best Practices">
                <node TEXT="Category Link">
                  <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/" />
                  <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/" />
                </node>
              </node>
              <node TEXT="New   Noteworthy">
                <node TEXT="Category Link">
                  <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/" />
                  <node TEXT="new" LINK="https://lionsandtigers.com/category/new/" />
                </node>
              </node>
              <node TEXT="People   Projects">
                <node TEXT="Category Link">
                  <node TEXT="people" LINK="https://lionsandtigers.com/category/people/" />
                </node>
              </node>
            </node>
            <node TEXT="Featured Posts">
              <node TEXT="Workforce Reimagined Research Launch Event">
                <node TEXT="Event Summary" />
                <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" />
              </node>
              <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic">
                <node TEXT="Picnic Highlights" />
                <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" />
              </node>
              <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive">
                <node TEXT="Empower   Support Women in Workplaces" />
                <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" />
              </node>
              <node TEXT="Elevating Culture   Community:  Miranda Leurquin’s New Chapter at L T">
                <node TEXT="Team Member Impact and Story" />
                <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" />
              </node>
              <node TEXT="Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog" />
            </node>
            <node TEXT="Newsletter Signup">
              <node TEXT="Form">
                <node TEXT="Email" />
                <node TEXT="SUBSCRIBE" />
              </node>
              <node TEXT="Newsletter Info">
                <node TEXT="Learn about solutions, success stories, best practices, and thought leadership" />
              </node>
            </node>
          </node>
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/">
            <node TEXT="Client Newsletter">
              <node TEXT="Summary: Solutions, success stories, best practices, and thought leadership." />
              <node TEXT="Form">
                <node TEXT="Enter Your email address" />
                <node TEXT="SUBSCRIBE" />
              </node>
            </node>
            <node TEXT="Talent Newsletter">
              <node TEXT="Summary: Open roles, events, and talent news from Lions   Tigers." />
              <node TEXT="Form">
                <node TEXT="Enter Your email address" />
                <node TEXT="SUBSCRIBE" />
              </node>
            </node>
            <node TEXT="Work with us">
              <node TEXT="Clients">
                <node TEXT="TALK TO US">
                  <node TEXT="Talk to Us" LINK="https://lionsandtigers.com/talk-to-us/" />
                </node>
              </node>
              <node TEXT="Talent">
                <node TEXT="JOIN OUR TEAM">
                  <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
                </node>
              </node>
            </node>
          </node>
        </node>
        
      </node>
      <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" />
    </node>
    <node TEXT="Main Content">
      <node TEXT="Hero Section">
        <node TEXT="Build Your Dream Team" />
        <node TEXT="Description: Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." />
        <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" />
        <node TEXT="Hero Image" />
      </node>
      <node TEXT="Trusted By">
        <node TEXT="Logos: Minecraft, Tribute, Xbox, Ada Developers Academy, Alaska Airlines, GitHub, Microsoft" />
      </node>
      <node TEXT="Model Section">
        <node TEXT="Our model fits your needs   our people" />
        <node TEXT="Description: We design the solutions that fit your needs – today   tomorrow." />
        <node TEXT="Full-time   Fractional" />
        <node TEXT="Individuals   Teams" />
        <node TEXT="Time   Outcome Based" />
      </node>
      <node TEXT="Clients   Talent Section">
        <node TEXT="CLIENTS">
          <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" />
        </node>
        <node TEXT="TALENT">
          <node TEXT="JOIN OUR TEAM (Button)" LINK="https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
      <node TEXT="Testimonial Section">
        <node TEXT="A Word From Our Clients" />
        <node TEXT="Testimonial: Lions   Tigers brings a talented team of experts..." />
        <node TEXT="DeAnna Paddleford, Change Management Strategy Lead" />
      </node>
      <node TEXT="Playbook Section">
        <node TEXT="Want to build a culture of high performance   belonging?" />
        <node TEXT="Description: We built a playbook for leaders who are thinking about workforce innovation..." />
        <node TEXT="LEARN MORE (Button)" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
      </node>
      <node TEXT="Vision   Mission Section">
        <node TEXT="Vision: To unlock the full potential of the workforce." />
        <node TEXT="Mission: We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." />
        <node TEXT="OUR STORY (Button)" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Team Image" />
      </node>
      <node TEXT="Work with us Section" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Logo" />
      <node TEXT="Description: PROFESSIONAL STAFFING   WORKFORCE SOLUTIONS PARTNER" />
      <node TEXT="About Us">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/" />
      </node>
      <node TEXT="Solutions">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together" />
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model" />
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" />
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" />
      </node>
      <node TEXT="Resources">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" />
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/" />
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/" />
      </node>
      <node TEXT="Newsletter">
        <node TEXT="Description: Learn about our solutions, our success stories, best practices, and thought leadership." />
        <node TEXT="Email (Form Field)" />
      </node>
      <node TEXT="Social Media">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" />
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" />
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" />
      </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/" />
      <node TEXT="Do Not Sell or Share My Personal Information (Button)" />
      <node TEXT="Cookie Policy" />
    </node>
    
  </node>
</map>