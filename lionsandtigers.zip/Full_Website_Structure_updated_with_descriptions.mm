<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Home Page" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo" FOLDED="true"/>
      <node TEXT="Navigation" FOLDED="true">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" FOLDED="true">
          <node TEXT="The Power of Part-time Impact" FOLDED="true">
            <node TEXT="Re-imagining Work Life - Founding story and purpose" FOLDED="true"/>
          </node>
          <node TEXT="Vision Mission" FOLDED="true">
            <node TEXT="Vision: To unlock the full potential of the workforce." FOLDED="true"/>
            <node TEXT="Mission: Strengthen businesses by building blended, human-centered teams." FOLDED="true"/>
          </node>
          <node TEXT="Our Values" FOLDED="true">
            <node TEXT="Community, Impact, Stewardship, Courage - Company values summary" FOLDED="true"/>
          </node>
          <node TEXT="Recent Recognition" FOLDED="true">
            <node TEXT="Awards and distinctions section" FOLDED="true"/>
          </node>
          <node TEXT="Staff Team" FOLDED="true">
            <node TEXT="Brea Starmer - Founder, CEO" FOLDED="true">
              <node TEXT="Bio" LINK="https://lionsandtigers.com/brea-starmer" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_brea-starmer.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Ashley Jude - President" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_ashleyjude.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Lorraine Cunningham - Chief Technology Financial Officer" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_cunninghamlorraine.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LaShunte Portrey - Business Development" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_lashunteportrey.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Steven Rowe - Client Experience" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_sttrowe.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Reiko Kono - Client Experience" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_reiko-kono-161056171.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Shannon Lee - Client Experience Team" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_shannon-lee13.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Nan Jackson - Marketing" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_nanbjackson.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Miranda Leurquin - Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_mirandaleurquin.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Jocylynn Kelley - Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_jocylynn-kelley.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Allison Monat - Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_allisonsmonat.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Mercedes Dunn - Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_mercedesdunn.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Work With Us" FOLDED="true">
            <node TEXT="Clients" FOLDED="true">
              <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true">
                <node TEXT="Page Introduction" FOLDED="true">
                  <node TEXT="Interested in hiring our consultants? Complete this form and we #39;ll be in touch shortly." FOLDED="true"/>
                  <node TEXT="Interested in joining our team of consultants?" FOLDED="true">
                    <node TEXT="here" LINK="https://lionsandtigers.com/join-our-team" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                  </node>
                </node>
                <node TEXT="Contact Form" FOLDED="true">
                  <node TEXT="First Name" FOLDED="true"/>
                  <node TEXT="Last Name" FOLDED="true"/>
                  <node TEXT="Title" FOLDED="true"/>
                  <node TEXT="Organization" FOLDED="true"/>
                  <node TEXT="Email" FOLDED="true"/>
                  <node TEXT="Phone" FOLDED="true"/>
                  <node TEXT="Message" FOLDED="true"/>
                  <node TEXT="Captcha" FOLDED="true"/>
                  <node TEXT="Submit Button" FOLDED="true"/>
                </node>
              <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Talent" FOLDED="true">
              <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" FOLDED="true">
          <node TEXT="Workforce Reimagined" FOLDED="true">
            <node TEXT="Summary: Unlocking the Power of Blended Teams, data on workforce models, blended teams as solution." FOLDED="true"/>
            <node TEXT="Read the Research Report" FOLDED="true">
              <node TEXT="Link: Read the Research Report" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="American workforce at inflection point" FOLDED="true">
            <node TEXT="Summary: Key stats – Women leaving workforce, rise in freelancers, gig work, independent work, job shifts for women." FOLDED="true"/>
          </node>
          <node TEXT="Why This Study" FOLDED="true">
            <node TEXT="Summary: Reasons for the study, anecdotal proof, need for data, partnership with Read the Room Advisors, study goals." FOLDED="true"/>
            <node TEXT="Brea Starmer" FOLDED="true">
              <node TEXT="Link: Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Blended Teams Work: Key findings" FOLDED="true">
            <node TEXT="Summary: Specialized skills as edge, quality over cost, speed and innovation, loss disrupts business outcomes." FOLDED="true"/>
          </node>
          <node TEXT="The Value Compounds Over Time" FOLDED="true">
            <node TEXT="Summary: Longer tenure with blended teams increases strategic advantage and focus on quality, innovation, and speed." FOLDED="true"/>
          </node>
          <node TEXT="Blended teams: Integral for current and future work" FOLDED="true">
            <node TEXT="Summary: Blended teams accepted for the future of work, trusted by experts and advisors." FOLDED="true"/>
          </node>
          <node TEXT="Why It Matters" FOLDED="true">
            <node TEXT="Summary: Blended teams are not a stopgap—support women/caregivers, address AI disruption, grow independence." FOLDED="true"/>
          </node>
          <node TEXT="2025 Blended Workforce Survey" FOLDED="true">
            <node TEXT="Summary: Run by Read the Room Advisors, predictive analytics for business impact, final report available." FOLDED="true"/>
            <node TEXT="Download Full Survey Report" FOLDED="true">
              <node TEXT="Link: Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" FOLDED="true">
          <node TEXT="Built For Fortune 500s   Startups" FOLDED="true"/>
          <node TEXT="Working together" FOLDED="true">
            <node TEXT="ROAR Results" FOLDED="true"/>
          </node>
          <node TEXT="Engagement Model Overview" FOLDED="true">
            <node TEXT="Full-time   Fractional" FOLDED="true"/>
            <node TEXT="Individuals   Teams" FOLDED="true"/>
            <node TEXT="Time   Outcome Based" FOLDED="true"/>
          </node>
          <node TEXT="Capabilities   Skillsets" FOLDED="true">
            <node TEXT="Communications   Marketing" FOLDED="true"/>
            <node TEXT="Operations" FOLDED="true"/>
            <node TEXT="Change" FOLDED="true"/>
            <node TEXT="See Capabilities   Skillsets Section" FOLDED="true">
              <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_capabilities-skillsets.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Client Stories" FOLDED="true">
            <node TEXT="Read Case Studies" FOLDED="true">
              <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_client-stories.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Work with us" FOLDED="true">
            <node TEXT="Clients" FOLDED="true">
              <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Talent" FOLDED="true">
              <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true">
          <node TEXT="Join Our Team Introduction" FOLDED="true">
            <node TEXT="Inclusive community of specialists; value high-impact work   flexibility" FOLDED="true"/>
            <node TEXT="EXPLORE OPEN ROLES" FOLDED="true">
              <node TEXT="EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team_open-roles.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="What it means to be a great place to work" FOLDED="true">
            <node TEXT="Flexible roles, putting people first, conscious investment in community" FOLDED="true"/>
            <node TEXT="Values   Benefits" FOLDED="true">
              <node TEXT="Flexibility - Open to a variety of work hours" FOLDED="true"/>
              <node TEXT="Community - Join a network of outstanding people" FOLDED="true"/>
              <node TEXT="Values - Driven by stewardship, courage, impact, and alignment" FOLDED="true"/>
              <node TEXT="Resources   Growth - Access library, best practices, support" FOLDED="true"/>
              <node TEXT="Remote Work - Work from home or anywhere" FOLDED="true"/>
              <node TEXT="Transparency - Open team communications and resources" FOLDED="true"/>
              <node TEXT="DEI-Actively anti-racist organization, learn more" FOLDED="true">
                <node TEXT="more" LINK="https://lionsandtigers.com/dei" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_dei.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
          </node>
          <node TEXT="Open Roles" FOLDED="true">
            <node TEXT="Job Listings" FOLDED="true">
              <node TEXT="Locations: Seattle, WA, United States" FOLDED="true"/>
              <node TEXT="Data Analyst (consultant)" FOLDED="true"/>
              <node TEXT="Events Manager (consultant)" FOLDED="true"/>
              <node TEXT="Communications Manager (consultant)" FOLDED="true"/>
              <node TEXT="Introduce Yourself! (Apply for any position)" FOLDED="true"/>
              <node TEXT="Change Management (consultant)" FOLDED="true"/>
              <node TEXT="Project Manager (consultant)" FOLDED="true"/>
            </node>
            <node TEXT="Consultant Profile Updates Form" FOLDED="true">
              <node TEXT="Fields" FOLDED="true">
                <node TEXT="Name" FOLDED="true"/>
                <node TEXT="Availability" FOLDED="true"/>
                <node TEXT="Resume" FOLDED="true"/>
                <node TEXT="Other details" FOLDED="true"/>
              </node>
            </node>
          </node>
          <node TEXT="Key Metrics   Highlights" FOLDED="true">
            <node TEXT="97.5% consultant retention rate" FOLDED="true"/>
            <node TEXT="$34M paid out to consultants" FOLDED="true"/>
            <node TEXT="100% remote or hybrid team" FOLDED="true"/>
            <node TEXT="87% women representation" FOLDED="true"/>
          </node>
          <node TEXT="What Happens After You Apply" FOLDED="true">
            <node TEXT="Step 1: Apply for a role via online application" FOLDED="true"/>
            <node TEXT="Step 2: Real person reviews application" FOLDED="true"/>
            <node TEXT="Step 3: Contact if fit for initial call" FOLDED="true"/>
            <node TEXT="Step 4: No ghosting promise" FOLDED="true"/>
            <node TEXT="CONSULTANT FAQ" FOLDED="true">
              <node TEXT="CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_consultant-faq.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="From Our Team" FOLDED="true">
            <node TEXT="Testimonial: Charting own path, work-life balance, purpose" FOLDED="true"/>
          </node>
          <node TEXT="Newsletter Signup" FOLDED="true">
            <node TEXT="SUBSCRIBE" FOLDED="true">
              <node TEXT="Email Address" FOLDED="true"/>
              <node TEXT="SUBSCRIBE button" FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Resources" LINK="" FOLDED="true">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true">
            <node TEXT="Avoiding the All-Or-Nothing Workplace: Enabling People to Operate at their Highest   Best Use" FOLDED="true">
              <node TEXT="By Brea Starmer, Founder/CEO" FOLDED="true"/>
              <node TEXT="Download a pdf of the playbook" FOLDED="true">
                <node TEXT="here" LINK="https://lionsandtigers.com/playbook-download/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_playbook-download.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Listen to the audio version." FOLDED="true">
                <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_player.captivate.fm_episode_ae64d6e2-5fb9-49fb-95e8-46d0a2433c68.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Contents" FOLDED="true">
              <node TEXT="The Future Now of Work" FOLDED="true"/>
              <node TEXT="We Must Adopt Blended Work Ecosystems" FOLDED="true"/>
              <node TEXT="Measuring Impact Over Hours" FOLDED="true"/>
              <node TEXT="Highest   Best Use Operating System" FOLDED="true"/>
              <node TEXT="Our Process of Establishing HBU" FOLDED="true"/>
              <node TEXT="Unlocking HBU: High-EQ Change Management" FOLDED="true"/>
              <node TEXT="Blending Our Workforce: Natalie’s Example" FOLDED="true"/>
              <node TEXT="Building the Plane While You Fly It" FOLDED="true"/>
              <node TEXT="Advice for Proliferating HBU" FOLDED="true"/>
              <node TEXT="How to Convince Your Boss or Peers You Need HBU" FOLDED="true"/>
              <node TEXT="The P L Benefits of a Blended Workforce" FOLDED="true"/>
              <node TEXT="HR vs Procurement: Who Manages the Blended Workforce?" FOLDED="true"/>
              <node TEXT="A Few Things to Dream About" FOLDED="true"/>
              <node TEXT="Commitments to Diversity are Now Public" FOLDED="true"/>
              <node TEXT="Portable Benefits for Independent Workers" FOLDED="true"/>
              <node TEXT="Hybrid   Flex Work Permanence" FOLDED="true"/>
              <node TEXT="In Conclusion" FOLDED="true"/>
            </node>
            <node TEXT="Featured Section: How I Lost My Job and Found My Way" FOLDED="true">
              <node TEXT="Founder’s story and introduction to hybrid work movement." FOLDED="true"/>
              <node TEXT="Link: since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.fatherly.com_news_75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="The Workplace Isn’t Working for Everyone" FOLDED="true">
              <node TEXT="Explains workplace struggles and changing work trends." FOLDED="true"/>
              <node TEXT="Link: business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.mckinsey.com_featured-insights_diversity-and-inclusion_women-in-the-workplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.pewresearch.org_fact-tank_2022_03_09_majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disres.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="The “Great Resignation” and Losing Those We Most Seek" FOLDED="true">
              <node TEXT="Outlines resignations and challenges in retaining talent." FOLDED="true"/>
              <node TEXT="Link: 30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_en.wikipedia.org_wiki_Labor_force_in_the_United_States_cite_note-45.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.superstaff.com_blog_top-20-great-resignation-statistics.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.latimes.com_politics_story_2021-08-18_pandemic-pushes-moms-to-scale-back-or-quit-their-careers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.fastcompany.com_90848858_women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.businessinsider.com_black-women-leaving-corporate-america-entreprenurship-startups-2022-12.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="We Must Adopt Blended Work Ecosystems" FOLDED="true">
              <node TEXT="Describes shift to more flexible, blended workforce and demand for remote work." FOLDED="true"/>
              <node TEXT="Link: 70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.zippia.com_advice_how-many-freelancers-in-the-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.gallup.com_workplace_397751_returning-office-current-preferred-future-state-remote-work.aspx.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.vox.com_recode_23129752_work-from-home-productivity.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: MITSloan" LINK="https://shop.sloanreview.mit.edu/store/workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_shop.sloanreview.mit.edu_store_workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Measuring Impact Over Hours" FOLDED="true">
              <node TEXT="Urges focus on impact and outcomes, not just hours worked." FOLDED="true"/>
            </node>
            <node TEXT="Reimagining the Workplace with HBU Operating System" FOLDED="true">
              <node TEXT="Introduction to Highest   Best Use framework for work allocation." FOLDED="true"/>
            </node>
            <node TEXT="The Highest   Best Use Operating System" FOLDED="true">
              <node TEXT="Explains the HBU framework and its benefits." FOLDED="true"/>
            </node>
            <node TEXT="The 3Ms of HBU" FOLDED="true">
              <node TEXT="Summarizes Magnet, Momentum, Maximum—core principles of the system." FOLDED="true"/>
            </node>
            <node TEXT="Applying the 3Ms to our Blended Work Ecosystem" FOLDED="true">
              <node TEXT="Description of organizational layers and blended models." FOLDED="true"/>
            </node>
            <node TEXT="Our Process of Establishing HBU" FOLDED="true">
              <node TEXT="Outlines the step-by-step approach for HBU in organizations." FOLDED="true"/>
              <node TEXT="First Step: Highest   Best ORGANIZATION" FOLDED="true"/>
              <node TEXT="Second Step: Highest   Best YOU" FOLDED="true"/>
              <node TEXT="Third Step: Highest   Best COMMUNITY" FOLDED="true"/>
            </node>
            <node TEXT="Stitching It All Together: Your Ecosystem is Unique" FOLDED="true">
              <node TEXT="Shows how the 3Ms combine to create unique flexible ecosystems." FOLDED="true"/>
            </node>
            <node TEXT="Unlocking HBU: High-EQ Change Management" FOLDED="true">
              <node TEXT="Approach to emotional intelligence in leading workplace change." FOLDED="true"/>
              <node TEXT="Link: Dr. Renee St. Jacques" LINK="https://www.reneestjacques.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.reneestjacques.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Blending Our Workforce: Natalie’s Example" FOLDED="true">
              <node TEXT="Practical case study applying HBU steps to a blended workforce." FOLDED="true"/>
            </node>
            <node TEXT="Building the Plane While You Fly It" FOLDED="true">
              <node TEXT="Encouragement and analogy for evolving work practices." FOLDED="true"/>
            </node>
            <node TEXT="Very Practical Advice for Proliferating HBU" FOLDED="true">
              <node TEXT="Actionable, step-by-step guidance for implementing HBU." FOLDED="true"/>
            </node>
            <node TEXT="How to Convince Your Boss or Peers You Need HBU" FOLDED="true">
              <node TEXT="Tips for building a business case and securing buy-in." FOLDED="true"/>
            </node>
            <node TEXT="The P L Benefits of a Blended Workforce" FOLDED="true">
              <node TEXT="Financial and productivity benefits comparison for workforce models." FOLDED="true"/>
            </node>
            <node TEXT="Human Resources vs Procurement: Management Debate" FOLDED="true">
              <node TEXT="Describes roles of HR and procurement in managing blended workforce." FOLDED="true"/>
            </node>
            <node TEXT="A Few Things to Dream About" FOLDED="true">
              <node TEXT="Forward-looking ideas and trends for innovative workforces." FOLDED="true"/>
              <node TEXT="Link: FLEX network" LINK="https://www.webwire.com/ViewPressRel.asp?aId=242981" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.webwire.com_ViewPressRel.asp_aId_242981.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: public version in the Netherlands" LINK="https://unileverfreelancers.talent-pool.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_unileverfreelancers.talent-pool.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: Josh Bersin highlights" LINK="https://joshbersin.com/2019/07/the-company-as-a-talent-network-unilever-and-schneider-electric-show-the-way/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_joshbersin.com_2019_07_the-company-as-a-talent-network-unilever-and-schneider-electric-show-the-way.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: Jon Younger recently published" LINK="https://www.forbes.com/sites/jonyounger/2022/12/01/six-ways-that-freelancers-will-improve-project-team-engagement-and-performance/?sh=45f3f32f1b81" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.forbes.com_sites_jonyounger_2022_12_01_six-ways-that-freelancers-will-improve-project-team-engagement-and-performance_sh_45f3f32f1b81.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Commitments to Diversity are Now Public" FOLDED="true">
              <node TEXT="Describes DEI progress, transparency, and importance." FOLDED="true"/>
              <node TEXT="Link: public commitment" LINK="https://docs.google.com/spreadsheets/d/11OBEAG8yQs3olTDDFwt6PoSy9Lqjk9cWslCc-H_ytyo/edit#gid=0" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_docs.google.com_spreadsheets_d_11OBEAG8yQs3olTDDFwt6PoSy9Lqjk9cWslCc-H_ytyo_edit_gid_0.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: Measure Up initiative" LINK="https://www.prnewswire.com/news-releases/fortune-and-refinitiv-encourage-unprecedented-corporate-diversity-disclosure-and-accountability-through-new-measure-up-partnership-301159688.html" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.prnewswire.com_news-releases_fortune-and-refinitiv-encourage-unprecedented-corporate-diversity-disclosure-and-accountability-through-new-mea.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: Diverse company lists like these" LINK="https://vervoe.com/most-diverse-companies/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_vervoe.com_most-diverse-companies.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: inclusive approach to procurement" LINK="https://hbr.org/2020/08/why-you-need-a-supplier-diversity-program" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_hbr.org_2020_08_why-you-need-a-supplier-diversity-program.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Portable Benefits for Independent Workers" FOLDED="true">
              <node TEXT="Highlights need for benefits portability for freelancers and independents." FOLDED="true"/>
              <node TEXT="Link: National Conference of State Legislators" LINK="https://www.ncsl.org/research/labor-and-employment/portable-benefits-for-gig-workers.aspx#:~:text=Policymakers%2C%20industry%20innovators%2C%20labor%20organizers,and%20drive%20broader%20economic%20prosperity." FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.ncsl.org_research_labor-and-employment_portable-benefits-for-gig-workers.aspx_~_text_Policymakers_2C_20industry_20innovators_2C_20labor_20or.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: potential" LINK="https://www.aspeninstitute.org/publications/designing-portable-benefits/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.aspeninstitute.org_publications_designing-portable-benefits.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Hybrid   Flex Work Permanence" FOLDED="true">
              <node TEXT="Flexibility in location, schedule, and organizational value." FOLDED="true"/>
              <node TEXT="Link: According to Gallup" LINK="https://www.gallup.com/workplace/390632/future-hybrid-work-key-questions-answered-data.aspx" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.gallup.com_workplace_390632_future-hybrid-work-key-questions-answered-data.aspx.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: enable non-linear days" LINK="https://www.bbc.com/worklife/article/20220928-the-non-linear-workdays-changing-the-shape-of-productivity" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.bbc.com_worklife_article_20220928-the-non-linear-workdays-changing-the-shape-of-productivity.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: flexible work policy examples" LINK="https://www.shrm.org/resourcesandtools/tools-and-samples/policies/pages/cms_000593.aspx#:~:text=Flextime%2C%20in%20which%20an%20employee,leave%20earlier%20in%20the%20afternoon." FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.shrm.org_resourcesandtools_tools-and-samples_policies_pages_cms_000593.aspx_~_text_Flextime_2C_20in_20which_20an_20employee,leave_20earlier_.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: Mercer reports" LINK="https://www.mercer.us/content/dam/mercer/attachments/north-america/us/us-2022-inside-employees-minds-infographic.pdf?utm_source=marketo&amp;utm_medium=email&amp;utm_campaign=NSW1&amp;utm_term=rethinking-the-way-we-work-flexible-work-policies&amp;utm_content=newsletter&amp;utm_country=us&amp;adobe_mc=MCMID%3D28544653033654653390475691018962050474%7CMCORGID%3D7205F0F5559E57A87F000101%2540AdobeOrg%7CTS%3D1671228362" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.mercer.us_content_dam_mercer_attachments_north-america_us_us-2022-inside-employees-minds-infographic.pdf_utm_source_marketo_utm_medium_email.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="In Conclusion" FOLDED="true">
              <node TEXT="Summarizes call to action for workplace change." FOLDED="true"/>
            </node>
            <node TEXT="Sources" FOLDED="true">
              <node TEXT="Collection of research, citations, and further reading." FOLDED="true"/>
              <node TEXT="Link: a pdf version" LINK="https://lionsandtigers.com/playbook-download/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_playbook-download.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Link: Blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true">
            <node TEXT="Courage at Work" FOLDED="true">
              <node TEXT="Overview" FOLDED="true">
                <node TEXT="Welcome to our courageous community." FOLDED="true"/>
              </node>
            </node>
            <node TEXT="Content Categories" FOLDED="true">
              <node TEXT="Thought Leadership   Best Practices" FOLDED="true">
                <node TEXT="Category Link" FOLDED="true">
                  <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_thought-leadership.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                  <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_best-practices.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
              <node TEXT="New   Noteworthy" FOLDED="true">
                <node TEXT="Category Link" FOLDED="true">
                  <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_noteworthy.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                  <node TEXT="new" LINK="https://lionsandtigers.com/category/new/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_new.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
              <node TEXT="People   Projects" FOLDED="true">
                <node TEXT="Category Link" FOLDED="true">
                  <node TEXT="people" LINK="https://lionsandtigers.com/category/people/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_people.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
            </node>
            <node TEXT="Featured Posts" FOLDED="true">
              <node TEXT="Workforce Reimagined Research Launch Event" FOLDED="true">
                <node TEXT="Event Summary" FOLDED="true"/>
                <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_workforce-reimagined-research-launch-event.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic" FOLDED="true">
                <node TEXT="Picnic Highlights" FOLDED="true"/>
                <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive" FOLDED="true">
                <node TEXT="Empower   Support Women in Workplaces" FOLDED="true"/>
                <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Elevating Culture   Community:  Miranda Leurquin’s New Chapter at L T" FOLDED="true">
                <node TEXT="Team Member Impact and Story" FOLDED="true"/>
                <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_elevating-culture-community-miranda-hickmans-new-chapter-at-lt.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog_page_2_et_blog.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Newsletter Signup" FOLDED="true">
              <node TEXT="Form" FOLDED="true">
                <node TEXT="Email" FOLDED="true"/>
                <node TEXT="SUBSCRIBE" FOLDED="true"/>
              </node>
              <node TEXT="Newsletter Info" FOLDED="true">
                <node TEXT="Learn about solutions, success stories, best practices, and thought leadership" FOLDED="true"/>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" FOLDED="true">
            <node TEXT="Client Newsletter" FOLDED="true">
              <node TEXT="Summary: Solutions, success stories, best practices, and thought leadership." FOLDED="true"/>
              <node TEXT="Form" FOLDED="true">
                <node TEXT="Enter Your email address" FOLDED="true"/>
                <node TEXT="SUBSCRIBE" FOLDED="true"/>
              </node>
            </node>
            <node TEXT="Talent Newsletter" FOLDED="true">
              <node TEXT="Summary: Open roles, events, and talent news from Lions   Tigers." FOLDED="true"/>
              <node TEXT="Form" FOLDED="true">
                <node TEXT="Enter Your email address" FOLDED="true"/>
                <node TEXT="SUBSCRIBE" FOLDED="true"/>
              </node>
            </node>
            <node TEXT="Work with us" FOLDED="true">
              <node TEXT="Clients" FOLDED="true">
                <node TEXT="TALK TO US" FOLDED="true">
                  <node TEXT="Talk to Us" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
              <node TEXT="Talent" FOLDED="true">
                <node TEXT="JOIN OUR TEAM" FOLDED="true">
                  <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        
      </node>
      <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Build Your Dream Team" FOLDED="true"/>
        <node TEXT="Description: Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." FOLDED="true"/>
        <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Hero Image" FOLDED="true"/>
      </node>
      <node TEXT="Trusted By" FOLDED="true">
        <node TEXT="Logos: Minecraft, Tribute, Xbox, Ada Developers Academy, Alaska Airlines, GitHub, Microsoft" FOLDED="true"/>
      </node>
      <node TEXT="Model Section" FOLDED="true">
        <node TEXT="Our model fits your needs   our people" FOLDED="true"/>
        <node TEXT="Description: We design the solutions that fit your needs – today   tomorrow." FOLDED="true"/>
        <node TEXT="Full-time   Fractional" FOLDED="true"/>
        <node TEXT="Individuals   Teams" FOLDED="true"/>
        <node TEXT="Time   Outcome Based" FOLDED="true"/>
      </node>
      <node TEXT="Clients   Talent Section" FOLDED="true">
        <node TEXT="CLIENTS" FOLDED="true">
          <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="TALENT" FOLDED="true">
          <node TEXT="JOIN OUR TEAM (Button)" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
      <node TEXT="Testimonial Section" FOLDED="true">
        <node TEXT="A Word From Our Clients" FOLDED="true"/>
        <node TEXT="Testimonial: Lions   Tigers brings a talented team of experts..." FOLDED="true"/>
        <node TEXT="DeAnna Paddleford, Change Management Strategy Lead" FOLDED="true"/>
      </node>
      <node TEXT="Playbook Section" FOLDED="true">
        <node TEXT="Want to build a culture of high performance   belonging?" FOLDED="true"/>
        <node TEXT="Description: We built a playbook for leaders who are thinking about workforce innovation..." FOLDED="true"/>
        <node TEXT="LEARN MORE (Button)" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Vision   Mission Section" FOLDED="true">
        <node TEXT="Vision: To unlock the full potential of the workforce." FOLDED="true"/>
        <node TEXT="Mission: We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." FOLDED="true"/>
        <node TEXT="OUR STORY (Button)" LINK="https://lionsandtigers.com/our-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Team Image" FOLDED="true"/>
      </node>
      <node TEXT="Work with us Section" FOLDED="true"/>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Logo" FOLDED="true"/>
      <node TEXT="Description: PROFESSIONAL STAFFING   WORKFORCE SOLUTIONS PARTNER" FOLDED="true"/>
      <node TEXT="About Us" FOLDED="true">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_dei.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Solutions" FOLDED="true">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_working-together.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_engagement-model.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_capabilities-skillsets.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_client-stories.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Resources" FOLDED="true">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_media.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_general-inquiries.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Newsletter" FOLDED="true">
        <node TEXT="Description: Learn about our solutions, our success stories, best practices, and thought leadership." FOLDED="true"/>
        <node TEXT="Email (Form Field)" FOLDED="true"/>
      </node>
      <node TEXT="Social Media" FOLDED="true">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_company_lionsandtigers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_twitter.com_lionstigersco.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_lionstigersco.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.youtube.com_lionstigersco.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_privacy-policy.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Do Not Sell or Share My Personal Information (Button)" FOLDED="true"/>
      <node TEXT="Cookie Policy" FOLDED="true"/>
    </node>
    
  </node>
</map>
