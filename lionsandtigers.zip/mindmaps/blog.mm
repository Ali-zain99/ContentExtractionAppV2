<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="blog">
    <node TEXT="Courage at Work">
      <node TEXT="Overview">
        <node TEXT="Welcome to our courageous community." />
      </node>
    </node>
    <node TEXT="Content Categories">
      <node TEXT="Thought Leadership   Best Practices">
        <node TEXT="Category Link">
          <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/" />
          <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/" />
        </node>
      </node>
      <node TEXT="New   Noteworthy">
        <node TEXT="Category Link">
          <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/" />
          <node TEXT="new" LINK="https://lionsandtigers.com/category/new/" />
        </node>
      </node>
      <node TEXT="People   Projects">
        <node TEXT="Category Link">
          <node TEXT="people" LINK="https://lionsandtigers.com/category/people/" />
        </node>
      </node>
    </node>
    <node TEXT="Featured Posts">
      <node TEXT="Workforce Reimagined Research Launch Event">
        <node TEXT="Event Summary" />
        <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" />
      </node>
      <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic">
        <node TEXT="Picnic Highlights" />
        <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" />
      </node>
      <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive">
        <node TEXT="Empower   Support Women in Workplaces" />
        <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" />
      </node>
      <node TEXT="Elevating Culture   Community:  Miranda Leurquin’s New Chapter at L T">
        <node TEXT="Team Member Impact and Story" />
        <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" />
      </node>
      <node TEXT="Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog" />
    </node>
    <node TEXT="Newsletter Signup">
      <node TEXT="Form">
        <node TEXT="Email" />
        <node TEXT="SUBSCRIBE" />
      </node>
      <node TEXT="Newsletter Info">
        <node TEXT="Learn about solutions, success stories, best practices, and thought leadership" />
      </node>
    </node>
  </node>
</map>