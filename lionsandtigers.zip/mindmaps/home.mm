<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Professional Workforce   Staffing Solutions - Lions   Tigers">
    <node TEXT="Header">
      <node TEXT="Logo" />
      <node TEXT="Navigation">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" />
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        <node TEXT="Resources">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" />
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" />
        </node>
      </node>
      <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" />
    </node>
    <node TEXT="Page Content">
      <node TEXT="Hero Section">
        <node TEXT="Build Your Dream Team" />
        <node TEXT="Description: Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." />
        <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" />
        <node TEXT="Hero Image" />
      </node>
      <node TEXT="Trusted By">
        <node TEXT="Logos: Minecraft, Tribute, Xbox, Ada Developers Academy, Alaska Airlines, GitHub, Microsoft" />
      </node>
      <node TEXT="Model Section">
        <node TEXT="Our model fits your needs   our people" />
        <node TEXT="Description: We design the solutions that fit your needs – today   tomorrow." />
        <node TEXT="Full-time   Fractional" />
        <node TEXT="Individuals   Teams" />
        <node TEXT="Time   Outcome Based" />
      </node>
      <node TEXT="Clients   Talent Section">
        <node TEXT="CLIENTS">
          <node TEXT="TALK TO US (Button)" LINK="https://lionsandtigers.com/talk-to-us/" />
        </node>
        <node TEXT="TALENT">
          <node TEXT="JOIN OUR TEAM (Button)" LINK="https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
      <node TEXT="Testimonial Section">
        <node TEXT="A Word From Our Clients" />
        <node TEXT="Testimonial: Lions   Tigers brings a talented team of experts..." />
        <node TEXT="DeAnna Paddleford, Change Management Strategy Lead" />
      </node>
      <node TEXT="Playbook Section">
        <node TEXT="Want to build a culture of high performance   belonging?" />
        <node TEXT="Description: We built a playbook for leaders who are thinking about workforce innovation..." />
        <node TEXT="LEARN MORE (Button)" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
      </node>
      <node TEXT="Vision   Mission Section">
        <node TEXT="Vision: To unlock the full potential of the workforce." />
        <node TEXT="Mission: We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." />
        <node TEXT="OUR STORY (Button)" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Team Image" />
      </node>
      <node TEXT="Work with us Section" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Logo" />
      <node TEXT="Description: PROFESSIONAL STAFFING   WORKFORCE SOLUTIONS PARTNER" />
      <node TEXT="About Us">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/" />
      </node>
      <node TEXT="Solutions">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together" />
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model" />
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" />
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" />
      </node>
      <node TEXT="Resources">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" />
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/" />
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/" />
      </node>
      <node TEXT="Newsletter">
        <node TEXT="Description: Learn about our solutions, our success stories, best practices, and thought leadership." />
        <node TEXT="Email (Form Field)" />
      </node>
      <node TEXT="Social Media">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" />
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" />
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" />
      </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/" />
      <node TEXT="Do Not Sell or Share My Personal Information (Button)" />
      <node TEXT="Cookie Policy" />
    </node>
  </node>
</map>