<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="why now">
    <node TEXT="Workforce Reimagined">
      <node TEXT="Summary: Unlocking the Power of Blended Teams, data on workforce models, blended teams as solution." />
      <node TEXT="Read the Research Report">
        <node TEXT="Link: Read the Research Report" LINK="https://lionsandtigers.com/why-now/" />
      </node>
    </node>
    <node TEXT="American workforce at inflection point">
      <node TEXT="Summary: Key stats – Women leaving workforce, rise in freelancers, gig work, independent work, job shifts for women." />
    </node>
    <node TEXT="Why This Study">
      <node TEXT="Summary: Reasons for the study, anecdotal proof, need for data, partnership with Read the Room Advisors, study goals." />
      <node TEXT="Brea Starmer">
        <node TEXT="Link: Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/" />
      </node>
    </node>
    <node TEXT="Blended Teams Work: Key findings">
      <node TEXT="Summary: Specialized skills as edge, quality over cost, speed and innovation, loss disrupts business outcomes." />
    </node>
    <node TEXT="The Value Compounds Over Time">
      <node TEXT="Summary: Longer tenure with blended teams increases strategic advantage and focus on quality, innovation, and speed." />
    </node>
    <node TEXT="Blended teams: Integral for current and future work">
      <node TEXT="Summary: Blended teams accepted for the future of work, trusted by experts and advisors." />
    </node>
    <node TEXT="Why It Matters">
      <node TEXT="Summary: Blended teams are not a stopgap—support women/caregivers, address AI disruption, grow independence." />
    </node>
    <node TEXT="2025 Blended Workforce Survey">
      <node TEXT="Summary: Run by Read the Room Advisors, predictive analytics for business impact, final report available." />
      <node TEXT="Download Full Survey Report">
        <node TEXT="Link: Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/" />
      </node>
    </node>
  </node>
</map>