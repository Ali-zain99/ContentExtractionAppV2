<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="hybrid workplace playbook">
    <node TEXT="Avoiding the All-Or-Nothing Workplace: Enabling People to Operate at their Highest   Best Use">
      <node TEXT="By Brea Starmer, Founder/CEO" />
      <node TEXT="Download a pdf of the playbook">
        <node TEXT="here" LINK="https://lionsandtigers.com/playbook-download/" />
      </node>
      <node TEXT="Listen to the audio version.">
        <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" />
      </node>
    </node>
    <node TEXT="Contents">
      <node TEXT="The Future Now of Work" />
      <node TEXT="We Must Adopt Blended Work Ecosystems" />
      <node TEXT="Measuring Impact Over Hours" />
      <node TEXT="Highest   Best Use Operating System" />
      <node TEXT="Our Process of Establishing HBU" />
      <node TEXT="Unlocking HBU: High-EQ Change Management" />
      <node TEXT="Blending Our Workforce: Natalie’s Example" />
      <node TEXT="Building the Plane While You Fly It" />
      <node TEXT="Advice for Proliferating HBU" />
      <node TEXT="How to Convince Your Boss or Peers You Need HBU" />
      <node TEXT="The P L Benefits of a Blended Workforce" />
      <node TEXT="HR vs Procurement: Who Manages the Blended Workforce?" />
      <node TEXT="A Few Things to Dream About" />
      <node TEXT="Commitments to Diversity are Now Public" />
      <node TEXT="Portable Benefits for Independent Workers" />
      <node TEXT="Hybrid   Flex Work Permanence" />
      <node TEXT="In Conclusion" />
    </node>
    <node TEXT="Featured Section: How I Lost My Job and Found My Way">
      <node TEXT="Founder’s story and introduction to hybrid work movement." />
      <node TEXT="Link: since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave" />
    </node>
    <node TEXT="The Workplace Isn’t Working for Everyone">
      <node TEXT="Explains workplace struggles and changing work trends." />
      <node TEXT="Link: business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace" />
      <node TEXT="Link: Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/" />
    </node>
    <node TEXT="The “Great Resignation” and Losing Those We Most Seek">
      <node TEXT="Outlines resignations and challenges in retaining talent." />
      <node TEXT="Link: 30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45" />
      <node TEXT="Link: employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/" />
      <node TEXT="Link: One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers" />
      <node TEXT="Link: disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics" />
      <node TEXT="Link: black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12" />
    </node>
    <node TEXT="We Must Adopt Blended Work Ecosystems">
      <node TEXT="Describes shift to more flexible, blended workforce and demand for remote work." />
      <node TEXT="Link: 70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/" />
      <node TEXT="Link: Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx" />
      <node TEXT="Link: research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity" />
      <node TEXT="Link: MITSloan" LINK="https://shop.sloanreview.mit.edu/store/workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work" />
    </node>
    <node TEXT="Measuring Impact Over Hours">
      <node TEXT="Urges focus on impact and outcomes, not just hours worked." />
    </node>
    <node TEXT="Reimagining the Workplace with HBU Operating System">
      <node TEXT="Introduction to Highest   Best Use framework for work allocation." />
    </node>
    <node TEXT="The Highest   Best Use Operating System">
      <node TEXT="Explains the HBU framework and its benefits." />
    </node>
    <node TEXT="The 3Ms of HBU">
      <node TEXT="Summarizes Magnet, Momentum, Maximum—core principles of the system." />
    </node>
    <node TEXT="Applying the 3Ms to our Blended Work Ecosystem">
      <node TEXT="Description of organizational layers and blended models." />
    </node>
    <node TEXT="Our Process of Establishing HBU">
      <node TEXT="Outlines the step-by-step approach for HBU in organizations." />
      <node TEXT="First Step: Highest   Best ORGANIZATION" />
      <node TEXT="Second Step: Highest   Best YOU" />
      <node TEXT="Third Step: Highest   Best COMMUNITY" />
    </node>
    <node TEXT="Stitching It All Together: Your Ecosystem is Unique">
      <node TEXT="Shows how the 3Ms combine to create unique flexible ecosystems." />
    </node>
    <node TEXT="Unlocking HBU: High-EQ Change Management">
      <node TEXT="Approach to emotional intelligence in leading workplace change." />
      <node TEXT="Link: Dr. Renee St. Jacques" LINK="https://www.reneestjacques.com/" />
    </node>
    <node TEXT="Blending Our Workforce: Natalie’s Example">
      <node TEXT="Practical case study applying HBU steps to a blended workforce." />
    </node>
    <node TEXT="Building the Plane While You Fly It">
      <node TEXT="Encouragement and analogy for evolving work practices." />
    </node>
    <node TEXT="Very Practical Advice for Proliferating HBU">
      <node TEXT="Actionable, step-by-step guidance for implementing HBU." />
    </node>
    <node TEXT="How to Convince Your Boss or Peers You Need HBU">
      <node TEXT="Tips for building a business case and securing buy-in." />
    </node>
    <node TEXT="The P L Benefits of a Blended Workforce">
      <node TEXT="Financial and productivity benefits comparison for workforce models." />
    </node>
    <node TEXT="Human Resources vs Procurement: Management Debate">
      <node TEXT="Describes roles of HR and procurement in managing blended workforce." />
    </node>
    <node TEXT="A Few Things to Dream About">
      <node TEXT="Forward-looking ideas and trends for innovative workforces." />
      <node TEXT="Link: FLEX network" LINK="https://www.webwire.com/ViewPressRel.asp?aId=242981" />
      <node TEXT="Link: public version in the Netherlands" LINK="https://unileverfreelancers.talent-pool.com/" />
      <node TEXT="Link: Josh Bersin highlights" LINK="https://joshbersin.com/2019/07/the-company-as-a-talent-network-unilever-and-schneider-electric-show-the-way/" />
      <node TEXT="Link: Jon Younger recently published" LINK="https://www.forbes.com/sites/jonyounger/2022/12/01/six-ways-that-freelancers-will-improve-project-team-engagement-and-performance/?sh=45f3f32f1b81" />
    </node>
    <node TEXT="Commitments to Diversity are Now Public">
      <node TEXT="Describes DEI progress, transparency, and importance." />
      <node TEXT="Link: public commitment" LINK="https://docs.google.com/spreadsheets/d/11OBEAG8yQs3olTDDFwt6PoSy9Lqjk9cWslCc-H_ytyo/edit#gid=0" />
      <node TEXT="Link: Measure Up initiative" LINK="https://www.prnewswire.com/news-releases/fortune-and-refinitiv-encourage-unprecedented-corporate-diversity-disclosure-and-accountability-through-new-measure-up-partnership-301159688.html" />
      <node TEXT="Link: Diverse company lists like these" LINK="https://vervoe.com/most-diverse-companies/" />
      <node TEXT="Link: inclusive approach to procurement" LINK="https://hbr.org/2020/08/why-you-need-a-supplier-diversity-program" />
    </node>
    <node TEXT="Portable Benefits for Independent Workers">
      <node TEXT="Highlights need for benefits portability for freelancers and independents." />
      <node TEXT="Link: National Conference of State Legislators" LINK="https://www.ncsl.org/research/labor-and-employment/portable-benefits-for-gig-workers.aspx#:~:text=Policymakers%2C%20industry%20innovators%2C%20labor%20organizers,and%20drive%20broader%20economic%20prosperity." />
      <node TEXT="Link: potential" LINK="https://www.aspeninstitute.org/publications/designing-portable-benefits/" />
    </node>
    <node TEXT="Hybrid   Flex Work Permanence">
      <node TEXT="Flexibility in location, schedule, and organizational value." />
      <node TEXT="Link: According to Gallup" LINK="https://www.gallup.com/workplace/390632/future-hybrid-work-key-questions-answered-data.aspx" />
      <node TEXT="Link: enable non-linear days" LINK="https://www.bbc.com/worklife/article/20220928-the-non-linear-workdays-changing-the-shape-of-productivity" />
      <node TEXT="Link: flexible work policy examples" LINK="https://www.shrm.org/resourcesandtools/tools-and-samples/policies/pages/cms_000593.aspx#:~:text=Flextime%2C%20in%20which%20an%20employee,leave%20earlier%20in%20the%20afternoon." />
      <node TEXT="Link: Mercer reports" LINK="https://www.mercer.us/content/dam/mercer/attachments/north-america/us/us-2022-inside-employees-minds-infographic.pdf?utm_source=marketo&amp;utm_medium=email&amp;utm_campaign=NSW1&amp;utm_term=rethinking-the-way-we-work-flexible-work-policies&amp;utm_content=newsletter&amp;utm_country=us&amp;adobe_mc=MCMID%3D28544653033654653390475691018962050474%7CMCORGID%3D7205F0F5559E57A87F000101%2540AdobeOrg%7CTS%3D1671228362" />
    </node>
    <node TEXT="In Conclusion">
      <node TEXT="Summarizes call to action for workplace change." />
    </node>
    <node TEXT="Sources">
      <node TEXT="Collection of research, citations, and further reading." />
      <node TEXT="Link: a pdf version" LINK="https://lionsandtigers.com/playbook-download/" />
      <node TEXT="Link: Blog" LINK="https://lionsandtigers.com/blog/" />
    </node>
  </node>
</map>