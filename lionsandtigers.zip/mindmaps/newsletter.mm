<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="newsletter">
    <node TEXT="Client Newsletter">
      <node TEXT="Summary: Solutions, success stories, best practices, and thought leadership." />
      <node TEXT="Form">
        <node TEXT="Enter Your email address" />
        <node TEXT="SUBSCRIBE" />
      </node>
    </node>
    <node TEXT="Talent Newsletter">
      <node TEXT="Summary: Open roles, events, and talent news from Lions   Tigers." />
      <node TEXT="Form">
        <node TEXT="Enter Your email address" />
        <node TEXT="SUBSCRIBE" />
      </node>
    </node>
    <node TEXT="Work with us">
      <node TEXT="Clients">
        <node TEXT="TALK TO US">
          <node TEXT="Talk to Us" LINK="https://lionsandtigers.com/talk-to-us/" />
        </node>
      </node>
      <node TEXT="Talent">
        <node TEXT="JOIN OUR TEAM">
          <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
    </node>
  </node>
</map>