<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="solutions">
    <node TEXT="Built For Fortune 500s   Startups" />
    <node TEXT="Working together">
      <node TEXT="ROAR Results" />
    </node>
    <node TEXT="Engagement Model Overview">
      <node TEXT="Full-time   Fractional" />
      <node TEXT="Individuals   Teams" />
      <node TEXT="Time   Outcome Based" />
    </node>
    <node TEXT="Capabilities   Skillsets">
      <node TEXT="Communications   Marketing" />
      <node TEXT="Operations" />
      <node TEXT="Change" />
      <node TEXT="See Capabilities   Skillsets Section">
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" />
      </node>
    </node>
    <node TEXT="Client Stories">
      <node TEXT="Read Case Studies">
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" />
      </node>
    </node>
    <node TEXT="Work with us">
      <node TEXT="Clients">
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
      </node>
      <node TEXT="Talent">
        <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
      </node>
    </node>
  </node>
</map>