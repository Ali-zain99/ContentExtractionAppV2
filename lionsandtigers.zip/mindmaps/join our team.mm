<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="join our team">
    <node TEXT="Join Our Team Introduction">
      <node TEXT="Inclusive community of specialists; value high-impact work   flexibility" />
      <node TEXT="EXPLORE OPEN ROLES">
        <node TEXT="EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles" />
      </node>
    </node>
    <node TEXT="What it means to be a great place to work">
      <node TEXT="Flexible roles, putting people first, conscious investment in community" />
      <node TEXT="Values   Benefits">
        <node TEXT="Flexibility - Open to a variety of work hours" />
        <node TEXT="Community - Join a network of outstanding people" />
        <node TEXT="Values - Driven by stewardship, courage, impact, and alignment" />
        <node TEXT="Resources   Growth - Access library, best practices, support" />
        <node TEXT="Remote Work - Work from home or anywhere" />
        <node TEXT="Transparency - Open team communications and resources" />
        <node TEXT="DEI-Actively anti-racist organization, learn more">
          <node TEXT="more" LINK="https://lionsandtigers.com/dei" />
        </node>
      </node>
    </node>
    <node TEXT="Open Roles">
      <node TEXT="Job Listings">
        <node TEXT="Locations: Seattle, WA, United States" />
        <node TEXT="Data Analyst (consultant)" />
        <node TEXT="Events Manager (consultant)" />
        <node TEXT="Communications Manager (consultant)" />
        <node TEXT="Introduce Yourself! (Apply for any position)" />
        <node TEXT="Change Management (consultant)" />
        <node TEXT="Project Manager (consultant)" />
      </node>
      <node TEXT="Consultant Profile Updates Form">
        <node TEXT="Fields">
          <node TEXT="Name" />
          <node TEXT="Availability" />
          <node TEXT="Resume" />
          <node TEXT="Other details" />
        </node>
      </node>
    </node>
    <node TEXT="Key Metrics   Highlights">
      <node TEXT="97.5% consultant retention rate" />
      <node TEXT="$34M paid out to consultants" />
      <node TEXT="100% remote or hybrid team" />
      <node TEXT="87% women representation" />
    </node>
    <node TEXT="What Happens After You Apply">
      <node TEXT="Step 1: Apply for a role via online application" />
      <node TEXT="Step 2: Real person reviews application" />
      <node TEXT="Step 3: Contact if fit for initial call" />
      <node TEXT="Step 4: No ghosting promise" />
      <node TEXT="CONSULTANT FAQ">
        <node TEXT="CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" />
      </node>
    </node>
    <node TEXT="From Our Team">
      <node TEXT="Testimonial: Charting own path, work-life balance, purpose" />
    </node>
    <node TEXT="Newsletter Signup">
      <node TEXT="SUBSCRIBE">
        <node TEXT="Email Address" />
        <node TEXT="SUBSCRIBE button" />
      </node>
    </node>
  </node>
</map>