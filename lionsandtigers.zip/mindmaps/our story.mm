<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="our story">
    <node TEXT="The Power of   Part-time   Impact">
      <node TEXT="Re-imagining Work   Life - Founding story and purpose" />
    </node>
    <node TEXT="Vision   Mission">
      <node TEXT="Vision: To unlock the full potential of the workforce." />
      <node TEXT="Mission: Strengthen businesses by building blended, human-centered teams." />
    </node>
    <node TEXT="Our Values">
      <node TEXT="Community, Impact, Stewardship, Courage - Company values summary" />
    </node>
    <node TEXT="Recent Recognition">
      <node TEXT="Awards and distinctions section" />
    </node>
    <node TEXT="Staff Team">
      <node TEXT="Brea Starmer - Founder, CEO">
        <node TEXT="Bio" LINK="https://lionsandtigers.com/brea-starmer" />
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer" />
      </node>
      <node TEXT="Ashley Jude - President">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude" />
      </node>
      <node TEXT="Lorraine Cunningham - Chief Technology   Financial Officer">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine" />
      </node>
      <node TEXT="LaShunte Portrey - Business Development">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/" />
      </node>
      <node TEXT="Steven Rowe - Client Experience">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe" />
      </node>
      <node TEXT="Reiko Kono - Client Experience">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" />
      </node>
      <node TEXT="Shannon Lee - Client Experience Team">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/" />
      </node>
      <node TEXT="Nan Jackson - Marketing">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson" />
      </node>
      <node TEXT="Miranda Leurquin - Talent Advocacy">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/" />
      </node>
      <node TEXT="Jocylynn Kelley - Talent Advocacy">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/" />
      </node>
      <node TEXT="Allison Monat - Talent Advocacy">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat" />
      </node>
      <node TEXT="Mercedes Dunn - Talent Advocacy">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/" />
      </node>
    </node>
    <node TEXT="Work With Us">
      <node TEXT="Clients">
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
      </node>
      <node TEXT="Talent">
        <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
      </node>
    </node>
  </node>
</map>