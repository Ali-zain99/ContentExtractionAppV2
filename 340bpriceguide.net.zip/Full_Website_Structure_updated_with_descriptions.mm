<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home Page" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Home" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true">
        <node TEXT="Main Content" FOLDED="true">
          <node TEXT="Frequently Searched Products" FOLDED="true">
            <node TEXT="ADVAIR HFA 230-21..." LINK="https://www.340bpriceguide.net/340b-search#486" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_486.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="BREO ELLIPTA 100-25..." LINK="https://www.340bpriceguide.net/340b-search#488" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_488.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="BUTRANS 5 MCG/HR..." LINK="https://www.340bpriceguide.net/340b-search#14857" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_14857.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="DULERA 200 MCG-5..." LINK="https://www.340bpriceguide.net/340b-search#13331" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_13331.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="FARXIGA 10 MG TABL..." LINK="https://www.340bpriceguide.net/340b-search#116" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_116.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JANUVIA 100 MG TAB..." LINK="https://www.340bpriceguide.net/340b-search#534" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_534.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JARDIANCE 10 MG TA..." LINK="https://www.340bpriceguide.net/340b-search#185" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_185.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LANTUS SOLOSTAR 1..." LINK="https://www.340bpriceguide.net/340b-search#588" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_588.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LIDOCAINE 5% PATCH" LINK="https://www.340bpriceguide.net/340b-search#2310" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_2310.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LYRICA 100 MG CAPS..." LINK="https://www.340bpriceguide.net/340b-search#19309" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_19309.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="PROAIR RESPICLICK..." LINK="https://www.340bpriceguide.net/340b-search#18373" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_18373.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="TRADJENTA 5 MG TA..." LINK="https://www.340bpriceguide.net/340b-search#167" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_167.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="TRULICITY 1.5 MG/0...." LINK="https://www.340bpriceguide.net/340b-search#365" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_365.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="VICTOZA 2-PAK 18 M..." LINK="https://www.340bpriceguide.net/340b-search#13214" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_13214.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="XARELTO 10 MG TAB..." LINK="https://www.340bpriceguide.net/340b-search#9718" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_9718.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Comments" FOLDED="true">
            <node TEXT="Sophie Mengele" FOLDED="true">
              <node TEXT="Synjardy out of stock, issues with 340B discount at CVS." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="CVS pharmacy needs to enter the 340B coupon codes by first searching the TPPC code." FOLDED="true" />
            </node>
            <node TEXT="Tammy McCullough" FOLDED="true">
              <node TEXT="when can we expect the App to come back?" FOLDED="true"><node TEXT="Returns to the previous screen or step." FOLDED="true" /></node>
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Mobile app available on Apple Store or Google Play." FOLDED="true" />
            </node>
            <node TEXT="Steven Busselen" FOLDED="true">
              <node TEXT="Question about 90-day vs 1-year supply of Synjardy XR." FOLDED="true"><node TEXT="Displays information about the organization or product." FOLDED="true" /></node>
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Normal dosing for Synjardy is 2 tablets twice daily." FOLDED="true" />
            </node>
            <node TEXT="Sarah Munoz" FOLDED="true">
              <node TEXT="Is Levemir FlexPen 100unit/mL still covered?" FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Levemir discontinued; removed from 340B Price Guide." FOLDED="true" />
            </node>
            <node TEXT="Sandra Dardy" FOLDED="true">
              <node TEXT="is lispro or 70/30 insulin covered under 340b program?" FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Try searching &quot;Novolin&quot; or &quot;Novolog&quot;." FOLDED="true" />
            </node>
            <node TEXT="Kirk J." FOLDED="true">
              <node TEXT="Question about unit cost calculation on 340b Price Guide." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Select pharmacy, quantity, and patient group to see total estimated amount." FOLDED="true" />
            </node>
            <node TEXT="Anonymous" FOLDED="true">
              <node TEXT="How do I select medications from our formulary?" FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Use &quot;Choose Formulary&quot; option to select medications." FOLDED="true" />
            </node>
            <node TEXT="Kim Kelly" FOLDED="true">
              <node TEXT="Farxiga and symbicort availability at Genoa question." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Contacting 340B program manager about Genoa availability." FOLDED="true" />
            </node>
            <node TEXT="Kristan Stone" FOLDED="true">
              <node TEXT="is Pennsaid no longer on the 340b?" FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Try searching for DICLOFENAC 1.5% TOPICAL SOLN." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Levemir removed; see article for details." FOLDED="true" />
            </node>
            <node TEXT="Load more comments" FOLDED="true" />
          </node>
          <node TEXT="Search Comments" FOLDED="true">
            <node TEXT="Search Comments" FOLDED="true" />
            <node TEXT="Search" FOLDED="true">
              <node TEXT="set" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Sort by" FOLDED="true">
              <node TEXT="Newest" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Search Medication or NDC or Therap" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node><node TEXT="Executes a search query across site data." FOLDED="true" /></node>
      <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true">
        <node TEXT="Page Title" FOLDED="true">
          <node TEXT="Articles and News - 340B Price Guide" FOLDED="true" />
        </node>
        <node TEXT="Main Content" FOLDED="true">
          <node TEXT="Weekly Product Shortages" FOLDED="true">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Manufacturer 340B Restrictions for Oregon" FOLDED="true">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026" FOLDED="true">
            <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." FOLDED="true" />
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Bausch Health Exits the 340B Drug Pricing Program" FOLDED="true">
            <node TEXT="Effective October 1, 2025, Bausch Health has ended its participation in the 340B Drug Pricing Program." FOLDED="true" />
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="More Articles" FOLDED="true">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_140-communication-from-bphc-announcing-new-award-terms.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_139-rite-aid-winds-down-340b-operations.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_138-continued-brand-name-victoza-shortages.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Pagination" FOLDED="true">
            <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_8.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_12.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_16.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node><node TEXT="Moves to the next step in a process or wizard." FOLDED="true" /></node>
            <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true">
        <node TEXT="Main Content" FOLDED="true">
          <node TEXT="About" FOLDED="true">
            <node TEXT="340B Price Guide is a customized publication helping entities interpret drug prices." FOLDED="true" />
          </node>
          <node TEXT="340B Guided Services" FOLDED="true">
            <node TEXT="340B Price Guide, LLC offers independent consulting for covered entities." FOLDED="true" />
          </node>
          <node TEXT="Client Testimonials" FOLDED="true">
            <node TEXT="Marvin Roman, M.D." FOLDED="true">
              <node TEXT="340B Price Guide is excellent and saves time figuring out patient affordability." FOLDED="true" />
            </node>
            <node TEXT="Kylie Fonteno, PA-C" FOLDED="true">
              <node TEXT="340B Price Guide helps see patient savings and stay updated on price changes." FOLDED="true" />
            </node>
            <node TEXT="David Homyk" FOLDED="true">
              <node TEXT="340B Price Guide is excellent and helpful for staff communication." FOLDED="true" />
            </node>
            <node TEXT="Connie Serra, MD" FOLDED="true">
              <node TEXT="340B Price Guide was incredibly helpful in solving a pricing dilemma." FOLDED="true" />
            </node>
            <node TEXT="Charity Aguirre LPN" FOLDED="true">
              <node TEXT="340B pricing helped a patient afford medication." FOLDED="true" />
            </node>
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_about-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true">
        <node TEXT="Main Content" FOLDED="true">
          <node TEXT="Contact Form" FOLDED="true">
            <node TEXT="Name Field" FOLDED="true" />
            <node TEXT="Email Field" FOLDED="true" />
            <node TEXT="Company Field" FOLDED="true" />
            <node TEXT="Address Field" FOLDED="true" />
            <node TEXT="City, State Zip Field" FOLDED="true" />
            <node TEXT="Phone Field" FOLDED="true" />
            <node TEXT="Inquiry Type" FOLDED="true" />
            <node TEXT="Comment or Question" FOLDED="true"><node TEXT="Adds a note or feedback to an item." FOLDED="true" /></node>
            <node TEXT="Captcha" FOLDED="true" />
            <node TEXT="Submit" FOLDED="true"><node TEXT="Sends form data to the server." FOLDED="true" /></node>
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node><node TEXT="Opens contact form or company contact details." FOLDED="true" /></node>
      <node TEXT="Sign up" FOLDED="true"><node TEXT="Allows new users to create an account." FOLDED="true" /></node>
      <node TEXT="Login" FOLDED="true"><node TEXT="After Login Flow" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/" FOLDED="true">
        <node TEXT="Navigation" FOLDED="true" />
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true">
        <node TEXT="Search Medication or NDC or Therap" FOLDED="true" />
        <node TEXT="Please assign pharmacy from the portal first." FOLDED="true" />
        <node TEXT="1 TABLET" FOLDED="true" />
        <node TEXT="Choose Patient Group" FOLDED="true" />
        <node TEXT="Choose Formulary" FOLDED="true" />
        <node TEXT="Clear All Data" FOLDED="true" />
        <node TEXT="FREQUENTLY SEARCHED PRODUCTS" FOLDED="true">
          <node TEXT="ADVAIR HFA 230-21 MCG INHALERADVAIR HFA 230-21 MCG INHALER" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#486" FOLDED="true" />
          </node>
          <node TEXT="BREO ELLIPTA 100-25 MCG INHALRBREO ELLIPTA 100-25 MCG INHALR" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#488" FOLDED="true" />
          </node>
          <node TEXT="BUTRANS 5 MCG/HR PATCHBUTRANS 5 MCG/HR PATCH" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#14857" FOLDED="true" />
          </node>
          <node TEXT="DULERA 200 MCG-5 MCG INHALERDULERA 200 MCG-5 MCG INHALER" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#13331" FOLDED="true" />
          </node>
          <node TEXT="FARXIGA 10 MG TABLETFARXIGA 10 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#116" FOLDED="true" />
          </node>
          <node TEXT="JANUVIA 100 MG TABLETJANUVIA 100 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#534" FOLDED="true" />
          </node>
          <node TEXT="JARDIANCE 10 MG TABLETJARDIANCE 10 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#185" FOLDED="true" />
          </node>
          <node TEXT="LANTUS SOLOSTAR 100 UNIT/MLLANTUS SOLOSTAR 100 UNIT/ML" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#588" FOLDED="true" />
          </node>
          <node TEXT="LIDOCAINE 5% PATCHLIDOCAINE 5% PATCH" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#2310" FOLDED="true" />
          </node>
          <node TEXT="LYRICA 100 MG CAPSULELYRICA 100 MG CAPSULE" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#19309" FOLDED="true" />
          </node>
          <node TEXT="PROAIR RESPICLICK 90 MCG INHLRPROAIR RESPICLICK 90 MCG INHLR" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#18373" FOLDED="true" />
          </node>
          <node TEXT="TRADJENTA 5 MG TABLETTRADJENTA 5 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#167" FOLDED="true" />
          </node>
          <node TEXT="TRULICITY 1.5 MG/0.5 ML PENTRULICITY 1.5 MG/0.5 ML PEN" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#365" FOLDED="true" />
          </node>
          <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PENVICTOZA 2-PAK 18 MG/3 ML PEN" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#13214" FOLDED="true" />
          </node>
          <node TEXT="XARELTO 10 MG TABLETXARELTO 10 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#9718" FOLDED="true" />
          </node>
        </node>
        <node TEXT="COMMENTS" FOLDED="true">
          <node TEXT="What do you think?" FOLDED="true" />
          <node TEXT="Post" FOLDED="true" />
          <node TEXT="Search Comments" FOLDED="true" />
          <node TEXT="Sort by" FOLDED="true" />
          <node TEXT="Newest" FOLDED="true" />
          <node TEXT="Sophie Mengele" FOLDED="true">
            <node TEXT="I have tried sending in Synjardy to 2 different pharmacies now. Carrillo is out of stock and never called the pt back. I just sent it to CVS 2973 State Street and Pharmacy is stating that there is no discount (despite me sending in the discount with patient name and DOB) and that the patient needs to come in so that pricing can be discussed and they are not giving us confirmed 340B pricing over the phone. Is this how it normally works?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            <node TEXT="Responds to an existing comment or thread." FOLDED="true" /></node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            <node TEXT="Shares content via link or social media." FOLDED="true" /></node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="CVS pharmacy needs to enter the 340B coupon codes by first searching the TPPC code, not the BIN code. I'm noticing that CVS pharmacies are searching the 340B discount code by first searching the &quot;BIN&quot; number, which lists way too many options. If CVS pharmacy searches FIRST by the TPPC they can then find the right BIN and PCN codes. Once they enter it in the system, the 340B price will show." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Tammy McCullough" FOLDED="true">
            <node TEXT="when can we expect the App to come back?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Tammy, the mobile app has been available for several months. You can download from the Apple Store or Google Play. Here is a video on how to use the mobile app: https://www.340bpriceguide.net/articles-news/132-mobile-app-how-to-use" FOLDED="true"><node TEXT="Triggers file or report download." FOLDED="true" /></node>
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Steven Busselen" FOLDED="true">
            <node TEXT="I've noticed that a 1-year supply is often not much more expensive that a 90-day supply. However, CVS 222 W. Carrillo has been dispensing 90-day supplies of Synjardy XR 12.5/1000 when I order 730 tablets. Is CVS messing this up or am I?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="As you know, the normal dosing for Synjardy is 2 tablets twice daily, so a 90 day supply would be 180 tablets. Pharmacies are accustomed to dispensing up to 90 days at a time with refills. If a patient prescriber requests a greater day supply, you should explain and coordinate with the pharmacist. There may also be State Board of Pharmacy rules to consider as well." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Sarah Munoz" FOLDED="true">
            <node TEXT="Is Levemir FlexPen 100unit/mL still covered? I only see Levemir in the vial" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Sarah, in November 2023, Novo Nordisk announced it would discontinue Levemir with remaining supplies to end this year. It has fallen out of favor with patients and health plans. So we removed from 340B Price Guide. Here is the announcement. https://www.340bpriceguide.net/articles-news/118-novo-nordisk-will-discontinue-levemir" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Sandra Dardy" FOLDED="true">
            <node TEXT="is lispro or 70/30 insulin covered under 340b program?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Sandra, yes it is. Try searching &quot;Novolin&quot; or &quot;Novolog&quot;" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Kirk J." FOLDED="true">
            <node TEXT="On the 340b Price Guide is the unit cost $0.04 the cost per pill? So if the Rx was for 100 tablets x 0.04, it would be $4.00?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="On the far left, remember to select the pharmacy, quantity, and patient group. Once you've selected all, you can see the total estimated amount the patient will pay at the pharmacy." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Anonymous" FOLDED="true">
            <node TEXT="How do I select medications from our formulary?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Stacy, On the far left, where you search for medications, there is a drop-down option, &quot;Choose Formulary.&quot; If your clinic has a 340B formulary, you can select medications directly from there." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Kim Kelly" FOLDED="true">
            <node TEXT="I am seeing Farxiga and symbicort as available at Genoa on 340B but the Genoa pharmacists say they are not available. Am I using the website incorrectly?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Kim, I'll contact your 340B program manager to see what is going on here. There might be a data issue with the TPA or wholesaler setup and I will get back with you." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Kristan Stone" FOLDED="true">
            <node TEXT="is Pennsaid no longer on the 340b?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Unfortunately, it is not. Please try searching for DICLOFENAC 1.5% TOPICAL SOLN. Consider asking the pharmacy if they have in stock. It appears this item frequently runs low on supply" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Levemir has been removed from 340B Price Guide since Novo Nordisk will discontinue it. Please see the article: https://www.340bpriceguide.net/articles-news/118-novo-nordisk-will-discontinue-levemir" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Load more comments" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true">
        <node TEXT="Weekly Product Shortages" FOLDED="true">
          <node TEXT="Read more ..." FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true" />
          </node>
          <node TEXT="Print" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages?tmpl=component&amp;print=1&amp;layout=default" FOLDED="true" />
          <node TEXT="Sends current page or data to printer." FOLDED="true" /></node>
          <node TEXT="Email" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=48f36ca13f26e4d5730c8eb5ff22f26733881327" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Manufacturer 340B Restrictions for Oregon" FOLDED="true">
          <node TEXT="Read more ..." FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" FOLDED="true" />
          </node>
          <node TEXT="Print" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon?tmpl=component&amp;print=1&amp;layout=default" FOLDED="true" />
          </node>
          <node TEXT="Email" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=b6e19967b78cdac7c6c13cbbfc280d6e2dbb5cc9" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026" FOLDED="true">
          <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." FOLDED="true" />
          <node TEXT="Read more ..." FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" FOLDED="true" />
          </node>
          <node TEXT="Print" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026?tmpl=component&amp;print=1&amp;layout=default" FOLDED="true" />
          </node>
          <node TEXT="Email" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=7519cc1dcaee0c8a80b4e0ec10cc94c9d82ee5cb" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Bausch Health Exits the 340B Drug Pricing Program" FOLDED="true">
          <node TEXT="Effective October 1, 2025, Bausch Health has ended its participation in the 340B Drug Pricing Program. As a result, Bausch products are no longer considered covered outpatient drugs and are not eligible for 340B pricing." FOLDED="true" />
          <node TEXT="Read more ..." FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" FOLDED="true" />
          </node>
          <node TEXT="Print" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program?tmpl=component&amp;print=1&amp;layout=default" FOLDED="true" />
          </node>
          <node TEXT="Email" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=915b7f8f4733ba08ede3e87c060f748bad1a471b" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Pagination" FOLDED="true">
          <node TEXT="2" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true" />
          </node>
          <node TEXT="3" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=8" FOLDED="true" />
          </node>
          <node TEXT="4" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=12" FOLDED="true" />
          </node>
          <node TEXT="5" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=16" FOLDED="true" />
          </node>
          <node TEXT="6" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true" />
          </node>
          <node TEXT="7" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=24" FOLDED="true" />
          </node>
          <node TEXT="Next" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true" />
          </node>
          <node TEXT="End" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=24" FOLDED="true" />
          </node>
        </node>
        <node TEXT="More Articles" FOLDED="true">
          <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" FOLDED="true" />
          </node>
          <node TEXT="Communication from BPHC announcing new award terms" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" FOLDED="true" />
          </node>
          <node TEXT="Rite Aid Winds Down 340B Operations" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" FOLDED="true" />
          </node>
          <node TEXT="Continued Brand Name Victoza Shortages" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true">
        <node TEXT="340B Price Guide" FOLDED="true">
          <node TEXT="Customized publication for eligible health organizations, helps interpret drug prices and their impact on patient care." FOLDED="true" />
        </node>
        <node TEXT="340B Guided Services" FOLDED="true">
          <node TEXT="Independent consulting for covered entities, ensuring best practices and better health outcomes." FOLDED="true" />
        </node>
        <node TEXT="Client Testimonials" FOLDED="true">
          <node TEXT="Northwest Human Services" FOLDED="true">
            <node TEXT="340B Price Guide is excellent, saves time, helps patients afford meds, and is easy to navigate." FOLDED="true" />
          </node>
          <node TEXT="Beaufort Memorial Hospital" FOLDED="true">
            <node TEXT="340B Price Guide is excellent and helpful for communicating the 340B program to staff and physicians." FOLDED="true" />
          </node>
          <node TEXT="One Community Health" FOLDED="true">
            <node TEXT="340B Price Guide helped solve a dilemma with GoodRx and Walmart pricing." FOLDED="true" />
          </node>
          <node TEXT="CHC Lane County" FOLDED="true">
            <node TEXT="340B pricing helped a patient save money on Januvia." FOLDED="true"><node TEXT="Stores entered information without submitting." FOLDED="true" /></node>
          </node>
        </node>
        <node TEXT="www.hrsa.gov/opa" FOLDED="true">
          <node TEXT="www.hrsa.gov/opa" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_about-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true">
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="Name: *" FOLDED="true" />
          <node TEXT="Email: *" FOLDED="true" />
          <node TEXT="Company:" FOLDED="true" />
          <node TEXT="Address:" FOLDED="true" />
          <node TEXT="City, State Zip:" FOLDED="true" />
          <node TEXT="Phone:" FOLDED="true" />
          <node TEXT="Inquiry Type: *" FOLDED="true" />
          <node TEXT="Comment or Question: *" FOLDED="true" />
          <node TEXT="Captcha: *" FOLDED="true" />
          <node TEXT="SUBMIT" FOLDED="true" />
        </node>
        <node TEXT="info@340Bpriceguide.net" FOLDED="true">
          <node TEXT="mailto:info@340Bpriceguide.com" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_contact-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile" FOLDED="true">
        <node TEXT="ALI ZAIN" FOLDED="true">
          <node TEXT="Edit Profile" FOLDED="true">
            <node TEXT="Edit Profile" LINK="https://www.340bpriceguide.net/profile/profile?layout=edit" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_profile_profile_layout_edit.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="DETAILS" FOLDED="true">
          <node TEXT="Username: Ali" FOLDED="true" />
          <node TEXT="First Name: Ali" FOLDED="true" />
          <node TEXT="Last Name: Zain" FOLDED="true" />
          <node TEXT="Clinic/Hospital: ABC" FOLDED="true" />
          <node TEXT="Email Address: alizainsharif48@gmail.com" FOLDED="true">
            <node TEXT="alizainsharif48@gmail.com" LINK="mailto:alizainsharif48@gmail.com" FOLDED="true" />
          </node>
          <node TEXT="Phone Number" FOLDED="true" />
          <node TEXT="Default Pharmacy" FOLDED="true" />
          <node TEXT="Default Group" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_my-profile.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node><node TEXT="User profile details and account settings." FOLDED="true" /></node>
      <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_logout.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node><node TEXT="Ends user session and logs out of the system." FOLDED="true" /></node>
      <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message" FOLDED="true">
        <node TEXT="Send Secure Message" FOLDED="true">
          <node TEXT="Form" FOLDED="true">
            <node TEXT="Patient Name" FOLDED="true" />
            <node TEXT="Patient DOB" FOLDED="true" />
            <node TEXT="Pharmacy" FOLDED="true" />
            <node TEXT="Medication and Strength" FOLDED="true" />
            <node TEXT="Prescription Number (if available)" FOLDED="true" />
            <node TEXT="Contact at the pharmacy (if available)" FOLDED="true" />
            <node TEXT="Problem/Comment" FOLDED="true" />
          </node>
          <node TEXT="Submit" FOLDED="true">
            <node TEXT="Submit" FOLDED="true" />
          </node>
        <node TEXT="Opens a direct message or chat box." FOLDED="true" /></node>
        <node TEXT="www.hrsa.gov/opa" FOLDED="true">
          <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/http_www.hrsa.gov_opa.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="TOP" FOLDED="true">
          <node TEXT="TOP" LINK="https://www.340bpriceguide.net/secure-message" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_secure-message.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_secure-message.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Search Bar" FOLDED="true">
        <node TEXT="Enter a medication" FOLDED="true">
          <node TEXT="Form Field" FOLDED="true">
            <attribute NAME="type" VALUE="text" />
          </node>
        </node>
        <node TEXT="Find 340B Prices" FOLDED="true">
          <node TEXT="Button" FOLDED="true" />
        </node>
      </node>
      <node TEXT="What is 340B?" FOLDED="true">
        <node TEXT="What is 340B?" FOLDED="true" />
        <node TEXT="For the past 25 years, 340B has helped provide low-cost medications and better health..." FOLDED="true" />
      </node>
      <node TEXT="Weekly Product Shortages" FOLDED="true" />
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Useful Links" FOLDED="true">
        <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/index.php" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information" FOLDED="true">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" FOLDED="true">
        <node TEXT="501 Fourth Street, #854 Lake Oswego, OR 97034" FOLDED="true" />
        <node TEXT="Phone: (503)592-0681" FOLDED="true" />
        <node TEXT="Email" LINK="mailto:info@340Bpriceguide.com" FOLDED="true" />
      </node>
      <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/http_www.hrsa.gov_opa.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
    <node TEXT="Displays footer information and links." FOLDED="true" /></node>
  </node>
<node TEXT="Opens authentication form to access user account." FOLDED="true" /></node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Carousel" FOLDED="true">
        <node TEXT="Community Health Centers of Lane County" FOLDED="true" />
        <node TEXT="Compassion, Respect, Excellence, Empowerment" FOLDED="true" />
      </node>
      <node TEXT="What is 340B?" FOLDED="true">
        <node TEXT="For the past 25 years, 340B has helped provide low-cost medications..." FOLDED="true" />
      </node>
      <node TEXT="Weekly Product Shortages" FOLDED="true" />
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Useful Links" FOLDED="true">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information" FOLDED="true">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" FOLDED="true">
        <node TEXT="501 Fourth Street, #854 Lake Oswego, OR 97034" FOLDED="true" />
        <node TEXT="Phone: (503)592-0681" FOLDED="true" />
        <node TEXT="Email: info@340Bpriceguide.net" FOLDED="true" />
      </node>
      <node TEXT="Disclaimer" FOLDED="true">
        <node TEXT="The 340B Drug Pricing Program is managed by the HRSA..." FOLDED="true" />
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/http_www.hrsa.gov_opa.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
  <node TEXT="Navigates to the main landing page or dashboard." FOLDED="true"><node TEXT="Centralized area showing user stats and quick actions." FOLDED="true" /></node></node>
</map>