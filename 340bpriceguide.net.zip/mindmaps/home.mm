<map version="1.0.1">
    <node TEXT="Home - 340B Price Guide">
        <node TEXT="Header">
            <node TEXT="Navigation">
                <node TEXT="Home" LINK="https://www.340bpriceguide.net/"/>
                <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search"/>
                <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news"/>
                <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us"/>
                <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us"/>
                <node TEXT="Sign up / Sign in"/>
            </node>
        </node>
        <node TEXT="Main Content">
            <node TEXT="Hero Section">
                <node TEXT="Enter a medication">
                    <node TEXT="Search Field"/>
                    <node TEXT="Find 340B Prices"/>
                </node>
                <node TEXT="Values">
                    <node TEXT="Compassion"/>
                    <node TEXT="Respect"/>
                    <node TEXT="Excellence"/>
                    <node TEXT="Empowerment"/>
                    <node TEXT="Community Health Centers Of Lane County"/>
                </node>
            </node>
            <node TEXT="What is 340B?">
                <node TEXT="For the past 25 years, 340B has helped provide low-cost medications and better health..."/>
            </node>
            <node TEXT="Weekly Product Shortages"/>
        </node>
        <node TEXT="Footer">
            <node TEXT="Useful Links">
                <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php"/>
                <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us"/>
                <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news"/>
                <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us"/>
            </node>
            <node TEXT="Information">
                <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a"/>
            </node>
            <node TEXT="Contact Us">
                <node TEXT="501 Fourth Street, #854 Lake Oswego, OR 97034"/>
                <node TEXT="Phone: (503)592-0681"/>
                <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com"/>
            </node>
            <node TEXT="Disclaimer">
                <node TEXT="The 340B Drug Pricing Program is managed by the Health Resources and Services Administration (HRSA) Office of Pharmacy Affairs (OPA). For more information visit: www.hrsa.gov/opa"/>
                <node TEXT="This material is provided for general informational purposes..."/>
            </node>
        </node>
    </node>
</map>