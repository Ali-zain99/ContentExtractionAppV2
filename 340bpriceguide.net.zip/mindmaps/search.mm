<map version="1.0.1">
  <node TEXT="Search">
    <node TEXT="Page Title">
      <node TEXT="Search"/>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Search Medication or NDC or Therap">
        <node TEXT="Search Comments">
          <node TEXT="Search Comme" />
          <node TEXT="Q" />
        </node>
        <node TEXT="Sort by">
          <node TEXT="Newest" />
        </node>
      </node>
      <node TEXT="Frequently Searched Products">
        <node TEXT="ADVAIR HFA 230-21..." LINK="https://www.340bpriceguide.net/340b-search#486"/>
        <node TEXT="BREO ELLIPTA 100-25..." LINK="https://www.340bpriceguide.net/340b-search#488"/>
        <node TEXT="BUTRANS 5 MCG/HR..." LINK="https://www.340bpriceguide.net/340b-search#14857"/>
        <node TEXT="DULERA 200 MCG-5..." LINK="https://www.340bpriceguide.net/340b-search#13331"/>
        <node TEXT="FARXIGA 10 MG TABL....." LINK="https://www.340bpriceguide.net/340b-search#116"/>
        <node TEXT="JANUVIA 100 MG TAB..." LINK="https://www.340bpriceguide.net/340b-search#534"/>
        <node TEXT="JARDIANCE 10 MG TA..." LINK="https://www.340bpriceguide.net/340b-search#185"/>
        <node TEXT="LANTUS SOLOSTAR 1..." LINK="https://www.340bpriceguide.net/340b-search#588"/>
        <node TEXT="LIDOCAINE 5% PATCH" LINK="https://www.340bpriceguide.net/340b-search#2310"/>
        <node TEXT="LYRICA 100 MG CAPS..." LINK="https://www.340bpriceguide.net/340b-search#19309"/>
        <node TEXT="PROAIR RESPICLICK..." LINK="https://www.340bpriceguide.net/340b-search#18373"/>
        <node TEXT="TRADJENTA 5 MG TA..." LINK="https://www.340bpriceguide.net/340b-search#167"/>
        <node TEXT="TRULICITY 1.5 MG/0...." LINK="https://www.340bpriceguide.net/340b-search#365"/>
        <node TEXT="VICTOZA 2-PAK 18 M..." LINK="https://www.340bpriceguide.net/340b-search#13214"/>
        <node TEXT="XARELTO 10 MG TAB..." LINK="https://www.340bpriceguide.net/340b-search#9718"/>
      </node>
      <node TEXT="Comments">
        <node TEXT="Sophie Mengele">
          <node TEXT="User reports issues with Synjardy availability and 340B pricing at CVS pharmacies."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey explains the correct procedure for CVS pharmacies to use 340B coupon codes."/>
        </node>
        <node TEXT="Tammy McCullough">
          <node TEXT="User asks about the return of the mobile app."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey confirms the mobile app is available and provides a link to a tutorial."/>
        </node>
        <node TEXT="Steven Busselen">
          <node TEXT="User questions the quantity of Synjardy dispensed by CVS."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey explains the normal dosing and pharmacy practices for Synjardy."/>
        </node>
        <node TEXT="Sarah Munoz">
          <node TEXT="User asks if Levemir FlexPen is still covered."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey explains that Levemir has been removed due to discontinuation by Novo Nordisk."/>
        </node>
        <node TEXT="Sandra Dardy">
          <node TEXT="User asks if lispro or 70/30 insulin is covered."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey confirms that lispro/70-30 is covered and suggests search terms."/>
        </node>
        <node TEXT="Kirk J.">
          <node TEXT="User asks about the unit cost calculation on the 340B Price Guide."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey explains how to select pharmacy and quantity to see the estimated cost."/>
        </node>
        <node TEXT="Anonymous">
          <node TEXT="User asks how to select medications from their formulary."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey explains how to choose a formulary on the website."/>
        </node>
        <node TEXT="Kim Kelly">
          <node TEXT="User reports discrepancies in Farxiga/Symbicort availability at Genoa."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey offers to contact the 340B program manager to investigate."/>
        </node>
        <node TEXT="Kristan Stone">
          <node TEXT="User asks if Pennsaid is no longer on the 340B."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey confirms Pennsaid is not available and suggests an alternative."/>
        </node>
        <node TEXT="Torey Lam">
          <node TEXT="Torey mentions Levemir's removal and links to an article."/>
        </node>
        <node TEXT="Load more comments"/>
      </node>
    </node>
  </node>
</map>