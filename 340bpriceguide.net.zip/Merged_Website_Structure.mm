<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home Page">
    <node TEXT="Header">
      <node TEXT="Home" LINK="https://www.340bpriceguide.net/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search">
        <node TEXT="Page Title">
          <node TEXT="Search" />
        </node>
        <node TEXT="Main Content">
          <node TEXT="Search Medication or NDC or Therap">
            <node TEXT="Search Comments">
              <node TEXT="Search Comme" />
              <node TEXT="Q" />
            </node>
            <node TEXT="Sort by">
              <node TEXT="Newest" />
            </node>
          </node>
          <node TEXT="Frequently Searched Products">
            <node TEXT="ADVAIR HFA 230-21..." LINK="https://www.340bpriceguide.net/340b-search#486"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_486.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="BREO ELLIPTA 100-25..." LINK="https://www.340bpriceguide.net/340b-search#488"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_488.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="BUTRANS 5 MCG/HR..." LINK="https://www.340bpriceguide.net/340b-search#14857"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_14857.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="DULERA 200 MCG-5..." LINK="https://www.340bpriceguide.net/340b-search#13331"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_13331.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="FARXIGA 10 MG TABL....." LINK="https://www.340bpriceguide.net/340b-search#116"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_116.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JANUVIA 100 MG TAB..." LINK="https://www.340bpriceguide.net/340b-search#534"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_534.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JARDIANCE 10 MG TA..." LINK="https://www.340bpriceguide.net/340b-search#185"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_185.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LANTUS SOLOSTAR 1..." LINK="https://www.340bpriceguide.net/340b-search#588"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_588.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LIDOCAINE 5% PATCH" LINK="https://www.340bpriceguide.net/340b-search#2310"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_2310.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LYRICA 100 MG CAPS..." LINK="https://www.340bpriceguide.net/340b-search#19309"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_19309.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="PROAIR RESPICLICK..." LINK="https://www.340bpriceguide.net/340b-search#18373"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_18373.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="TRADJENTA 5 MG TA..." LINK="https://www.340bpriceguide.net/340b-search#167"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_167.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="TRULICITY 1.5 MG/0...." LINK="https://www.340bpriceguide.net/340b-search#365"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_365.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="VICTOZA 2-PAK 18 M..." LINK="https://www.340bpriceguide.net/340b-search#13214"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_13214.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="XARELTO 10 MG TAB..." LINK="https://www.340bpriceguide.net/340b-search#9718"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_9718.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Comments">
            <node TEXT="Sophie Mengele">
              <node TEXT="User reports issues with Synjardy availability and 340B pricing at CVS pharmacies." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey explains the correct procedure for CVS pharmacies to use 340B coupon codes." />
            </node>
            <node TEXT="Tammy McCullough">
              <node TEXT="User asks about the return of the mobile app." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey confirms the mobile app is available and provides a link to a tutorial." />
            </node>
            <node TEXT="Steven Busselen">
              <node TEXT="User questions the quantity of Synjardy dispensed by CVS." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey explains the normal dosing and pharmacy practices for Synjardy." />
            </node>
            <node TEXT="Sarah Munoz">
              <node TEXT="User asks if Levemir FlexPen is still covered." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey explains that Levemir has been removed due to discontinuation by Novo Nordisk." />
            </node>
            <node TEXT="Sandra Dardy">
              <node TEXT="User asks if lispro or 70/30 insulin is covered." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey confirms that lispro/70-30 is covered and suggests search terms." />
            </node>
            <node TEXT="Kirk J.">
              <node TEXT="User asks about the unit cost calculation on the 340B Price Guide." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey explains how to select pharmacy and quantity to see the estimated cost." />
            </node>
            <node TEXT="Anonymous">
              <node TEXT="User asks how to select medications from their formulary." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey explains how to choose a formulary on the website." />
            </node>
            <node TEXT="Kim Kelly">
              <node TEXT="User reports discrepancies in Farxiga/Symbicort availability at Genoa." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey offers to contact the 340B program manager to investigate." />
            </node>
            <node TEXT="Kristan Stone">
              <node TEXT="User asks if Pennsaid is no longer on the 340B." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey confirms Pennsaid is not available and suggests an alternative." />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Torey mentions Levemir's removal and links to an article." />
            </node>
            <node TEXT="Load more comments" />
          </node>
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news">
        <node TEXT="Page Title">
          <node TEXT="Articles and News - 340B Price Guide" />
        </node>
        <node TEXT="Main Content">
          <node TEXT="Weekly Product Shortages">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Manufacturer 340B Restrictions for Oregon">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
            <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026.">
              <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
            <node TEXT="Effective October 1, 2025, Bausch Health has ended its participation in the 340B Drug Pricing Program.">
              <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="More Articles">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" />
            <node TEXT="Communication from BPHC announcing new award terms" />
            <node TEXT="Rite Aid Winds Down 340B Operations" />
            <node TEXT="Continued Brand Name Victoza Shortages" />
          </node>
          <node TEXT="Pagination">
            <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_8.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_12.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_16.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us">
        <node TEXT="Main Content">
          <node TEXT="About">
            <node TEXT="340B Price Guide is a customized publication helping entities interpret drug prices." />
          </node>
          <node TEXT="340B Guided Services">
            <node TEXT="340B Price Guide, LLC offers independent consulting for covered entities." />
          </node>
          <node TEXT="Client Testimonials">
            <node TEXT="Marvin Roman, M.D.">
              <node TEXT="340B Price Guide is excellent and saves time figuring out patient affordability." />
            </node>
            <node TEXT="Kylie Fonteno, PA-C">
              <node TEXT="340B Price Guide helps see patient savings and stay updated on price changes." />
            </node>
            <node TEXT="David Homyk">
              <node TEXT="340B Price Guide is excellent and helpful for staff communication." />
            </node>
            <node TEXT="Connie Serra, MD">
              <node TEXT="340B Price Guide was incredibly helpful in solving a pricing dilemma." />
            </node>
            <node TEXT="Charity Aguirre LPN">
              <node TEXT="340B pricing helped a patient afford medication." />
            </node>
          </node>
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_about-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us">
        <node TEXT="Main Content">
          <node TEXT="Contact Form">
            <node TEXT="Name Field" />
            <node TEXT="Email Field" />
            <node TEXT="Company Field" />
            <node TEXT="Address Field" />
            <node TEXT="City, State Zip Field" />
            <node TEXT="Phone Field" />
            <node TEXT="Inquiry Type" />
            <node TEXT="Comment or Question" />
            <node TEXT="Captcha" />
            <node TEXT="Submit" />
          </node>
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Hero Section">
        <node TEXT="Enter a medication">
          <node TEXT="Search Field" />
          <node TEXT="Find 340B Prices" />
        </node>
        <node TEXT="Values">
          <node TEXT="Compassion" />
          <node TEXT="Respect" />
          <node TEXT="Excellence" />
          <node TEXT="Empowerment" />
          <node TEXT="Community Health Centers Of Lane County" />
        </node>
      </node>
      <node TEXT="What is 340B?">
        <node TEXT="For the past 25 years, 340B has helped provide low-cost medications and better health..." />
      </node>
      <node TEXT="Weekly Product Shortages" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Useful Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us">
        <node TEXT="501 Fourth Street, #854 Lake Oswego, OR 97034" />
        <node TEXT="Phone: (503)592-0681" />
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
      </node>
      <node TEXT="Disclaimer">
        <node TEXT="The 340B Drug Pricing Program is managed by the Health Resources and Services Administration (HRSA) Office of Pharmacy Affairs (OPA). For more information visit: www.hrsa.gov/opa" />
        <node TEXT="This material is provided for general informational purposes..." />
      </node>
    </node>
    <node TEXT="Login"><node TEXT="After Login Flow">
    <node TEXT="Header">
      <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/">
        <node TEXT="Navigation" />
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search">
        <node TEXT="Search Medication or NDC or Therap" />
        <node TEXT="Please assign pharmacy from the portal first." />
        <node TEXT="1 TABLET" />
        <node TEXT="Choose Patient Group" />
        <node TEXT="Choose Formulary" />
        <node TEXT="Clear All Data" />
        <node TEXT="FREQUENTLY SEARCHED PRODUCTS">
          <node TEXT="ADVAIR HFA 230-21 MCG INHALERADVAIR HFA 230-21 MCG INHALER">
            <node TEXT="https://www.340bpriceguide.net/340b-search#486" />
          </node>
          <node TEXT="BREO ELLIPTA 100-25 MCG INHALRBREO ELLIPTA 100-25 MCG INHALR">
            <node TEXT="https://www.340bpriceguide.net/340b-search#488" />
          </node>
          <node TEXT="BUTRANS 5 MCG/HR PATCHBUTRANS 5 MCG/HR PATCH">
            <node TEXT="https://www.340bpriceguide.net/340b-search#14857" />
          </node>
          <node TEXT="DULERA 200 MCG-5 MCG INHALERDULERA 200 MCG-5 MCG INHALER">
            <node TEXT="https://www.340bpriceguide.net/340b-search#13331" />
          </node>
          <node TEXT="FARXIGA 10 MG TABLETFARXIGA 10 MG TABLET">
            <node TEXT="https://www.340bpriceguide.net/340b-search#116" />
          </node>
          <node TEXT="JANUVIA 100 MG TABLETJANUVIA 100 MG TABLET">
            <node TEXT="https://www.340bpriceguide.net/340b-search#534" />
          </node>
          <node TEXT="JARDIANCE 10 MG TABLETJARDIANCE 10 MG TABLET">
            <node TEXT="https://www.340bpriceguide.net/340b-search#185" />
          </node>
          <node TEXT="LANTUS SOLOSTAR 100 UNIT/MLLANTUS SOLOSTAR 100 UNIT/ML">
            <node TEXT="https://www.340bpriceguide.net/340b-search#588" />
          </node>
          <node TEXT="LIDOCAINE 5% PATCHLIDOCAINE 5% PATCH">
            <node TEXT="https://www.340bpriceguide.net/340b-search#2310" />
          </node>
          <node TEXT="LYRICA 100 MG CAPSULELYRICA 100 MG CAPSULE">
            <node TEXT="https://www.340bpriceguide.net/340b-search#19309" />
          </node>
          <node TEXT="PROAIR RESPICLICK 90 MCG INHLRPROAIR RESPICLICK 90 MCG INHLR">
            <node TEXT="https://www.340bpriceguide.net/340b-search#18373" />
          </node>
          <node TEXT="TRADJENTA 5 MG TABLETTRADJENTA 5 MG TABLET">
            <node TEXT="https://www.340bpriceguide.net/340b-search#167" />
          </node>
          <node TEXT="TRULICITY 1.5 MG/0.5 ML PENTRULICITY 1.5 MG/0.5 ML PEN">
            <node TEXT="https://www.340bpriceguide.net/340b-search#365" />
          </node>
          <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PENVICTOZA 2-PAK 18 MG/3 ML PEN">
            <node TEXT="https://www.340bpriceguide.net/340b-search#13214" />
          </node>
          <node TEXT="XARELTO 10 MG TABLETXARELTO 10 MG TABLET">
            <node TEXT="https://www.340bpriceguide.net/340b-search#9718" />
          </node>
        </node>
        <node TEXT="COMMENTS">
          <node TEXT="Ali Zain">
            <node TEXT="What do you think?" />
            <node TEXT="Post" />
          </node>
          <node TEXT="Search Comments">
            <node TEXT="Search Comme" />
          </node>
          <node TEXT="Sort by">
            <node TEXT="Newest" />
          </node>
          <node TEXT="Sophie Mengele">
            <node TEXT="User tried sending in Synjardy to 2 different pharmacies now and had issues with discount" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Share">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="CVS pharmacy needs to enter the 340B coupon codes by first searching the TPPC code" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Share">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Tammy McCullough">
            <node TEXT="when can we expect the App to come back?" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Share">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="Hi Tammy, the mobile app has been available for several months." />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Share">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Steven Busselen">
            <node TEXT="I've noticed that a 1-year supply is often not much more expensive that a 90-day supply." />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Share">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="As you know, the normal dosing for Synjardy is 2 tablets twice daily, so a 90 day supply would be 180 tablets." />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Share">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Sarah Munoz">
            <node TEXT="Is Levemir FlexPen 100unit/mL still covered?" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Share">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="Hi Sarah, in November 2023, Novo Nordisk announced it would discontinue Levemir with remaining supplies to end this year." />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Share">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Sandra Dardy">
            <node TEXT="is lispro or 70/30 insulin covered under 340b program?" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Hi Sandra, yes it is. Try searching &quot;Novolin&quot; or &quot;Novolog&quot;" />
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
          </node>
          <node TEXT="Kirk J.">
            <node TEXT="On the 340b Price Guide is the unit cost $0.04 the cost per pill?" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="On the far left, remember to select the pharmacy, quantity, and patient group." />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Anonymous">
            <node TEXT="How do I select medications from our formulary?" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="Hi Stacy, On the far left, where you search for medications, there is a drop-down option, &quot;Choose Formulary.&quot;" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Kim Kelly">
            <node TEXT="I am seeing Farxiga and symbicort as available at Genoa on 340B but the Genoa pharmacists say they are not available." />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="Hi Kim, I'll contact your 340B program manager to see what is going on here." />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Kristan Stone">
            <node TEXT="is Pennsaid no longer on the 340b?" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="Unfortunately, it is not. Please try searching for DICLOFENAC 1.5% TOPICAL SOLN." />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Torey Lam">
            <node TEXT="Levemir has been removed from 340B Price Guide since Novo Nordisk will discontinue it" />
            <node TEXT="Reply">
              <node TEXT="https://www.340bpriceguide.net/340b-search" />
            </node>
          </node>
          <node TEXT="Load more comments" />
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news">
        <node TEXT="Weekly Product Shortages">
          <node TEXT="Read more ...">
            <node TEXT="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
          </node>
          <node TEXT="Print">
            <node TEXT="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages?tmpl=component&amp;print=1&amp;layout=default" />
          </node>
          <node TEXT="Email">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=48f36ca13f26e4d5730c8eb5ff22f26733881327" />
          </node>
        </node>
        <node TEXT="Manufacturer 340B Restrictions for Oregon">
          <node TEXT="Read more ...">
            <node TEXT="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" />
          </node>
          <node TEXT="Print">
            <node TEXT="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon?tmpl=component&amp;print=1&amp;layout=default" />
          </node>
          <node TEXT="Email">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=b6e19967b78cdac7c6c13cbbfc280d6e2dbb5cc9" />
          </node>
        </node>
        <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
          <node TEXT="Read more ...">
            <node TEXT="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" />
          </node>
          <node TEXT="Print">
            <node TEXT="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026?tmpl=component&amp;print=1&amp;layout=default" />
          </node>
          <node TEXT="Email">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=7519cc1dcaee0c8a80b4e0ec10cc94c9d82ee5cb" />
          </node>
        </node>
        <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
          <node TEXT="Read more ...">
            <node TEXT="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" />
          </node>
          <node TEXT="Print">
            <node TEXT="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program?tmpl=component&amp;print=1&amp;layout=default" />
          </node>
          <node TEXT="Email">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=915b7f8f4733ba08ede3e87c060f748bad1a471b" />
          </node>
        </node>
        <node TEXT="Pagination">
          <node TEXT="2">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=4" />
          </node>
          <node TEXT="3">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=8" />
          </node>
          <node TEXT="4">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=12" />
          </node>
          <node TEXT="5">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=16" />
          </node>
          <node TEXT="6">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=20" />
          </node>
          <node TEXT="7">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=24" />
          </node>
          <node TEXT="Next">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=4" />
          </node>
          <node TEXT="End">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=24" />
          </node>
        </node>
        <node TEXT="More Articles">
          <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September">
            <node TEXT="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" />
          </node>
          <node TEXT="Communication from BPHC announcing new award terms">
            <node TEXT="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" />
          </node>
          <node TEXT="Rite Aid Winds Down 340B Operations">
            <node TEXT="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" />
          </node>
          <node TEXT="Continued Brand Name Victoza Shortages">
            <node TEXT="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" />
          </node>
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us">
        <node TEXT="340B Price Guide">
          <node TEXT="customized, entity-specific publication available to Federally Qualified Health Centers" />
        </node>
        <node TEXT="340B Guided Services">
          <node TEXT="340B Price Guide, LLC. offers independent 340B consulting" />
        </node>
        <node TEXT="Client Testimonials">
          <node TEXT="340B Price Guide is excellent">
            <node TEXT="Marvin Roman, M.D." />
          </node>
          <node TEXT="The 340B Price Guide really helps me">
            <node TEXT="Kylie Fonteno, PA-C" />
          </node>
          <node TEXT="340B Price Guide is excellent and has been very helpful">
            <node TEXT="David Homyk" />
          </node>
          <node TEXT="I used 340 Price Guide today!">
            <node TEXT="Connie Serra, MD" />
          </node>
          <node TEXT="I have a 69 y/o pt that was put on Januvia with Medicare">
            <node TEXT="Charity Aguirre LPN" />
          </node>
        </node>
        <node TEXT="Useful Links">
          <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Information">
          <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Contact Us.">
          <node TEXT="info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_about-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us">
        <node TEXT="Contact Form">
          <node TEXT="Name: *" />
          <node TEXT="Email: *" />
          <node TEXT="Company:" />
          <node TEXT="Address:" />
          <node TEXT="City, State Zip:" />
          <node TEXT="Phone:" />
          <node TEXT="Inquiry Type: *">
            <node TEXT="-- Please select --" />
          </node>
          <node TEXT="Comment or Question: *" />
          <node TEXT="Captcha: *" />
        </node>
        <node TEXT="Submit">
          <node TEXT="Submit" />
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_contact-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile">
        <node TEXT="ALI ZAIN">
          <node TEXT="Edit Profile">
            <node TEXT="Edit Profile" LINK="https://www.340bpriceguide.net/profile/profile?layout=edit"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_profile_profile_layout_edit.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="DETAILS">
          <node TEXT="Username: Ali" />
          <node TEXT="First Name: Ali" />
          <node TEXT="Last Name: Zain" />
          <node TEXT="Clinic/Hospital: ABC" />
          <node TEXT="Email Address">
            <node TEXT="alizainsharif48@gmail.com" LINK="mailto:alizainsharif48@gmail.com" />
          </node>
          <node TEXT="Phone Number" />
          <node TEXT="Default Pharmacy" />
          <node TEXT="Default Group" />
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_my-profile.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_logout.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message">
        <node TEXT="SEND SECURE MESSAGE">
          <node TEXT="Form" />
          <node TEXT="Patient Name" />
          <node TEXT="Patient DOB" />
          <node TEXT="Pharmacy" />
          <node TEXT="Medication and Strength" />
          <node TEXT="Prescription Number (if available)" />
          <node TEXT="Contact at the pharmacy (if available)" />
          <node TEXT="Problem/Comment" />
          <node TEXT="SUBMIT" />
        </node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_secure-message.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Community Health Centers Of Lane County" />
      <node TEXT="What is 340B?" />
      <node TEXT="Weekly Product Shortages" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Useful Links">
        <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/index.php"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us">
        <node TEXT="Email" LINK="mailto:info@340Bpriceguide.com" />
      </node>
      <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/http_www.hrsa.gov_opa.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
    </node>
  </node>
</node>
    <node TEXT="Signup" />
  </node>
</map>