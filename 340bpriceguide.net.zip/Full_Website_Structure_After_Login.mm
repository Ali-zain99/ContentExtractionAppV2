<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home - 340B Price Guide">
    <node TEXT="Header">
      <node TEXT="Navigation">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" />
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search">
          <node TEXT="Search Medication or NDC or Therap">
        </node>
          <node TEXT="Please assign pharmacy from the portal first.">
        </node>
          <node TEXT="1 TABLET">
        </node>
          <node TEXT="Choose Patient Group">
        </node>
          <node TEXT="Choose Formulary">
        </node>
          <node TEXT="Clear All Data">
        </node>
          <node TEXT="FREQUENTLY SEARCHED PRODUCTS">
            <node TEXT="ADVAIR HFA 230-21 MCG INHALERADVAIR HFA 230-21 MCG INHALER">
              <node TEXT="https://www.340bpriceguide.net/340b-search#486" />
            </node>
            <node TEXT="BREO ELLIPTA 100-25 MCG INHALRBREO ELLIPTA 100-25 MCG INHALR">
              <node TEXT="https://www.340bpriceguide.net/340b-search#488" />
            </node>
            <node TEXT="BUTRANS 5 MCG/HR PATCHBUTRANS 5 MCG/HR PATCH">
              <node TEXT="https://www.340bpriceguide.net/340b-search#14857" />
            </node>
            <node TEXT="DULERA 200 MCG-5 MCG INHALERDULERA 200 MCG-5 MCG INHALER">
              <node TEXT="https://www.340bpriceguide.net/340b-search#13331" />
            </node>
            <node TEXT="FARXIGA 10 MG TABLETFARXIGA 10 MG TABLET">
              <node TEXT="https://www.340bpriceguide.net/340b-search#116" />
            </node>
            <node TEXT="JANUVIA 100 MG TABLETJANUVIA 100 MG TABLET">
              <node TEXT="https://www.340bpriceguide.net/340b-search#534" />
            </node>
            <node TEXT="JARDIANCE 10 MG TABLETJARDIANCE 10 MG TABLET">
              <node TEXT="https://www.340bpriceguide.net/340b-search#185" />
            </node>
            <node TEXT="LANTUS SOLOSTAR 100 UNIT/MLLANTUS SOLOSTAR 100 UNIT/ML">
              <node TEXT="https://www.340bpriceguide.net/340b-search#588" />
            </node>
            <node TEXT="LIDOCAINE 5% PATCHLIDOCAINE 5% PATCH">
              <node TEXT="https://www.340bpriceguide.net/340b-search#2310" />
            </node>
            <node TEXT="LYRICA 100 MG CAPSULELYRICA 100 MG CAPSULE">
              <node TEXT="https://www.340bpriceguide.net/340b-search#19309" />
            </node>
            <node TEXT="PROAIR RESPICLICK 90 MCG INHLRPROAIR RESPICLICK 90 MCG INHLR">
              <node TEXT="https://www.340bpriceguide.net/340b-search#18373" />
            </node>
            <node TEXT="TRADJENTA 5 MG TABLETTRADJENTA 5 MG TABLET">
              <node TEXT="https://www.340bpriceguide.net/340b-search#167" />
            </node>
            <node TEXT="TRULICITY 1.5 MG/0.5 ML PENTRULICITY 1.5 MG/0.5 ML PEN">
              <node TEXT="https://www.340bpriceguide.net/340b-search#365" />
            </node>
            <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PENVICTOZA 2-PAK 18 MG/3 ML PEN">
              <node TEXT="https://www.340bpriceguide.net/340b-search#13214" />
            </node>
            <node TEXT="XARELTO 10 MG TABLETXARELTO 10 MG TABLET">
              <node TEXT="https://www.340bpriceguide.net/340b-search#9718" />
            </node>
          </node>
          <node TEXT="COMMENTS">
            <node TEXT="Ali Zain">
              <node TEXT="What do you think?">
                </node>
              <node TEXT="Post">
                </node>
            </node>
            <node TEXT="Search Comments">
              <node TEXT="Search Comme">
                </node>
            </node>
            <node TEXT="Sort by">
              <node TEXT="Newest">
                </node>
            </node>
            <node TEXT="Sophie Mengele">
              <node TEXT="User tried sending in Synjardy to 2 different pharmacies now and had issues with discount">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Share">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="CVS pharmacy needs to enter the 340B coupon codes by first searching the TPPC code">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Share">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Tammy McCullough">
              <node TEXT="when can we expect the App to come back?">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Share">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Hi Tammy, the mobile app has been available for several months.">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Share">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Steven Busselen">
              <node TEXT="I've noticed that a 1-year supply is often not much more expensive that a 90-day supply.">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Share">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="As you know, the normal dosing for Synjardy is 2 tablets twice daily, so a 90 day supply would be 180 tablets.">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Share">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Sarah Munoz">
              <node TEXT="Is Levemir FlexPen 100unit/mL still covered?">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Share">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Hi Sarah, in November 2023, Novo Nordisk announced it would discontinue Levemir with remaining supplies to end this year.">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Share">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Sandra Dardy">
              <node TEXT="is lispro or 70/30 insulin covered under 340b program?">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
              <node TEXT="Torey Lam">
                <node TEXT="Hi Sandra, yes it is. Try searching &quot;Novolin&quot; or &quot;Novolog&quot;">
                    </node>
                <node TEXT="Reply">
                  <node TEXT="https://www.340bpriceguide.net/340b-search" />
                </node>
              </node>
            </node>
            <node TEXT="Kirk J.">
              <node TEXT="On the 340b Price Guide is the unit cost $0.04 the cost per pill?">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="On the far left, remember to select the pharmacy, quantity, and patient group.">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Anonymous">
              <node TEXT="How do I select medications from our formulary?">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Hi Stacy, On the far left, where you search for medications, there is a drop-down option, &quot;Choose Formulary.&quot;">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Kim Kelly">
              <node TEXT="I am seeing Farxiga and symbicort as available at Genoa on 340B but the Genoa pharmacists say they are not available.">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Hi Kim, I'll contact your 340B program manager to see what is going on here.">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Kristan Stone">
              <node TEXT="is Pennsaid no longer on the 340b?">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Unfortunately, it is not. Please try searching for DICLOFENAC 1.5% TOPICAL SOLN.">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Torey Lam">
              <node TEXT="Levemir has been removed from 340B Price Guide since Novo Nordisk will discontinue it">
                </node>
              <node TEXT="Reply">
                <node TEXT="https://www.340bpriceguide.net/340b-search" />
              </node>
            </node>
            <node TEXT="Load more comments">
            </node>
          </node>
        </node>
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news">
          <node TEXT="Weekly Product Shortages">
            <node TEXT="Read more ...">
              <node TEXT="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
            </node>
            <node TEXT="Print">
              <node TEXT="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages?tmpl=component&amp;print=1&amp;layout=default" />
            </node>
            <node TEXT="Email">
              <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=48f36ca13f26e4d5730c8eb5ff22f26733881327" />
            </node>
          </node>
          <node TEXT="Manufacturer 340B Restrictions for Oregon">
            <node TEXT="Read more ...">
              <node TEXT="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" />
            </node>
            <node TEXT="Print">
              <node TEXT="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon?tmpl=component&amp;print=1&amp;layout=default" />
            </node>
            <node TEXT="Email">
              <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=b6e19967b78cdac7c6c13cbbfc280d6e2dbb5cc9" />
            </node>
          </node>
          <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
            <node TEXT="Read more ...">
              <node TEXT="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" />
            </node>
            <node TEXT="Print">
              <node TEXT="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026?tmpl=component&amp;print=1&amp;layout=default" />
            </node>
            <node TEXT="Email">
              <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=7519cc1dcaee0c8a80b4e0ec10cc94c9d82ee5cb" />
            </node>
          </node>
          <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
            <node TEXT="Read more ...">
              <node TEXT="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" />
            </node>
            <node TEXT="Print">
              <node TEXT="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program?tmpl=component&amp;print=1&amp;layout=default" />
            </node>
            <node TEXT="Email">
              <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=915b7f8f4733ba08ede3e87c060f748bad1a471b" />
            </node>
          </node>
          <node TEXT="Pagination">
            <node TEXT="2">
              <node TEXT="https://www.340bpriceguide.net/articles-news?start=4" />
            </node>
            <node TEXT="3">
              <node TEXT="https://www.340bpriceguide.net/articles-news?start=8" />
            </node>
            <node TEXT="4">
              <node TEXT="https://www.340bpriceguide.net/articles-news?start=12" />
            </node>
            <node TEXT="5">
              <node TEXT="https://www.340bpriceguide.net/articles-news?start=16" />
            </node>
            <node TEXT="6">
              <node TEXT="https://www.340bpriceguide.net/articles-news?start=20" />
            </node>
            <node TEXT="7">
              <node TEXT="https://www.340bpriceguide.net/articles-news?start=24" />
            </node>
            <node TEXT="Next">
              <node TEXT="https://www.340bpriceguide.net/articles-news?start=4" />
            </node>
            <node TEXT="End">
              <node TEXT="https://www.340bpriceguide.net/articles-news?start=24" />
            </node>
          </node>
          <node TEXT="More Articles">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September">
              <node TEXT="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" />
            </node>
            <node TEXT="Communication from BPHC announcing new award terms">
              <node TEXT="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" />
            </node>
            <node TEXT="Rite Aid Winds Down 340B Operations">
              <node TEXT="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" />
            </node>
            <node TEXT="Continued Brand Name Victoza Shortages">
              <node TEXT="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" />
            </node>
          </node>
        </node>
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us">
          <node TEXT="340B Price Guide">
            <node TEXT="customized, entity-specific publication available to Federally Qualified Health Centers" />
          </node>
          <node TEXT="340B Guided Services">
            <node TEXT="340B Price Guide, LLC. offers independent 340B consulting" />
          </node>
          <node TEXT="Client Testimonials">
            <node TEXT="340B Price Guide is excellent">
              <node TEXT="Marvin Roman, M.D." />
            </node>
            <node TEXT="The 340B Price Guide really helps me">
              <node TEXT="Kylie Fonteno, PA-C" />
            </node>
            <node TEXT="340B Price Guide is excellent and has been very helpful">
              <node TEXT="David Homyk" />
            </node>
            <node TEXT="I used 340 Price Guide today!">
              <node TEXT="Connie Serra, MD" />
            </node>
            <node TEXT="I have a 69 y/o pt that was put on Januvia with Medicare">
              <node TEXT="Charity Aguirre LPN" />
            </node>
          </node>
          <node TEXT="Useful Links">
            <node TEXT="Home" LINK="https://www.340bpriceguide.net/" />
            <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" />
            <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" />
            <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" />
          </node>
          <node TEXT="Information">
            <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" />
          </node>
          <node TEXT="Contact Us.">
            <node TEXT="info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
          </node>
        </node>
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us">
          <node TEXT="Contact Form">
            <node TEXT="Name: *" />
            <node TEXT="Email: *" />
            <node TEXT="Company:" />
            <node TEXT="Address:" />
            <node TEXT="City, State Zip:" />
            <node TEXT="Phone:" />
            <node TEXT="Inquiry Type: *">
              <node TEXT="-- Please select --" />
            </node>
            <node TEXT="Comment or Question: *" />
            <node TEXT="Captcha: *" />
          </node>
          <node TEXT="Submit">
            <node TEXT="Submit" />
          </node>
        </node>
        <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile">
          <node TEXT="ALI ZAIN">
            <node TEXT="Edit Profile">
              <node TEXT="Edit Profile" LINK="https://www.340bpriceguide.net/profile/profile?layout=edit" />
            </node>
          </node>
          <node TEXT="DETAILS">
            <node TEXT="Username: Ali" />
            <node TEXT="First Name: Ali" />
            <node TEXT="Last Name: Zain" />
            <node TEXT="Clinic/Hospital: ABC" />
            <node TEXT="Email Address">
              <node TEXT="alizainsharif48@gmail.com" LINK="mailto:alizainsharif48@gmail.com" />
            </node>
            <node TEXT="Phone Number" />
            <node TEXT="Default Pharmacy" />
            <node TEXT="Default Group" />
          </node>
        </node>
        <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout" />
        <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message">
          <node TEXT="SEND SECURE MESSAGE">
            <node TEXT="Form" />
            <node TEXT="Patient Name" />
            <node TEXT="Patient DOB" />
            <node TEXT="Pharmacy" />
            <node TEXT="Medication and Strength" />
            <node TEXT="Prescription Number (if available)" />
            <node TEXT="Contact at the pharmacy (if available)" />
            <node TEXT="Problem/Comment" />
            <node TEXT="SUBMIT" />
          </node>
        </node>
      </node>
    </node>
    <node TEXT="Search Bar">
      <node TEXT="Enter a medication">
        <node TEXT="Form Field: Search" />
      </node>
      <node TEXT="Button">
        <node TEXT="FIND 340B PRICES" />
      </node>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Community Health Centers Of Lane County" />
      <node TEXT="What is 340B?" />
      <node TEXT="Weekly Product Shortages" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Useful Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php" />
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" />
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" />
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" />
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" />
      </node>
      <node TEXT="Contact Us">
        <node TEXT="Email" LINK="mailto:info@340Bpriceguide.com" />
      </node>
      <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" />
    </node>
  </node>
</map>